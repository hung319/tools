const BLOCK_RULE_START_ID = 2000;
const REDIRECT_RULE_START_ID = 3000;
const DEFAULT_REDIRECT_BLOCK = ['phim.nguonc.com'];

// [v32.3.0] Host của các player/embed đã biết — dùng làm `initiatorDomains` để chỉ
// chặn cú đá tự động, không chặn khi người dùng tự mở trang phim.
// Thêm host mới khi gặp họ player khác (xem README mục 5).
const DEFAULT_PLAYER_HOSTS = [
    'streamc.xyz',            // họ streamc (guard-messages), đá sang phim.nguonc.com
    'api.rophim.stream',      // player rổ phim
    'rophim.soy', 'rophim.stream',
    'phim.nguonc.com',        // chính nó cũng đá sang chính nó ở một số luồng
    'player.phim.nguonc.com'
];

function formalizeMatchPattern(item) {
    try {
        let domain = item.trim();
        if (!domain) return null;
        domain = domain.replace(/^(http|https):\/\//i, '');
        domain = domain.split('/')[0].split(':')[0].replace(/^\*\./, '');
        if (!domain) return null;
        return `*://*.${domain}/*`;
    } catch (e) { return null; }
}

// Chuẩn hoá 1 host cho DNR requestDomains (không nhận path/wildcard/ký tự lạ)
function formalizeDomain(item) {
    try {
        let d = String(item || '').trim().toLowerCase();
        if (!d) return null;
        d = d.replace(/^(https?):\/\//, '').split('/')[0].split(':')[0].replace(/^\*\./, '');
        return /^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$/.test(d) ? d : null;
    } catch (e) { return null; }
}

async function updateRulesAndScripts() {
    const data = await chrome.storage.sync.get(
        ['whitelist', 'blockList', 'masterToggle', 'redirectBlockList', 'playerHosts']);
    const whitelist = data.whitelist || [];
    const blockList = data.blockList || [];
    const redirectBlockList = (data.redirectBlockList && data.redirectBlockList.length)
        ? data.redirectBlockList : DEFAULT_REDIRECT_BLOCK;
    const isEnabled = data.masterToggle !== false;

    // --- 1. CẬP NHẬT CHẶN NETWORK (DNR) ---
    const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = currentRules.map(rule => rule.id);
    
    let addRules = [];
    if (isEnabled) {
        addRules = blockList.map((item, index) => ({
            "id": BLOCK_RULE_START_ID + index,
            "priority": 1,
            "action": { "type": "block" },
            "condition": {
                "urlFilter": item, 
                "resourceTypes": ["script", "sub_frame", "xmlhttprequest", "websocket"]
            }
        }));

        // [v32.3.0] Chặn ĐIỀU HƯỚNG do guard gọi location.replace().
        //
        // BUG của 32.1.0/32.2.x: rule chặn theo `requestDomains` + `main_frame` nên nó
        // chặn CẢ KHI NGƯỜI DÙNG TỰ GÕ địa chỉ muốn vào phim.nguonc.com. Bỏ khỏi danh
        // sách thì lại mất luôn lớp chặn cú đá tự động (mà lớp JS `location.replace`
        // KHÔNG chặn được vì Location là [LegacyUnforgeable]).
        //
        // Cách đúng: chỉ chặn khi điều hướng được KHỞI TẠO TỪ trang player (initiator),
        // không chặn khi người dùng tự điều hướng (initiator là null/chính nó).
        //   • initiatorDomains = host của player → chặn cú đá tự động.
        //   • Bỏ `main_frame` khỏi danh sách khi không xác định được initiator.
        const redirectDomains = [...new Set(redirectBlockList.map(formalizeDomain).filter(Boolean))];
        // Nguồn phát sinh cú đá: các host player/embed đã biết + host của chính trang
        // mà extension đang bảo vệ. Người dùng có thể thêm ở ô "Player Hosts".
        const playerHosts = [...new Set(
            (data.playerHosts && data.playerHosts.length ? data.playerHosts : DEFAULT_PLAYER_HOSTS)
                .map(formalizeDomain).filter(Boolean)
        )];

        redirectDomains.forEach((domain, index) => {
            // (a) Bị đá TỪ player ⇒ chặn (main_frame + sub_frame)
            if (playerHosts.length) {
                addRules.push({
                    "id": REDIRECT_RULE_START_ID + index,
                    "priority": 3,
                    "action": { "type": "block" },
                    "condition": {
                        "requestDomains": [domain],
                        "initiatorDomains": playerHosts,
                        "resourceTypes": ["main_frame", "sub_frame"]
                    }
                });
            }
            // (b) Bị đá qua iframe con (sub_frame) từ bất kỳ đâu ⇒ vẫn chặn, vì
            //     người dùng không bao giờ "tự gõ" một URL vào sub_frame.
            addRules.push({
                "id": REDIRECT_RULE_START_ID + 1000 + index,
                "priority": 3,
                "action": { "type": "block" },
                "condition": {
                    "requestDomains": [domain],
                    "resourceTypes": ["sub_frame"]
                }
            });
        });
    }
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });

    // --- 2. CẬP NHẬT CONTENT SCRIPT ---
    const defaultExcludes = [
        "*://*.google.com/*", "*://*.google.com.vn/*", "*://*.recaptcha.net/*"
    ];
    const userExcludes = whitelist.map(item => formalizeMatchPattern(item)).filter(Boolean);
    const allExcludes = [...new Set([...defaultExcludes, ...userExcludes])];

    try { 
        // Gỡ bỏ các script cũ một cách lặng lẽ
        await chrome.scripting.unregisterContentScripts({ ids: ["cezdev-main", "cezdev-bridge"] }); 
    } catch(e) {}

    // Thoát lặng lẽ nếu user tắt công tắc
    if (!isEnabled) return; 

    try {
        // 2a. Lõi bảo vệ (MAIN world - chặn redirect / bypass anti-adblock)
        // 2b. Bridge (ISOLATED world - đọc storage rồi báo sang MAIN world)
        await chrome.scripting.registerContentScripts([
            {
                id: "cezdev-main",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes, 
                js: ["protection.js"],
                runAt: "document_start",
                world: "MAIN",
                allFrames: true,
                // frame about:blank/blob do trang tạo ra vẫn được tiêm
                matchOriginAsFallback: true
            },
            {
                id: "cezdev-bridge",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes,
                js: ["content_loader.js"],
                runAt: "document_start",
                allFrames: true,
                matchOriginAsFallback: true
            }
        ]);
    } catch (err) {}
}

chrome.runtime.onInstalled.addListener(updateRulesAndScripts);
chrome.runtime.onStartup.addListener(updateRulesAndScripts);

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "UPDATE_RULES") {
        updateRulesAndScripts().then(() => sendResponse({status: "ok"}));
        return true; 
    }
});
