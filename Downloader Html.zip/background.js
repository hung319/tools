// Lắng nghe sự kiện khi người dùng nhấp vào biểu tượng extension
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
    console.warn("Không thể tải HTML từ URL không hợp lệ:", tab.url);
    return;
  }

  try {
    // *** THAY ĐỔI: Thêm Cấu hình (Options) cho fetch ***
    const fetchOptions = {
      method: 'GET',
      headers: {
        // Giả mạo một User-Agent trình duyệt Chrome phổ biến
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        // Bạn có thể thay đổi UA này nếu cần
      }
    };

    // 1. Fetch HTML thô, truyền vào fetchOptions
    const response = await fetch(tab.url, fetchOptions);

    // 2. Kiểm tra nếu request không thành công
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} ${response.statusText}`);
    }

    // 3. Đọc nội dung HTML
    const htmlContent = await response.text();

    // 4. Tạo Blob
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });

    // 5. Chuyển Blob thành Data URL
    const dataUrl = await blobToDataURL(blob);

    // 6. Tạo tên file động là domain
    let filename = 'downloaded.html';
    try {
      const urlObject = new URL(tab.url);
      if (urlObject.hostname) {
        filename = `${urlObject.hostname}.html`; 
      }
    } catch (e) { /* Giữ tên mặc định */ }

    // 7. Tải file
    chrome.downloads.download({
      url: dataUrl,
      filename: filename,
      saveAs: true 
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Lỗi tải file:", chrome.runtime.lastError.message);
      }
    });

  } catch (error) {
    // Log lỗi chi tiết hơn
    console.error(`Lỗi khi fetch HTML từ ${tab.url}:`, error);
  }
});

/**
 * Hàm trợ giúp (helper) để chuyển đổi Blob sang Data URL.
 */
function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.onabort = () => reject(new Error("Blob read was aborted"));
    reader.readAsDataURL(blob);
  });
}