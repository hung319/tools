// Lắng nghe sự kiện khi người dùng nhấp vào biểu tượng extension
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || (!tab.url.startsWith('http://') && !tab.url.startsWith('https://'))) {
    console.warn("Không thể tải HTML từ URL không hợp lệ:", tab.url);
    return;
  }

  try {
    const fetchOptions = {
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    };

    // 1. Fetch HTML thô
    const response = await fetch(tab.url, fetchOptions);

    // 2. Kiểm tra
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status} ${response.statusText}`);
    }

    // 3. Đọc nội dung
    const htmlContent = await response.text();

    // 4. Tạo Blob
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });

    // 5. Chuyển Blob thành Data URL
    const dataUrl = await blobToDataURL(blob);

    // 6. *** THAY ĐỔI: Tạo tên file dựa trên URL đầy đủ ***
    let filename = 'downloaded.html'; // Tên mặc định
    try {
      const urlObject = new URL(tab.url);
      
      // Nối hostname, pathname, và search parameters
      // Ví dụ: "example.com" + "/search/path" + "?a=b"
      let fullPath = urlObject.hostname + urlObject.pathname + urlObject.search;

      // Xóa dấu / ở cuối (nếu có) để tránh tên file bị __.html
      if (fullPath.endsWith('/')) {
        fullPath = fullPath.slice(0, -1);
      }

      // Thay thế tất cả các ký tự không an toàn cho tên file bằng "_"
      // Thay thế: / \ ? % * : | " < > & =
      const safeFilename = fullPath.replace(/[/\\?%*:|"<>&=]/g, '_'); 

      filename = `${safeFilename}.html`;
      
    } catch (e) { 
      // Giữ tên mặc định nếu có lỗi parse URL
    }

    // 7. Tải file
    chrome.downloads.download({
      url: dataUrl,
      filename: filename,
      saveAs: true 
    }, (downloadId) => {
      if (chrome.runtime.lastError) {
        console.error("Lỗi tải file:", chrome.runtime.lastError.message);
      }
    });

  } catch (error) {
    console.error(`Lỗi khi fetch HTML từ ${tab.url}:`, error);
  }
});

/**
 * Hàm trợ giúp (helper) để chuyển đổi Blob sang Data URL.
 */
function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.onabort = () => reject(new Error("Blob read was aborted"));
    reader.readAsDataURL(blob);
  });
}