(function() {
    chrome.storage.sync.get(['redirectList'], (result) => {
        const domains = result.redirectList || [];
        const currentHost = location.hostname;
        
        // Kiểm tra xem trang này có nằm trong danh sách cần chặn Redirect không
        const isStrictTarget = domains.some(domain => currentHost.includes(domain));
        
        // Luôn luôn tiêm script, nhưng truyền cờ (flag) vào
        injectScriptFile(isStrictTarget);
    });

    function injectScriptFile(isStrict) {
        const script = document.createElement('script');
        script.src = chrome.runtime.getURL('protection.js');
        
        // Truyền cấu hình vào script được tiêm qua dataset
        // "true" nếu cần chặn Redirect, "false" nếu chỉ cần Anti-debug cơ bản
        script.setAttribute('data-strict', isStrict);
        
        script.onload = function() { this.remove(); };
        (document.head || document.documentElement).appendChild(script);
    }
})();