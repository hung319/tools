document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.sync.get(['redirectList', 'blockList'], (res) => {
        if (res.redirectList) document.getElementById('redirectList').value = res.redirectList.join('\n');
        if (res.blockList) document.getElementById('blockList').value = res.blockList.join('\n');
    });
});

document.getElementById('save').addEventListener('click', () => {
    // 1. Xử lý Redirect List (Có tự động tách domain)
    const rawRedirect = document.getElementById('redirectList').value;
    const redirectList = extractDomains(rawRedirect);
    
    // Hiển thị lại danh sách đã làm sạch cho người dùng thấy
    document.getElementById('redirectList').value = redirectList.join('\n');

    // 2. Xử lý Block List (DNR) - Giữ nguyên input, chỉ lọc dòng trống/#
    const rawBlock = document.getElementById('blockList').value;
    const blockList = parseBlockList(rawBlock);

    // 3. Lưu
    chrome.storage.sync.set({ redirectList, blockList }, () => {
        // Gửi lệnh update DNR
        chrome.runtime.sendMessage({ action: "UPDATE_RULES" }, () => {
            const status = document.getElementById('status');
            status.textContent = '✅ Đã lưu! (Anti-debug: Global | Redirect: Target)';
            status.style.color = 'green';
            setTimeout(() => { status.textContent = ''; }, 3000);
        });
    });
});

// Hàm tách domain thông minh
function extractDomains(text) {
    return text.split('\n')
        .map(line => {
            let clean = line.trim();
            if (!clean || clean.startsWith('#')) return null;
            try {
                // Nếu là url đầy đủ
                if (clean.includes('://')) {
                    return new URL(clean).hostname;
                }
                // Nếu là domain/path nhưng thiếu http (vd: google.com/abc)
                if (clean.includes('/')) {
                    return new URL('http://' + clean).hostname;
                }
                // Domain trần
                return clean;
            } catch (e) {
                return clean; // Fallback giữ nguyên nếu lỗi
            }
        })
        .filter(x => x)
        .filter((v, i, a) => a.indexOf(v) === i); // Xóa trùng
}

// Hàm lọc Block List (DNR)
function parseBlockList(text) {
    return text.split('\n')
        .map(line => line.trim())
        .filter(line => line.length > 0 && !line.startsWith('#'));
}