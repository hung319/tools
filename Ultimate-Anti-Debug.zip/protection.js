(function() {
    'use strict';
    const currentScript = document.currentScript;
    const isStrictMode = currentScript && currentScript.getAttribute('data-strict') === 'true';
    const LOG_PREFIX = isStrictMode ? "[Anti-Debug STRICT]" : "[Anti-Debug BASIC]";

    // --- 1. GLOBAL: CODE SANITIZER (Lọc code độc hại) ---
    function sanitize(code) {
        if (typeof code !== 'string') return code;
        let clean = code;
        
        // Chặn debugger
        if (clean.includes('debugger')) clean = clean.replace(/\bdebugger\b/g, '/*debugger*/');
        
        // Chặn đóng tab
        if (clean.match(/(window|self|top|parent)\.close\s*\(/)) {
             clean = clean.replace(/(window|self|top|parent)\.close\s*\(/g, 'void(0); /*blocked_close*/');
        }

        // Chặn gán location (Detect các kiểu gán location = 'about:blank')
        const locPattern = /location(\.href)?\s*=\s*['"`]about:blank['"`]/gi;
        if (locPattern.test(clean)) {
            clean = clean.replace(locPattern, 'void(0)');
        }

        return clean;
    }

    // --- 2. GLOBAL: HOOK FUNCTION & EVAL ---
    // Giữ nguyên logic "Classic Wrapper" vì nó ổn định nhất
    const realFunction = window.Function;
    const realEval = window.eval;

    const FakeFunction = function (...args) {
        if (args.length > 0 && typeof args[args.length - 1] === 'string') {
            args[args.length - 1] = sanitize(args[args.length - 1]);
        }
        return realFunction.apply(this, args);
    };
    FakeFunction.prototype = realFunction.prototype;
    FakeFunction.toString = () => "function Function() { [native code] }";
    
    try { window.Function = FakeFunction; } catch (e) {}

    window.eval = function(code) { return realEval(sanitize(code)); };
    window.eval.toString = () => "function eval() { [native code] }";
    
    // Chặn window.close
    window.close = function() { console.log(LOG_PREFIX, "Blocked window.close"); };


    // --- 3. STRICT MODE: CHẶN CHUYỂN HƯỚNG (MẠNH TAY) ---
    if (isStrictMode) {
        console.log(LOG_PREFIX, "🛡️ AGGRESSIVE MODE ACTIVATED");

        const isSafeUrl = (url) => {
            if (!url) return true;
            if (url.toLowerCase().startsWith('about:blank')) return false;
            // Cho phép các protocol của video player
            if (url.match(/^(blob|magnet|ed2k|data):/i)) return true; 
            return true;
        };

        // A. KHÓA LOCATION (Không cần kiểm tra descriptor, cứ lao vào hook)
        try {
            const originalSet = Object.getOwnPropertyDescriptor(window.Location.prototype, 'href').set;
            Object.defineProperty(window.Location.prototype, 'href', {
                set: function(url) {
                    if (isSafeUrl(url)) {
                        // Gọi setter gốc
                        originalSet.call(this, url);
                    } else {
                        console.log(LOG_PREFIX, "Blocked redirect to:", url);
                        // Không làm gì cả -> Chặn đứng
                    }
                },
                configurable: false // Cố gắng khóa không cho trang web sửa lại
            });
        } catch (e) {
            console.log(LOG_PREFIX, "Location.href hook failed (Likely blocked by browser).");
        }

        // B. KHÓA ASSIGN / REPLACE
        ['assign', 'replace'].forEach(method => {
            try {
                const old = window.Location.prototype[method];
                window.Location.prototype[method] = function(url) {
                    if (isSafeUrl(url)) return old.call(this, url);
                    console.log(LOG_PREFIX, `Blocked location.${method} to ${url}`);
                };
            } catch(e) {}
        });

        // C. CHẶN WINDOW.OPEN (Popups)
        const realOpen = window.open;
        window.open = function(url, name, specs) {
            if (!isSafeUrl(url)) {
                console.log(LOG_PREFIX, "Blocked window.open:", url);
                return null;
            }
            return realOpen.call(window, url, name, specs);
        };

        // D. LƯỚI AN TOÀN (BEFORE UNLOAD) - LUÔN BẬT
        // Ở V22 cái này là Fallback, ở V23 cái này là MẶC ĐỊNH cho Strict Mode
        // Đây là chốt chặn cuối cùng nếu mọi hook trên đều thất bại
        window.addEventListener('beforeunload', function (e) {
            e.preventDefault();
            e.returnValue = 'Extension đang bảo vệ trang này. Bạn có chắc muốn rời đi?';
            return e.returnValue;
        });

        // E. CHẶN CLICK LINK ĐỘC HẠI
        document.addEventListener('click', (e) => {
            const a = e.target.closest('a');
            if (a && a.href && !isSafeUrl(a.href)) {
                e.preventDefault();
                e.stopPropagation();
                console.log(LOG_PREFIX, "Blocked link click");
            }
        }, true);
    }
})();