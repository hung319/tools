(function() {
    // --- CẤU HÌNH CỨNG (ZERO LATENCY) ---
    // Vì chạy ngay lập tức, ta không thể đợi đọc storage.
    // Ta sử dụng logic: Nếu là IFRAME -> Kích hoạt chế độ CHIẾN ĐẤU.
    const isIframe = window.self !== window.top;
    
    // Nếu bạn muốn áp dụng cho cả trang chính (không chỉ iframe), hãy sửa thành true.
    // Nhưng khuyến nghị để logic isIframe để tránh lỗi web thường.
    const FORCE_PROTECTION = isIframe; 

    const LOG_PREFIX = "[Anti-Debug V27]";
    
    // --- 1. ANTI-DEBUG CORE (LUÔN BẬT) ---
    
    function sanitize(code) {
        if (typeof code !== 'string') return code;
        if (code.includes('debugger')) return code.replace(/\bdebugger\b/g, '/*debugger*/');
        return code;
    }

    // Hook Function & Eval & SetInterval (Diệt Loop Debugger)
    const realFunction = window.Function;
    const realEval = window.eval;
    const realSetInterval = window.setInterval;

    // A. Hook Function
    const FakeFunction = function (...args) {
        if (args.length > 0 && typeof args[args.length - 1] === 'string') {
            args[args.length - 1] = sanitize(args[args.length - 1]);
        }
        return realFunction.apply(this, args);
    };
    FakeFunction.prototype = realFunction.prototype;
    FakeFunction.toString = () => "function Function() { [native code] }";
    realFunction.prototype.constructor = FakeFunction;
    try { window.Function = FakeFunction; } catch (e) {}

    // B. Hook Eval
    window.eval = function(code) { return realEval(sanitize(code)); };
    window.eval.toString = () => "function eval() { [native code] }";

    // C. Hook SetInterval (Kill Loop)
    window.setInterval = function(func, delay, ...args) {
        if (typeof func === 'string') func = sanitize(func);
        else if (typeof func === 'function') {
            const s = func.toString();
            if (s.includes('debugger')) return realSetInterval(() => {}, delay);
        }
        return realSetInterval(func, delay, ...args);
    };
    window.setInterval.toString = () => "function setInterval() { [native code] }";


    // --- 2. ANTI-REDIRECT (CHỈ BẬT NẾU LÀ IFRAME) ---
    // Phần này chạy đồng bộ ngay lập tức, không có độ trễ 1ms nào.
    
    if (FORCE_PROTECTION) {
        // console.log(LOG_PREFIX, "🛡️ Iframe detected. Locking Doors Immediately.");

        const isSafeUrl = (url) => {
            if (!url) return true; // refresh
            if (url.toLowerCase().startsWith('about:blank')) return false; // Anti-debug hay dùng cái này
            if (url.match(/^(blob|magnet|ed2k|data):/i)) return true; // Player video cần cái này
            // Cho phép link nội bộ hoặc link video
            return true;
        };

        // A. Khóa Location.href
        try {
            const locProto = window.Location.prototype;
            const originalDesc = Object.getOwnPropertyDescriptor(locProto, 'href');
            const originalSet = originalDesc ? originalDesc.set : null;

            if (originalSet) {
                Object.defineProperty(locProto, 'href', {
                    set: function(url) {
                        // Logic kiểm tra cực gắt
                        if (isSafeUrl(url)) {
                            originalSet.call(this, url);
                        } else {
                            console.log(LOG_PREFIX, "🚫 Blocked Immediate Redirect:", url);
                            // Chặn bằng cách không làm gì cả
                        }
                    },
                    configurable: false // Khóa không cho sửa lại
                });
            }
        } catch (e) {
            console.log(LOG_PREFIX, "Loc Hook Error", e);
        }

        // B. Khóa assign / replace
        const denyNav = (method) => {
            try {
                window.Location.prototype[method] = function(url) {
                    if (isSafeUrl(url)) return; // Giả vờ chạy nhưng không làm gì nếu URL lạ
                    // Nếu muốn cho phép chuyển trang hợp lệ thì cần gọi hàm gốc, 
                    // nhưng với Megaplay iframe thì tốt nhất là block hết trừ khi cần thiết.
                    console.log(LOG_PREFIX, `🚫 Blocked location.${method}`);
                };
            } catch(e) {}
        };
        denyNav('assign');
        denyNav('replace');

        // C. BeforeUnload (Chốt chặn cuối cùng)
        // Gắn ngay lập tức
        window.addEventListener('beforeunload', function (e) {
            // Tự động chặn mà không cần người dùng click nếu có thể (Chrome chặn cái này)
            // Nhưng ít nhất nó sẽ hiện popup
            e.preventDefault();
            e.returnValue = 'Protected by Anti-Debug'; 
            return e.returnValue;
        });
        
        // D. Chặn top navigation (Iframe cố thoát ra ngoài)
        try {
            Object.defineProperty(window, 'top', {
                get: function() { 
                    // Trả về chính nó để lừa script nghĩ rằng nó là top
                    return window; 
                }
            });
        } catch(e) {}
    }

})();