const BLOCK_RULE_START_ID = 2000;

async function updateRules() {
    const data = await chrome.storage.sync.get(['blockList']);
    const blockList = data.blockList || [];

    // Lấy rules cũ để xóa
    const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = currentRules.map(rule => rule.id);

    const addRules = [];

    // Tạo Rules chặn từ Block List
    blockList.forEach((item, index) => {
        addRules.push({
            "id": BLOCK_RULE_START_ID + index,
            "priority": 1,
            "action": { "type": "block" },
            "condition": {
                // urlFilter hỗ trợ cả domain, tên file, hoặc path
                // VD: "detect.js" sẽ chặn ".../detect.js"
                "urlFilter": item, 
                "resourceTypes": ["script", "sub_frame", "xmlhttprequest", "websocket"]
            }
        });
    });

    await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: removeRuleIds,
        addRules: addRules
    });
}

chrome.runtime.onInstalled.addListener(updateRules);
chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "UPDATE_RULES") {
        updateRules().then(() => sendResponse({ success: true }));
        return true; 
    }
});