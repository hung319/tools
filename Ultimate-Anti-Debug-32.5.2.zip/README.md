# CezDev Phantom Shield — v32.5.2

Bản 32.5.2 đổi kiến trúc: **chia PROFILE theo host**.
Hook "nặng" (proxy `Function`/`eval`, bọc `performance.now`, chặn `innerHTML`,
sửa `fetch`, bọc `WebAssembly`, `outerWidth`…) chỉ chạy trên các host **đã reverse và đã
kiểm chứng**. Mọi host khác chỉ nhận **lớp an toàn**: treo `DisableDevtool` bằng
`isSuspend` — không chạm vào bất kỳ API nào của trang.

## 0. phimhdcss.com — "mở devmode là bị đá lùi trang liên tục"

### 0a. Cơ chế (đo trên bản capture 2026-11-07)

* Trang phim nạp `<script disable-devtool-auto src="/error.js">`.
  `/error.js` (17 683 B) **đúng là bundle DisableDevtool 0.3.9**, không kèm code nào khác.
* Cấu hình mặc định của lib: `detectors:[1,3,4,5,6,7]` (DefineId, DateToString,
  FuncToString, Debugger, Performance, DebugLib), `interval:500`, `disableMenu:true`.
* Callback mặc định khi phát hiện DevTools:

  ```js
  window.opener = null; window.open('', '_self'); window.close();
  window.history.back();
  setTimeout(() => location.href = 'https://theajack.github.io/disable-devtool/404.html?h=…', 500);
  ```

  → đúng hiện tượng "detect devmode rồi tự lùi trang".

### 0b. Ba cách SAI đã thử (đừng lặp lại)

| Bản | Cách làm | Hậu quả |
|---|---|---|
| 32.5.0-a | DNR block/redirect `/error.js` | **`Secure stream init failed.`** |
| 32.5.0-b | Bọc `Document.querySelector` + thay `window.DisableDevtool` bằng stub | vẫn fail + trang lỗi **"Ôi, hỏng!"** |
| 32.5.1 | Chỉ `isSuspend` — nhưng **vẫn chạy các hook nặng cũ** (Function/eval proxy, `performance.now` cắt bước 40 ms, chặn `innerHTML`, sửa `fetch`, `outerWidth`) trên mọi site | vẫn `Secure stream init failed.`, chuyển server fhdc ↔ hdc thì renderer chết ("Ôi, hỏng!") |

**Bài học:** hook nặng đủ sức phá một player không liên quan. Đừng bật chúng toàn cầu.

### 0c. Cách đúng (32.5.2) — profile theo host

```js
const HEAVY_HOSTS = ['rophim.soy','rophim.stream','api.rophim.stream',
                     'cinejoy.pk','streamc.xyz','phim.nguonc.com',
                     'vn2c.my','vn2data.com','vn2s.com','vn2s.net','vn2s.org','vn2s.tv'];
```

* **Host trong danh sách** → chạy đủ các lớp cũ (WASM-GUARD, làm phẳng đồng hồ,
  streamGuard neutralizer, anti-adblock, redirect "loi"…).
* **Mọi host khác** (`phimhdcss.com`, `tiktok.phimhdc.com`, …) → **chỉ** lớp an toàn:

  ```js
  DisableDevtool.isSuspend = true;   // poll 20 ms trong 15 s, sau đó 500 ms
  ```

  Không chặn URL, không bọc `querySelector`, không proxy `Function`/`eval`, không đổi
  `performance.now`, không chặn `innerHTML`, không sửa `fetch`, không đụng `WebAssembly`.

Vì sao đủ: vòng detector của lib có `if (!(i.isSuspend || l || N())) { …detect… }`
⇒ mọi detector ngừng, không còn `history.back()`/404/`window.close()`, trong khi
`isRunning` vẫn `true` và object vẫn là bản thật nên trang/player thấy lib "đang chạy".

Kiểm tra profile đang chạy: `__phantomGuardStatus().profile` → `"light"` hoặc `"heavy"`.

### 0d. Bằng chứng (browser thật, lib thật)

| Ca | Không shield | 32.5.2 |
|---|---|---|
| `<script disable-devtool-auto>` + kích `window.eruda` | `history.back()` → về trang trước | ở lại; `profile:light`, `isRunning=true`, `isSuspend=true` |
| Trang phim capture + kích detector | bị đá về trang trước | ở lại; `perfPatched:false`, `fetchPatched:false`, `innerHTML` setter nguyên bản, `#player` còn |
| Harness ép heavy (`__phantomForceHeavy`) | — | `wasmWrapped:true`, `perfPatched:true` ⇒ lớp cũ vẫn nguyên |

---

## 1. v32.4.0 sửa gì (cinejoy.pk)

Bản 32.4.0 sửa lỗi: **bị detect trên `cinejoy.pk`** (anti-debug kiểu đo thời gian quanh
`debugger;`), đồng thời sửa một lỗi nghiêm trọng của lớp làm phẳng đồng hồ khiến
**đồng hồ đứng lại trên máy chậm**.

---

## 1. cinejoy.pk — cơ chế anti-debug (đã reverse, không đoán)

`cinejoy.pk` là SvelteKit. Toàn bộ anti-debug nằm trong bundle **root layout**
`/_app/immutable/nodes/0.ZV0KQenn.js`, bị làm rối bằng `javascript-obfuscator`
(string-array + RC4 + base64). Chỉ file này chứa `debugger`.

### 1a. Giải mã obfuscation (quy trình dùng lại được)

Decoder trong file:

```js
function Rd(r, R) {                     // R = khoá RC4, khác nhau ở TỪNG call site
    r = r - 406;                        // ← BASE = 406  (KHÔNG phải 380 — xem mục 1c)
    const c = go();                     // c = mảng 49 chuỗi đã bị mã hoá
    let o = c[r];
    ...
    o = Rd.xLUisc(o, R);                // base64 → %XX → decodeURIComponent → RC4
    return o;
}
```

Điểm dễ sai: **mỗi call site truyền khoá RC4 khác nhau** (`Rd(406,"1f5d")`,
`Rd(420,"r[5Y")`, `Rd(428,"cLm]")`…). Dùng một khoá cho cả mảng sẽ ra rác.

Bảng đã giải (base 406):

| Index | Key | Chuỗi |
|---|---|---|
| 406 | `1f5d` | `play` |
| 409 | `4Q[z` | `paused` |
| 414 | `y^3j` | `$page` |
| 415 | `G[*x` | `setup_stores` |
| 417 | `jnEB` | `store_get` |
| 420 | `r[5Y` | `addEventListener` |
| 423 | `GkmQ` | `now` |
| 425 | `nJ#X` | `pop` |
| 426 | `pP2f` | `pause` |
| 427 | `GP!X` | `user_effect` |
| 428 | `cLm]` | `setInterval` |
| 429 | `pP2f` | `querySelectorAll` |
| 430 | `5Dy%` | `removeEventListener` |

(tất cả đã xác minh lại bằng script — `harness/verify_table.js`)

### 1b. Logic thật (sau khi giải mã)

```js
const I = 120;                 // -2479*-2 + -1*-3863 + 1*-8701  → ngưỡng ms
const L = 2;                   // -3136 + -7255 + 10393          → số lần liên tiếp
let F = 0;                     // -1*7649 + -5774 + -1*-13423
let IW = false;

function e() {                                 // hành động khi bị detect
  for (const Q of document.querySelectorAll('<selector>'))
    try { Q.paused || Q.pause(); } catch {}
}

const KW = () => {
  const lW = performance.now();
  debugger;                                    // ← DevTools mở là dừng ở đây
  F = (performance.now() - lW > I) ? F + 1 : 0;
  IW = F >= L;
  IW && e();                                   // pause video
};

const M = window.setInterval(KW, 500);          // 764*-2 + -3764 + 5792
document.addEventListener('play', MW, true);    // MW: nếu IW thì pause lại (capture)
```

⇒ Mỗi **500 ms** đo thời gian quanh `debugger;`. Nếu **> 120 ms** hai lần liên tiếp thì
**pause toàn bộ `<video>`**, kèm listener bắt sự kiện `play` để pause lại ngay.
Triệu chứng người dùng thấy: video tự dừng, không xem được — chính là "bị detect".

### 1c. Vì sao base = 406 mà không phải 380

Decoder ghi `r = r - (-1258+7994*1+-6356*1)` = `r - 380`, **nhưng** con số đó thuộc về
decoder thứ hai (`fd`/`yo`) trong cùng file. Decoder `Rd` dùng base **406**.
Kiểm chứng bằng call site không thể nhầm: `window[Rd(428,"cLm]")](KW, 500)` phải là
`setInterval` (vì cuối hàm có `clearInterval(M)` viết nguyên văn), và
`Q(428,"cLm]")` chỉ cho `setInterval` khi base = 406.
**Bài học: đừng suy base từ một chỗ rồi áp cho cả file — phải đối chiếu với một call site
có nghĩa đã biết.**

---

## 2. v32.4.0 sửa gì

### 2a. Lớp làm phẳng `performance.now()` — viết lại lần thứ 4

Cả hai họ anti-debug đã gặp (rophim và cinejoy) đều dựa trên **một** điểm chung:
`t0 = performance.now(); debugger; if (performance.now() - t0 > N) …`.
Nghĩa là chỉ cần đồng hồ **không bao giờ nhảy** quanh `debugger;` là mọi ngưỡng đều qua.

Bốn phiên bản — ba cái đầu SAI, ghi lại để không lặp:

| Bản | Cách làm | Vì sao hỏng | Đo được |
|---|---|---|---|
| 32.2.x | đóng băng + "thời gian ảo" trôi 0.5 ms/lần gọi | trang gọi `now()` liên tục (SvelteKit) ⇒ **cộng dồn** ⇒ vượt ngưỡng | callback bọc + chatter ⇒ `clockFlattens:6` mà vẫn `detected:true` |
| 32.4.0a | hấp thụ mọi gap > 60 ms | máy chậm/WebView throttle có gap 50–250 ms ⇒ hấp thụ liên tục ⇒ **đồng hồ đứng lại** | trôi **7 ms / 350 ms** |
| 32.4.0b | EWMA | gap thật > ngưỡng ⇒ mẫu bị hấp thụ ⇒ EWMA **không bao giờ cập nhật** ⇒ deadlock | trôi **203 ms / 500 ms** |
| 32.4.0c | MEDIAN "học nhịp bình thường" | site gọi `debugger;` ở **mọi** tick ⇒ cú nhảy thành "bình thường" ⇒ median học lên ⇒ thôi hấp thụ | chạy 10 s ⇒ `detected:true` (5 lần) |

**Cách đúng (32.4.0): trần bước cố định 40 ms, không học gì cả.**

```js
let out = origNow(), last = out;
const wgNow = () => {
  const t = origNow(), d = t - last;
  last = t;
  if (d > 40) { out += 40; wgState.clockFlattens++; }   // mọi cú nhảy → chỉ trôi 40 ms
  else if (d > 0) out += d;                            // gap bình thường giữ nguyên
  return out;                                          // luôn đơn điệu, không bao giờ nhảy
};
```

- Gap bình thường (16 ms @60fps) **đi qua nguyên vẹn** ⇒ không phá animation/video.
- Mọi cú nhảy bị cắt còn **40 ms** ⇒ `elapsed` quanh `debugger;` ≤ 40 ms,
  **dưới cả ngưỡng 100 (rophim) và 120 (cinejoy)**.
- Chọn 40 chứ không 60: nếu có 2 lần gọi xen giữa thì `2×40 = 80` vẫn < 100.
- Đánh đổi: trang nào gọi `now()` thưa hơn 25 fps sẽ thấy đồng hồ chậm hơn thực tế.
  Vô hại với player vì tiến trình phát lấy từ `video.currentTime`.

### 2b. Giữ nguyên từ các bản trước

- **1B-a** WASM-GUARD cho player rổ phim (`jquery.js` / `ASM_CONSTS` `debugger;` + bom).
- **1B-c/1B-d** chặn cờ bom `__NEXT_DATA_RAW__`, khôi phục `<body>` nếu bom đã nổ.
- **Redirect Block theo initiator** — chỉ chặn cú đá tự động từ player, bạn vẫn tự mở được
  `phim.nguonc.com` (xem mục 4b).
- Proxy `Function`/`eval`/`setInterval` + `sanitize('debugger')` — vẫn hữu ích cho trường hợp
  site truyền callback trực tiếp (cinejoy truyền `KW` thẳng vào `setInterval` nên lớp này
  vô hiệu hoá luôn callback).

---

## 3. Bằng chứng kiểm thử

Harness tái hiện **nguyên văn** logic cinejoy (đã giải mã ở mục 1b) và mô phỏng
"DevTools đang mở" bằng cách chèn 300 ms vào đồng hồ nền ngay sau `debugger;`:

```sh
cd /var/minis/workspace/cj/test && python3 -m http.server 8792 --bind 127.0.0.1 &
# http://127.0.0.1:8792/index.html
```

| Ca | Không shield | Có shield 32.4.0 |
|---|---|---|
| callback truyền trực tiếp | **DETECT** (pause 2 video) | ✅ qua (`ticks:0` — callback bị vô hiệu) |
| callback bị bọc `()=>KW()` | **DETECT** | ✅ qua (`ticks:3` — chỉ nhờ lớp đồng hồ) |
| callback bọc + chatter 900/s | **DETECT** | ✅ qua (`ticks:5`) |
| **12 giây** liên tục, ca khó nhất | — | ✅ qua (`ticks:12`, `detections:0`) |
| **30 giây** liên tục | — | ✅ qua (`ticks:31`, `detections:0`, `clockFlattens:87`) |

Kiểm tra đồng hồ sau khi vá:

| Phép đo | Kết quả |
|---|---|
| gọi dày (300 ms, ~100k lần) | `perfMs 300 / realMs 300` → **ratio 1.00** |
| cú nhảy 3000 ms (debugger) | bước **40 ms** (< 100 và < 120) ✅ |
| đơn điệu | ✅ |

### Không hồi quy

| Kiểm tra | Kết quả |
|---|---|
| rophim (wasm thật, `debugger;` + bom `ASM_CONSTS`) | ✅ `[true,true,true,true]`, `asmBlocked:4` |
| `new Function('debugger;…')` vẫn bị làm sạch & chạy đúng | ✅ |
| `JSON.parse` bóc `browserGuard` | ✅ |
| `innerHTML=''` trên `<body>` vẫn bị chặn | ✅ |
| Nạp shield trên `https://cinejoy.pk/` (trang thật) | ✅ 376 ảnh / 385 link nguyên vẹn |
| `harness/test_dnr.js` (Redirect Block theo initiator) | ✅ 12/12 PASS |

---

## 4. Cách dùng

1. Nạp extension đã giải nén (`chrome://extensions` → Load unpacked).
2. Ô **🚫 Redirect Block List** = `phim.nguonc.com` (để nguyên — xem 4b).
3. Ô **🎬 Player Hosts** để trống = dùng mặc định (`streamc.xyz`, `api.rophim.stream`…).
4. Mở player → mở F12 → trong console của trang/iframe gõ `__phantomWasmStatus()`:
   mong đợi `perfPatched: true`, và `clockFlattens ≥ 1` sau vài giây.

### 4b. Vì sao bạn VẪN tự mở được `phim.nguonc.com`

Rule DNR cũ chặn theo `requestDomains` + `main_frame` nên chặn **cả khi bạn tự gõ địa chỉ**.
Bản 32.3.0+ thêm `initiatorDomains` (theo docs Chrome:
*"The rule will only match network requests originating from the list of initiatorDomains"*):

| Tình huống | `initiator` | Kết quả |
|---|---|---|
| Player tự đá bạn sang | `streamc.xyz` / `api.rophim.stream` | **CHẶN** |
| Bạn tự gõ / bookmark / mở tab mới | rỗng | **CHO QUA** |
| Bấm link từ Google | `google.com` | **CHO QUA** |
| Nhúng dạng `sub_frame` | bất kỳ | **CHẶN** |

## 5. Giới hạn

- Lớp WASM-GUARD bám vào **giá trị mã** `3316`/`3326`. Nếu site đổi số, lớp đó trượt —
  nhưng **lớp trần bước 40 ms vẫn chặn**, vì nó không quan tâm mã hay ngưỡng cụ thể.
- Trần 40 ms giả định ngưỡng detect của site **> 40 ms**. Cả hai họ đã gặp dùng 100/120 ms
  (ngưỡng thấp hơn sẽ bắt cả jitter khung hình bình thường). Nếu gặp site dùng ngưỡng rất thấp,
  hạ `WG_MAX_STEP` xuống.
- Trang gọi `performance.now()` thưa hơn 25 fps sẽ thấy đồng hồ chậm hơn thực tế.
- Cú đá bằng `meta refresh` / điều hướng cấp server có thể không đi qua `initiator`; khi đó
  thêm host vào Player Hosts hoặc dùng `excludedInitiatorDomains`.
- `initiatorDomains` cần **Chrome ≥ 101**.