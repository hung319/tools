# CezDev Phantom Shield — v32.1.0

Bản 32.1.0 sửa lỗi: **mở F12 là bị đá sang `phim.nguonc.com`** dù đã bật chặn redirect.
(Giữ nguyên mọi tính năng cũ; thêm 1 lớp mới + sửa 1 bug thật của bản 32.0.0.)

---

## 1. Vì sao bản 32.0.0 không chặn được

Player ở `embed11.streamc.xyz` (họ streamc, bundle `guard-messages-r25.js`) **không** dùng
meta-refresh hay redirect tĩnh. Chuỗi thật (đo trực tiếp, không đoán):

1. `embed.php` chỉ có `#stream-bootstrap = {api, assets}`.
2. `assets/cdn-start-messages-r25.*.js` **POST** `embed.php` body
   `{action:"bootstrap", referrer, frame_origins, request_grant:true, ...}` → nhận về envelope
   **AES-GCM** (`{format:"aesgcm-v1", iv, data}`), khoá = `SHA-256("stream-bootstrap-v1\n" + <api url>)`,
   AAD = chính chuỗi đó. Giải mã ra:

   ```json
   "browserGuard": {
     "block_shortcuts": true, "block_context_menu": true, "detect_devtools": true,
     "anti_adblock": true, "adblock_action": "pause",
     "devtools_redirect_url": "https://phim.nguonc.com/"
   }
   ```
3. cdn-start ghi lại `#stream-bootstrap.textContent = JSON.stringify(payload)` rồi nạp guard.
   Guard đọc `browserGuard`; phát hiện DevTools ⇒ `stopPlayback()` → gỡ `src` video →
   **`location.replace("https://phim.nguonc.com/")`** → ghi khoá phiên
   `sessionStorage['stream-guard:devtools-session-lock:v1']='locked-v1'` (khoá cả tab).

Guard bắt DevTools bằng 2 nhóm phép đo:

| Nhóm | Cách đo | Phantom Shield 32.0.0 |
|---|---|---|
| Bố cục | `outerWidth-innerWidth > 260` (DevTools dock), 2 lần liên tiếp | ✅ đã chặn (nhờ `outerWidth/outerHeight` → `innerWidth/innerHeight`) |
| Cục bộ | đo thời gian quanh câu lệnh `debugger;` (khi DevTools mở, nó dừng ở đó); + probe `console.debug(regexp,error)` có `toString`/`stack` bị ghi đè; + eruda/vConsole | ❌ **chưa chặn** ← đây là đường đã đá bạn đi |

Vì sao proxy `Function`/`eval`/`setTimeout` của bản cũ không cứu được: `sanitize()` chỉ làm sạch
chuỗi code **mới đưa vào** `Function`/`eval`/`setTimeout`, không chạm được câu `debugger;`
đã biên dịch sẵn trong `guard-messages-r25.js`.

Và vì sao "chặn redirect" của bản cũ vô hiệu: guard gọi `location.replace()` từ chính document.
Chrome/WebKit đánh dấu thành viên của `Location` là **`[LegacyUnforgeable]`** nên
`loc.replace = ...` / `defineProperty(Location.prototype,'href')` bị bỏ qua âm thầm.
(Đã đo lại trong harness: trang vẫn chuyển hướng.) Lớp chặn duy nhất hiệu quả là
`declarativeNetRequest` ở tầng trình duyệt.

## 2. v32.1.0 sửa gì

**a) Bóc cấu hình guard khỏi mọi payload JSON (neutralizer)** — trong `protection.js` (MAIN world,
`document_start`, giữ nguyên điều kiện chạy cũ):

- ghi đè `JSON.parse`: xoá `browserGuard`, và tổng quát hơn — xoá mọi object con mang đủ cặp
  `detect_devtools` + `devtools_redirect_url` (phòng khi site đổi tên khoá);
- `MutationObserver` trên `#stream-bootstrap`: nếu trang tự ghi lại JSON còn `browserGuard` thì bóc ngay
  (cdn-start ghi lại bằng `textContent`);
- xoá + chặn ghi khoá phiên `stream-guard:devtools-session-lock:v1`;
- vô hiệu phép dò console (`console.debug` không còn "native" ⇒ probe của guard không thể arm);
- nếu guard đã kịp chạy thì vô hiệu `waitForAccess`/`isBlocked`.

Guard thoát ngay dòng đầu (`if (!e || ...) return;`) nên `detect_devtools`, `anti_adblock`,
chặn F12/chuột phải, khoá phiên **không bao giờ bật**. Player dùng optional-chaining cho
`window.streamGuard` nên vắng guard không ảnh hưởng phát video.

**b) Chặn điều hướng thật ở tầng mạng** — thêm mục **🚫 Redirect Block List** (mặc định
`phim.nguonc.com`): `background.js` tạo rule DNR
`block` + `requestDomains` + `resourceTypes: ["main_frame","sub_frame"]` (id 3000+, không đụng
rule chặn file id 2000+). Danh sách được `content_loader.js` đẩy sang MAIN world qua sự kiện
`PHANTOM_REDIRECT_HOSTS` để lớp JS cũng biết (best-effort).

**c) Sửa bug thật của 32.0.0:** lớp "chống xoá DOM" (`innerHTML=''` trên `<body>`) **chưa bao giờ
được cài** vì code cũ yêu cầu `document.body` tồn tại — mà lúc `document_start` body còn `null`.
Giờ cài vô điều kiện. Ngoài ra việc ghi đè `innerHTML` đã giữ lại `get`/`enumerable`/`configurable`.

## 3. Bằng chứng kiểm thử

Harness offline dùng **đúng file guard thật** (`guard-messages-r25.7935ef4ddf515ec5.js` — trùng
hash với bản trang live đang tham chiếu; `embed.php` live byte-identical với bản capture),
payload bootstrap thật đã giải mã, `devtools_redirect_url = https://phim.nguonc.com/`, và
**giả lập "DevTools đang mở"** bằng cách ép phép đo `debugger` báo dừng 200 ms.

| Trang test | Kết quả |
|---|---|
| `dbg-plain.html` — guard thật, không shield | `"Phát hiện debugger cục bộ (2 lần)"` → `redirectStarted: true` → **bị đá sang phim.nguonc.com** |
| `dbg-phantom.html` — guard + **Phantom Shield 32.0.0** | vẫn `redirectStarted: true` → **bị đá** (tái hiện đúng lỗi của bạn) |
| `dbg-fixed.html` — guard + **Phantom Shield 32.1.0** | `streamGuard = undefined`, `configStripped: 2`, `sessionLock: null` → **đứng yên** |
| `feat-v32.html` (13 test tính năng) | 10/13 PASS — fail: chống xoá DOM, bóc browserGuard, chặn khoá phiên |
| `feat-fixed.html` (13 test tính năng) | **13/13 PASS** (không hồi quy tính năng cũ) |
| `node /tmp/exttest/adbg.test.js` (mock `chrome.*`) | **15/15 PASS** — rule DNR `block`+`requestDomains`+`main_frame/sub_frame`, priority, id 3000+, lọc host rác, `masterToggle` off, blockList cũ, `cezdev-main` vẫn MAIN/document_start/allFrames |

Chạy lại:

```sh
cd /var/minis/workspace && python3 -m http.server 8791 --bind 127.0.0.1 &
# http://127.0.0.1:8791/streamc_test/dbg/  ->  dbg-plain | dbg-phantom | dbg-fixed | feat-*
node /tmp/exttest/adbg.test.js
```

## 4. Cách dùng

1. Nạp extension đã giải nén (`chrome://extensions` → Load unpacked).
2. Để nguyên **🚫 Redirect Block List = phim.nguonc.com** (để trống cũng tự dùng mặc định).
3. Mở trang player, mở F12 — nếu vẫn muốn chắc, bấm **LƯU CẤU HÌNH** một lần để ghi rule DNR.
4. Kiểm tra: trong console của trang phát, gõ `__phantomGuardStatus()` →
   mong đợi `guardPresent: false`, `configStripped ≥ 1`, `sessionLock: null`.

## 5. Giới hạn

- Lớp neutralizer bám vào **tên khoá `browserGuard`** (+ dò tổng quát theo cặp khoá). Site đổi
  hẳn cấu trúc thì lớp này cần cập nhật; **Redirect Block List (DNR) vẫn độc lập và vẫn chặn**.
- Neutralizer chạy cho mọi trang (theo `matches: <all_urls>` như bản cũ) trừ whitelist;
  nó chỉ can thiệp khi gặp đúng cấu trúc anti-devtools nên không đụng các site khác.
- Phép đo DevTools kiểu khác (ví dụ đổi kích thước cửa sổ, hoặc dò qua iframe cùng origin với
  helper của trang mẹ) không bị ảnh hưởng bởi thay đổi này — nhưng chúng cũng chỉ *phát hiện*,
  còn cú đá đi thì đã bị bóc từ gốc.
