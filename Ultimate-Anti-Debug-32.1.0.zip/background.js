const BLOCK_RULE_START_ID = 2000;
const REDIRECT_RULE_START_ID = 3000;
const DEFAULT_REDIRECT_BLOCK = ['phim.nguonc.com'];

function formalizeMatchPattern(item) {
    try {
        let domain = item.trim();
        if (!domain) return null;
        domain = domain.replace(/^(http|https):\/\//i, '');
        domain = domain.split('/')[0].split(':')[0].replace(/^\*\./, '');
        if (!domain) return null;
        return `*://*.${domain}/*`;
    } catch (e) { return null; }
}

// Chuẩn hoá 1 host cho DNR requestDomains (không nhận path/wildcard/ký tự lạ)
function formalizeDomain(item) {
    try {
        let d = String(item || '').trim().toLowerCase();
        if (!d) return null;
        d = d.replace(/^(https?):\/\//, '').split('/')[0].split(':')[0].replace(/^\*\./, '');
        return /^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$/.test(d) ? d : null;
    } catch (e) { return null; }
}

async function updateRulesAndScripts() {
    const data = await chrome.storage.sync.get(['whitelist', 'blockList', 'masterToggle', 'redirectBlockList']);
    const whitelist = data.whitelist || [];
    const blockList = data.blockList || [];
    const redirectBlockList = (data.redirectBlockList && data.redirectBlockList.length)
        ? data.redirectBlockList : DEFAULT_REDIRECT_BLOCK;
    const isEnabled = data.masterToggle !== false;

    // --- 1. CẬP NHẬT CHẶN NETWORK (DNR) ---
    const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = currentRules.map(rule => rule.id);
    
    let addRules = [];
    if (isEnabled) {
        addRules = blockList.map((item, index) => ({
            "id": BLOCK_RULE_START_ID + index,
            "priority": 1,
            "action": { "type": "block" },
            "condition": {
                "urlFilter": item, 
                "resourceTypes": ["script", "sub_frame", "xmlhttprequest", "websocket"]
            }
        }));

        // [v32.1.0] Chặn ĐIỀU HƯỚNG (guard gọi location.replace -> main_frame/sub_frame).
        // Đây là lớp duy nhất thực sự chặn được: thành viên của Location là
        // [LegacyUnforgeable] nên mọi cách ghi đè bằng JS đều bị Chrome bỏ qua.
        const redirectDomains = [...new Set(redirectBlockList.map(formalizeDomain).filter(Boolean))];
        redirectDomains.forEach((domain, index) => {
            addRules.push({
                "id": REDIRECT_RULE_START_ID + index,
                "priority": 3,
                "action": { "type": "block" },
                "condition": {
                    "requestDomains": [domain],
                    "resourceTypes": ["main_frame", "sub_frame"]
                }
            });
        });
    }
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });

    // --- 2. CẬP NHẬT CONTENT SCRIPT ---
    const defaultExcludes = [
        "*://*.google.com/*", "*://*.google.com.vn/*", "*://*.recaptcha.net/*"
    ];
    const userExcludes = whitelist.map(item => formalizeMatchPattern(item)).filter(Boolean);
    const allExcludes = [...new Set([...defaultExcludes, ...userExcludes])];

    try { 
        // Gỡ bỏ các script cũ một cách lặng lẽ
        await chrome.scripting.unregisterContentScripts({ ids: ["cezdev-main", "cezdev-bridge"] }); 
    } catch(e) {}

    // Thoát lặng lẽ nếu user tắt công tắc
    if (!isEnabled) return; 

    try {
        // 2a. Lõi bảo vệ (MAIN world - chặn redirect / bypass anti-adblock)
        // 2b. Bridge (ISOLATED world - đọc storage rồi báo sang MAIN world)
        await chrome.scripting.registerContentScripts([
            {
                id: "cezdev-main",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes, 
                js: ["protection.js"],
                runAt: "document_start",
                world: "MAIN",
                allFrames: true
            },
            {
                id: "cezdev-bridge",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes,
                js: ["content_loader.js"],
                runAt: "document_start",
                allFrames: true
            }
        ]);
    } catch (err) {}
}

chrome.runtime.onInstalled.addListener(updateRulesAndScripts);
chrome.runtime.onStartup.addListener(updateRulesAndScripts);

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "UPDATE_RULES") {
        updateRulesAndScripts().then(() => sendResponse({status: "ok"}));
        return true; 
    }
});
