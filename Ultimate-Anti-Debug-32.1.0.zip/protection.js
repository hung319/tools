(function() {
    // ==========================================================================
    // 0. STREAM-GUARD NEUTRALIZER — chống "mở F12 là bị đá sang phim.nguonc.com"
    //    (player họ *.streamc.xyz, bundle guard-messages-r25.js)
    //
    //    Vì sao các lớp cũ không ăn:
    //      - Guard tự đọc cấu hình ANTI-DEVTOOLS từ JSON bootstrap:
    //        browserGuard{detect_devtools, devtools_redirect_url:"https://phim.nguonc.com/"}
    //        rồi khi phát hiện DevTools gọi location.replace() từ chính document.
    //      - Chặn redirect kiểu "/loi*.htm" hay ghi đè location.replace/assign
    //        KHÔNG chặn được: Chrome đánh dấu thành viên của Location là
    //        [LegacyUnforgeable] nên gán đè bị bỏ qua âm thầm (đã đo thực tế).
    //      - Proxy Function/eval của Phantom Shield chỉ làm sạch chuỗi code MỚI,
    //        không chạm được câu lệnh `debugger;` đã biên dịch trong guard-messages*.js,
    //        nên phép đo thời gian quanh `debugger;` vẫn báo "đã mở DevTools".
    //
    //    => Cách sửa: chặn guard ngay từ gốc — bóc cấu hình anti-devtools khỏi mọi
    //       payload JSON trước khi guard đọc. Guard thoát ở dòng đầu
    //       (`if (!e || ...) return;`) nên detect_devtools / anti_adblock / chặn phím
    //       / chuyển hướng KHÔNG bao giờ bật. Lớp chặn chuyển hướng thật nằm ở
    //       background.js (declarativeNetRequest block main_frame + sub_frame).
    // ==========================================================================
    const SG_LOCK_KEY = 'stream-guard:devtools-session-lock:v1';
    const sgState = { stripped: 0, hosts: [] };
    const sgLog = (m) => { try { console.log('%c[PhantomShield]', 'color:#0aa', m); } catch (e) {} };

    function sgHostBlocked(url) {
        try {
            if (!url) return false;
            const h = new URL(String(url), location.href).hostname.toLowerCase();
            return sgState.hosts.some(d => h === d || h.endsWith('.' + d));
        } catch (e) { return false; }
    }

    // --- 0a. Bóc cấu hình anti-devtools khỏi mọi kết quả JSON.parse ---
    (function sgPatchJsonParse() {
        const origParse = JSON.parse;
        const stripConfig = (obj) => {
            let hit = false;
            try {
                if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return false;
                if (obj.browserGuard && typeof obj.browserGuard === 'object') {
                    delete obj.browserGuard; hit = true;
                }
                if (obj.guard && typeof obj.guard === 'object' && 'devtools_redirect_url' in obj.guard) {
                    delete obj.guard; hit = true;
                }
                // Tổng quát: object con nào mang đủ dấu hiệu anti-devtools thì bóc
                for (const k in obj) {
                    const v = obj[k];
                    if (v && typeof v === 'object' && !Array.isArray(v) &&
                        ('devtools_redirect_url' in v) && ('detect_devtools' in v)) {
                        delete obj[k]; hit = true;
                    }
                }
            } catch (e) {}
            return hit;
        };
        const patched = function (text, reviver) {
            const out = origParse.call(this, text, reviver);
            try {
                if (stripConfig(out)) {
                    sgState.stripped++;
                    sgLog('Đã bóc cấu hình anti-devtools (browserGuard) — guard sẽ không chạy');
                }
            } catch (e) {}
            return out;
        };
        try {
            Object.defineProperty(patched, 'name', { value: 'parse' });
            Object.defineProperty(patched, 'length', { value: 2 });
        } catch (e) {}
        JSON.parse = patched;
    })();

    // --- 0b. Nếu trang tự ghi lại JSON vào #stream-bootstrap (cdn-start làm vậy) ---
    function sgScrubBootstrap() {
        try {
            const el = document.getElementById('stream-bootstrap');
            if (!el) return;
            const txt = el.textContent;
            if (!txt || txt.indexOf('browserGuard') === -1) return;
            const obj = JSON.parse(txt);
            if (obj && typeof obj === 'object' && obj.browserGuard) {
                delete obj.browserGuard;
                window.__phantomScrubbing = true;
                el.textContent = JSON.stringify(obj);
                window.__phantomScrubbing = false;
                sgState.stripped++;
                sgLog('Đã bóc browserGuard trong #stream-bootstrap');
            }
        } catch (e) {}
    }
    try {
        const startObserver = () => {
            new MutationObserver((records) => {
                if (window.__phantomScrubbing) return;
                for (const rec of records) {
                    const t = rec.target;
                    const el = (t && t.nodeType === 1) ? t : (t && t.parentNode);
                    if (el && (el.id === 'stream-bootstrap' || (el.closest && el.closest('#stream-bootstrap')))) {
                        sgScrubBootstrap();
                        return;
                    }
                }
            }).observe(document.documentElement || document, { childList: true, characterData: true, subtree: true });
            sgScrubBootstrap();
        };
        if (document.documentElement) startObserver();
        else document.addEventListener('readystatechange', function h() {
            if (document.documentElement) { document.removeEventListener('readystatechange', h); startObserver(); }
        });
    } catch (e) {}

    // --- 0c. Khoá phiên DevTools: xoá + chặn ghi ---
    try { sessionStorage.removeItem(SG_LOCK_KEY); } catch (e) {}
    try {
        const store = Storage.prototype, origSet = store.setItem, origGet = store.getItem;
        store.setItem = function (k, v) {
            if (k === SG_LOCK_KEY) { sgLog('Chặn ghi khoá phiên DevTools'); return undefined; }
            return origSet.call(this, k, v);
        };
        store.getItem = function (k) {
            if (k === SG_LOCK_KEY) return null;
            return origGet.call(this, k);
        };
    } catch (e) {}

    // --- 0d. Vô hiệu phép dò console (guard so console.debug phải là hàm native) ---
    try {
        if (window.console && typeof window.console.debug === 'function') {
            const realDebug = window.console.debug.bind(window.console);
            const wrapped = function () { return realDebug.apply(null, arguments); };
            try { Object.defineProperty(wrapped, 'name', { value: 'debug' }); } catch (e) {}
            window.console.debug = wrapped;
        }
    } catch (e) {}

    // --- 0e. Nếu guard đã kịp chạy (script nạp muộn) thì vô hiệu hoá ---
    try {
        if (window.streamGuard && window.streamGuard.__phantomDisabled !== true) {
            window.streamGuard.waitForAccess = async function () {};
            window.streamGuard.isBlocked = function () { return false; };
            try { Object.defineProperty(window.streamGuard, '__phantomDisabled', { value: true }); } catch (e) {}
            sgLog('Đã vô hiệu streamGuard đang chạy');
        }
    } catch (e) {}

    // Danh sách host chặn chuyển hướng do background/bridge đẩy sang
    window.addEventListener('PHANTOM_REDIRECT_HOSTS', function (ev) {
        try {
            const list = (ev && ev.detail && ev.detail.hosts) || [];
            sgState.hosts = list.map(h => String(h || '').trim().toLowerCase())
                .filter(h => h && h.indexOf('/') === -1);
            sgLog('Host chặn chuyển hướng: ' + (sgState.hosts.join(', ') || '(trống)'));
        } catch (e) {}
    });
    window.__phantomGuardStatus = function () {
        let st = null;
        try { st = window.streamGuard && window.streamGuard.status ? window.streamGuard.status() : null; } catch (e) {}
        return {
            version: 'phantom-32.1.0',
            guardPresent: !!window.streamGuard,
            guardDetectDevtools: !!(st && st.detectDevtools),
            configStripped: sgState.stripped,
            sessionLock: (function () { try { return sessionStorage.getItem(SG_LOCK_KEY); } catch (e) { return 'n/a'; } })(),
            redirectHosts: sgState.hosts
        };
    };

    // ==========================================
    // 1. TÀNG HÌNH PROXY (NATIVE FUNCTION SPOOFING)
    // ==========================================
    const proxyMap = new WeakMap();
    const origToString = Function.prototype.toString;

    Function.prototype.toString = function() {
        if (proxyMap.has(this)) {
            return origToString.call(proxyMap.get(this));
        }
        return origToString.call(this);
    };
    proxyMap.set(Function.prototype.toString, origToString);

    function sanitize(code) {
        if (typeof code === 'string' && code.includes('debugger')) {
            return code.replace(/debugger/g, '/*CezDev_Bypassed*/');
        }
        return code;
    }

    function isMalicious(fn) {
        try { 
            if (typeof fn === 'function' && origToString.call(fn).includes('debugger')) {
                return true;
            }
        } catch(e) {}
        return false;
    }

    // ==========================================
    // 2. MỞ KHÓA UI & CHỐNG CLEAR DOM
    // ==========================================
    function unlockDevTools(win) {
        try {
            const stopProp = (e) => {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J'))) {
                    e.stopImmediatePropagation();
                }
                if (['contextmenu', 'selectstart', 'copy'].includes(e.type)) {
                    e.stopImmediatePropagation();
                }
            };
            win.addEventListener('contextmenu', stopProp, true);
            win.addEventListener('keydown', stopProp, true);
            win.addEventListener('selectstart', stopProp, true);
            win.addEventListener('copy', stopProp, true);

            // [v32.1.0] Bản cũ yêu cầu document.body phải tồn tại -> ở document_start
            // body còn null nên lớp chống xoá DOM KHÔNG BAO GIỜ được cài (bug thật).
            // Giờ cài vô điều kiện: chỉ can thiệp khi đối tượng là <body>.
            if (win.document && win.document.documentElement) {
                const bodyDesc = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
                if (bodyDesc && bodyDesc.set) {
                    const origSet = bodyDesc.set;
                    Object.defineProperty(Element.prototype, 'innerHTML', {
                        configurable: bodyDesc.configurable,
                        enumerable: bodyDesc.enumerable,
                        get: bodyDesc.get,
                        set: function(val) {
                            if (this.tagName === 'BODY' && (val === '' || val.trim() === '')) {
                                return; // Block DOM clear silently
                            }
                            return origSet.call(this, val);
                        }
                    });
                }
            }
        } catch(e) {}
    }

    // ==========================================
    // 3. BỌC PROXY CHO CÁC HÀM HỆ THỐNG
    // ==========================================
    const createProxy = (originalFunc, isConstructor = false) => {
        if (!originalFunc) return originalFunc;
        const handler = {
            apply: function(target, thisArg, args) {
                if (args.length > 0) {
                    if (typeof args[0] === 'string') args[0] = sanitize(args[0]);
                    else if (isMalicious(args[0])) args[0] = function() {}; 
                }
                if (isConstructor && args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.apply(target, thisArg, args);
            }
        };
        if (isConstructor) {
            handler.construct = function(target, args) {
                if (args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.construct(target, args);
            };
        }
        const proxy = new Proxy(originalFunc, handler);
        proxyMap.set(proxy, originalFunc);
        return proxy;
    };

    // ==========================================
    // 4. BYPASS ANTI-ADBLOCK + CHẶN REDIRECT "LOI" (vn2c / vn2data / ...)
    //    - Khoá biến kenhvn2 luôn = 1 (site dùng nó để quyết định phát hay hiện loi3.htm)
    //    - Giả lập response 200 cho request dò adblock (/Images/ads/*, contineljs.com)
    //      => chuỗi fetch().catch(...) của site không bao giờ rơi vào catch
    //    - Chặn mọi chuyển hướng tới /loi.htm, /loi2.htm, /loi3.htm
    //    - (strict) vô hiệu hoá check "window.top !== window.self" chống nhúng iframe
    // ==========================================
    /*__CEZDEV_BYPASS_START__*/
    function installBypass(win, strict) {
        try {
            if (win.__cezdev_bypass) return;
            win.__cezdev_bypass = true;
        } catch (e) { return; }

        // ----- A. KHOÁ BIẾN CHỐNG-ADBLOCK (kenhvn2) -----
        // Logic site (play.php) đảo ngược:
        //   kenhvn2 = "" (ban đầu)   -> if (kenhvn2 > 0) FALSE -> nạp link thật
        //   mobi2.js đặt kenhvn2 = 1 -> check lần 2 giữ nguyên link thật
        //   bị phát hiện adblock     -> mobi2 đặt kenhvn2 = "" -> xoá link + hiện /loi3.htm
        // => chỉ nhận giá trị TRUTHY, còn falsy (chuỗi rỗng) thì nuốt đi.
        let __kenhvn2;
        try {
            Object.defineProperty(win, 'kenhvn2', {
                configurable: true,
                get: function() { return __kenhvn2; },
                set: function(v) { if (v) __kenhvn2 = v; }
            });
        } catch (e) {}

        // ----- B. REQUEST DÒ ADBLOCK LUÔN "THÀNH CÔNG" -----
        const PROBE_PATTERNS = ['/images/ads/', 'contineljs.com', 'ads/300.gif', 'adblock'];
        const isProbe = (url) => {
            const low = String(url).toLowerCase();
            return PROBE_PATTERNS.some(function(p) { return low.indexOf(p) !== -1; });
        };
        const fakeResponse = () => {
            try {
                const R = win.Response;
                if (typeof R === 'function') return Promise.resolve(new R(null, { status: 200, statusText: 'OK' }));
            } catch (e) {}
            return Promise.resolve({
                ok: true, status: 200, statusText: 'OK', type: 'opaque',
                text: () => Promise.resolve(''),
                arrayBuffer: () => Promise.resolve(new ArrayBuffer(0)),
                blob: () => Promise.resolve(new Blob([]))
            });
        };
        const localMap = (typeof proxyMap !== 'undefined' && proxyMap) ? proxyMap : new WeakMap();
        try {
            const origFetch = win.fetch;
            if (typeof origFetch === 'function' && !origFetch.__cezdev) {
                const patchedFetch = function(input, init) {
                    let url = '';
                    try { url = (typeof input === 'string') ? input : ((input && input.url) || ''); } catch (e) {}
                    if (isProbe(url)) return fakeResponse();
                    return origFetch.apply(this, arguments);
                };
                patchedFetch.__cezdev = true;
                try { localMap.set(patchedFetch, origFetch); } catch (e) {}
                win.fetch = patchedFetch;
            }
        } catch (e) {}

        // ----- C. CHẶN CHUYỂN HƯỚNG SANG TRANG "LOI" -----
        const BLOCKED_NAV = [/\/loi[0-9]*\.html?/i, /^about:blank/i];
        const isBlockedNav = (url) => {
            if (url === undefined || url === null) return false;
            const u = String(url).trim().toLowerCase();
            if (u === '') return true;
            // Host trong "Redirect Block List" (mặc định: phim.nguonc.com)
            if (sgHostBlocked(url)) return true;
            return BLOCKED_NAV.some(function(re) { return re.test(u); });
        };

        try {
            const loc = win.location;
            if (loc) {
                const wrapLoc = (fn) => function(url) {
                    if (isBlockedNav(url)) return undefined;
                    return fn.apply(loc, arguments);
                };
                if (typeof loc.replace === 'function') loc.replace = wrapLoc(loc.replace);
                if (typeof loc.assign === 'function') loc.assign = wrapLoc(loc.assign);
            }
        } catch (e) {}

        try {
            if (typeof Location !== 'undefined' && Location.prototype) {
                const desc = Object.getOwnPropertyDescriptor(Location.prototype, 'href');
                if (desc && desc.set) {
                    Object.defineProperty(Location.prototype, 'href', {
                        configurable: true,
                        enumerable: desc.enumerable,
                        get: desc.get,
                        set: function(url) {
                            if (isBlockedNav(url)) return;
                            return desc.set.call(this, url);
                        }
                    });
                }
            }
        } catch (e) {}

        try {
            const hist = win.history;
            if (hist) {
                const wrapState = (fn) => function(state, title, url) {
                    if (arguments.length >= 3 && isBlockedNav(url)) return undefined;
                    return fn.apply(hist, arguments);
                };
                if (typeof hist.pushState === 'function') hist.pushState = wrapState(hist.pushState);
                if (typeof hist.replaceState === 'function') hist.replaceState = wrapState(hist.replaceState);
            }
        } catch (e) {}

        try {
            const origOpen = win.open;
            if (typeof origOpen === 'function') {
                win.open = function(url) {
                    if (isBlockedNav(url)) return null;
                    return origOpen.apply(win, arguments);
                };
            }
        } catch (e) {}

        // ----- D. GỠ BOM KHUNG (chỉ bật ở chế độ STRICT) -----
        if (strict) applyStrictMode(win);
    }

    function applyStrictMode(win) {
        try {
            if (win.__cezdev_strict) return;
            win.__cezdev_strict = true;
            // window.top là [Replaceable] -> ghi đè được, khiến check
            // "window.top !== window.self" luôn sai => không bị đá sang /loi.htm
            Object.defineProperty(win, 'top', {
                configurable: true,
                get: function() { return win.self; }
            });
        } catch (e) {}
    }
    /*__CEZDEV_BYPASS_END__*/

    // Domain mặc định bật STRICT (thêm/bớt tuỳ ý; popup cũng đẩy thêm qua bridge)
    const DEFAULT_STRICT_HOSTS = [
        'vn2c.my', 'vn2data.com', 'vn2s.com', 'vn2s.net', 'vn2s.org', 'vn2s.tv'
    ];
    function hostInStrictList() {
        try {
            const h = String(location.hostname || '').toLowerCase();
            if (!h) return false;
            return DEFAULT_STRICT_HOSTS.some(function(d) {
                return h === d || h.endsWith('.' + d);
            });
        } catch (e) { return false; }
    }

    let strictMode = hostInStrictList();

    // Bridge (Isolated World) bắn sự kiện khi domain nằm trong Redirect List của user
    window.addEventListener('ACTIVATE_STRICT_MODE', function() {
        strictMode = true;
        applyStrictMode(window);
        document.querySelectorAll('iframe').forEach(function(f) {
            try { if (f.contentWindow) applyStrictMode(f.contentWindow); } catch (e) {}
        });
    });

    // ==========================================
    // 5. LÕI BẢO VỆ (APPLY HOOKS)
    // ==========================================
    const applyHooks = (win) => {
        try {
            if (win._cezdev_hooked) return;
            win._cezdev_hooked = true;

            unlockDevTools(win);

            win.setTimeout = createProxy(win.setTimeout);
            win.setInterval = createProxy(win.setInterval);
            win.requestAnimationFrame = createProxy(win.requestAnimationFrame); 

            const proxyFunc = createProxy(win.Function, true);
            win.Function = proxyFunc;
            
            try { win.Function.prototype.constructor = proxyFunc; } catch(e){}
            try { 
                const AsyncFunc = Object.getPrototypeOf(async function(){}).constructor;
                Object.getPrototypeOf(async function(){}).constructor = createProxy(AsyncFunc, true);
            } catch(e){}
            try { 
                const GenFunc = Object.getPrototypeOf(function*(){}).constructor;
                Object.getPrototypeOf(function*(){}).constructor = createProxy(GenFunc, true);
            } catch(e){}

            const realEval = win.eval;
            const fakeEval = function(code) { return realEval(sanitize(code)); };
            proxyMap.set(fakeEval, realEval);
            win.eval = fakeEval;

            try {
                const noop = () => {};
                if (win.console) {
                    ['clear', 'profile', 'profileEnd', 'table'].forEach(method => {
                        Object.defineProperty(win.console, method, {
                            value: noop,
                            writable: false,
                            configurable: false 
                        });
                    });
                }
            } catch (e) {}

            try {
                Object.defineProperty(win, 'outerWidth', { get: () => win.innerWidth, configurable: false });
                Object.defineProperty(win, 'outerHeight', { get: () => win.innerHeight, configurable: false });
            } catch (e) {}

            // Bypass anti-adblock / chặn redirect "loi" (đã gồm cả block about:blank cũ)
            installBypass(win, strictMode);

            if (strictMode) applyStrictMode(win);

        } catch(e) {}
    };

    applyHooks(window);

    // ==========================================
    // 6. THEO DÕI VÀ TIÊM VÀO IFRAME LIÊN TỤC
    // ==========================================
    const observeIframes = () => {
        const observer = new MutationObserver((mutations) => {
            for (const mut of mutations) {
                for (const node of mut.addedNodes) {
                    if (node.tagName === 'IFRAME') {
                        try {
                            if (node.contentWindow) applyHooks(node.contentWindow);
                        } catch(e) {}
                        
                        node.addEventListener('load', () => {
                            try {
                                if (node.contentWindow) applyHooks(node.contentWindow);
                            } catch(e) {}
                        }, { once: true });
                    }
                }
            }
        });

        observer.observe(document, { childList: true, subtree: true });
    };

    if (document.documentElement) {
        observeIframes();
    } else {
        window.addEventListener('DOMContentLoaded', observeIframes);
    }

})();