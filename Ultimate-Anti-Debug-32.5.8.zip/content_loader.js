(function() {
    // File này chạy ở Isolated World, an toàn để đọc Storage.
    // Nhiệm vụ 1: báo sang Main World biết domain nào cần "STRICT MODE"
    //             (chặn redirect loi*.htm + gỡ bom khung + bypass anti-adblock).
    // Nhiệm vụ 2 (v32.1.0): đẩy "Redirect Block List" sang Main World để
    //             protection.js chặn điều hướng tới các host đó.
    const DEFAULT_STRICT = [
        'vn2c.my', 'vn2data.com', 'vn2s.com', 'vn2s.net', 'vn2s.org', 'vn2s.tv'
    ];
    const DEFAULT_REDIRECT_BLOCK = ['phim.nguonc.com'];

    const notifyIfTarget = (domains) => {
        try {
            const currentHost = (location.hostname || '').toLowerCase();
            const isStrictTarget = domains.some(domain => {
                const d = String(domain || '').trim().toLowerCase().replace(/^\*\./, '');
                return d && (currentHost === d || currentHost.endsWith('.' + d));
            });
            if (isStrictTarget) {
                // Sự kiện này xuyên qua được ranh giới Isolated/Main World
                window.dispatchEvent(new CustomEvent("ACTIVATE_STRICT_MODE"));
            }
        } catch (e) {}
    };

    // Gửi nhiều lần: content script của Main World có thể được tiêm sau file này,
    // nên phát lại lúc DOM sẵn sàng để không mất sự kiện.
    const pushRedirectHosts = (hosts) => {
        const send = () => {
            try {
                window.dispatchEvent(new CustomEvent("PHANTOM_REDIRECT_HOSTS", {
                    detail: { hosts: hosts }
                }));
            } catch (e) {}
        };
        send();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', send, { once: true });
        }
        setTimeout(send, 300);
    };

    const pushSettings = (result) => {
        const send = () => {
            try {
                window.dispatchEvent(new CustomEvent('PHANTOM_SETTINGS', {
                    detail: {
                        ddSuspend: !(result && result.ddSuspend === false),
                        popupGuard: !(result && result.popupGuard === false),
                        autoMode: !(result && result.autoMode === false)
                    }
                }));
            } catch (e) {}
        };
        send();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', send, { once: true });
        }
        setTimeout(send, 300);
    };

    try {
        chrome.storage.sync.get(['redirectList', 'redirectBlockList', 'ddSuspend', 'popupGuard', 'autoMode'], (result) => {
            pushSettings(result);
            const userList = (result && result.redirectList) || [];
            const list = userList.length ? userList.concat(DEFAULT_STRICT) : DEFAULT_STRICT;
            notifyIfTarget(list);

            const blocked = (result && result.redirectBlockList) || [];
            pushRedirectHosts(blocked.length ? blocked : DEFAULT_REDIRECT_BLOCK);
        });
    } catch (e) {
        notifyIfTarget(DEFAULT_STRICT);
        pushRedirectHosts(DEFAULT_REDIRECT_BLOCK);
    }
})();
