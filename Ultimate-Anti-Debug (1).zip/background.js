const BLOCK_RULE_START_ID = 2000;

function formalizeMatchPattern(item) {
    try {
        let domain = item.trim();
        if (!domain) return null;
        domain = domain.replace(/^(http|https):\/\//i, '');
        domain = domain.split('/')[0].split(':')[0].replace(/^\*\./, '');
        if (!domain) return null;
        return `*://*.${domain}/*`;
    } catch (e) { return null; }
}

async function updateRulesAndScripts() {
    const data = await chrome.storage.sync.get(['whitelist', 'blockList', 'masterToggle']);
    const whitelist = data.whitelist || [];
    const blockList = data.blockList || [];
    const isEnabled = data.masterToggle !== false;

    // --- 1. CẬP NHẬT CHẶN NETWORK (DNR) ---
    const currentRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = currentRules.map(rule => rule.id);
    
    let addRules = [];
    if (isEnabled) {
        addRules = blockList.map((item, index) => ({
            "id": BLOCK_RULE_START_ID + index,
            "priority": 1,
            "action": { "type": "block" },
            "condition": {
                "urlFilter": item, 
                "resourceTypes": ["script", "sub_frame", "xmlhttprequest", "websocket"]
            }
        }));
    }
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });

    // --- 2. CẬP NHẬT CONTENT SCRIPT ---
    const defaultExcludes = [
        "*://*.google.com/*", "*://*.google.com.vn/*", "*://*.recaptcha.net/*"
    ];
    const userExcludes = whitelist.map(item => formalizeMatchPattern(item)).filter(Boolean);
    const allExcludes = [...new Set([...defaultExcludes, ...userExcludes])];

    try { 
        // Gỡ bỏ các script cũ một cách lặng lẽ
        await chrome.scripting.unregisterContentScripts({ ids: ["cezdev-main", "cezdev-bridge"] }); 
    } catch(e) {}

    // Thoát lặng lẽ nếu user tắt công tắc
    if (!isEnabled) return; 

    try {
        // 2a. Lõi bảo vệ (MAIN world - chặn redirect / bypass anti-adblock)
        // 2b. Bridge (ISOLATED world - đọc storage rồi báo sang MAIN world)
        await chrome.scripting.registerContentScripts([
            {
                id: "cezdev-main",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes, 
                js: ["protection.js"],
                runAt: "document_start",
                world: "MAIN",
                allFrames: true
            },
            {
                id: "cezdev-bridge",
                matches: ["<all_urls>"],
                excludeMatches: allExcludes,
                js: ["content_loader.js"],
                runAt: "document_start",
                allFrames: true
            }
        ]);
    } catch (err) {}
}

chrome.runtime.onInstalled.addListener(updateRulesAndScripts);
chrome.runtime.onStartup.addListener(updateRulesAndScripts);

chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === "UPDATE_RULES") {
        updateRulesAndScripts().then(() => sendResponse({status: "ok"}));
        return true; 
    }
});
