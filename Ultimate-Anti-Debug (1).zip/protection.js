(function() {
    // ==========================================
    // 1. TÀNG HÌNH PROXY (NATIVE FUNCTION SPOOFING)
    // ==========================================
    const proxyMap = new WeakMap();
    const origToString = Function.prototype.toString;

    Function.prototype.toString = function() {
        if (proxyMap.has(this)) {
            return origToString.call(proxyMap.get(this));
        }
        return origToString.call(this);
    };
    proxyMap.set(Function.prototype.toString, origToString);

    function sanitize(code) {
        if (typeof code === 'string' && code.includes('debugger')) {
            return code.replace(/debugger/g, '/*CezDev_Bypassed*/');
        }
        return code;
    }

    function isMalicious(fn) {
        try { 
            if (typeof fn === 'function' && origToString.call(fn).includes('debugger')) {
                return true;
            }
        } catch(e) {}
        return false;
    }

    // ==========================================
    // 2. MỞ KHÓA UI & CHỐNG CLEAR DOM
    // ==========================================
    function unlockDevTools(win) {
        try {
            const stopProp = (e) => {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J'))) {
                    e.stopImmediatePropagation();
                }
                if (['contextmenu', 'selectstart', 'copy'].includes(e.type)) {
                    e.stopImmediatePropagation();
                }
            };
            win.addEventListener('contextmenu', stopProp, true);
            win.addEventListener('keydown', stopProp, true);
            win.addEventListener('selectstart', stopProp, true);
            win.addEventListener('copy', stopProp, true);

            if (win.document && win.document.body) {
                const bodyDesc = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
                if (bodyDesc) {
                    const origSet = bodyDesc.set;
                    Object.defineProperty(Element.prototype, 'innerHTML', {
                        set: function(val) {
                            if (this.tagName === 'BODY' && (val === '' || val.trim() === '')) {
                                return; // Block DOM clear silently
                            }
                            return origSet.call(this, val);
                        }
                    });
                }
            }
        } catch(e) {}
    }

    // ==========================================
    // 3. BỌC PROXY CHO CÁC HÀM HỆ THỐNG
    // ==========================================
    const createProxy = (originalFunc, isConstructor = false) => {
        if (!originalFunc) return originalFunc;
        const handler = {
            apply: function(target, thisArg, args) {
                if (args.length > 0) {
                    if (typeof args[0] === 'string') args[0] = sanitize(args[0]);
                    else if (isMalicious(args[0])) args[0] = function() {}; 
                }
                if (isConstructor && args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.apply(target, thisArg, args);
            }
        };
        if (isConstructor) {
            handler.construct = function(target, args) {
                if (args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.construct(target, args);
            };
        }
        const proxy = new Proxy(originalFunc, handler);
        proxyMap.set(proxy, originalFunc);
        return proxy;
    };

    // ==========================================
    // 4. LÕI BẢO VỆ (APPLY HOOKS)
    // ==========================================
    const applyHooks = (win) => {
        try {
            if (win._cezdev_hooked) return;
            win._cezdev_hooked = true;

            unlockDevTools(win);

            win.setTimeout = createProxy(win.setTimeout);
            win.setInterval = createProxy(win.setInterval);
            win.requestAnimationFrame = createProxy(win.requestAnimationFrame); 

            const proxyFunc = createProxy(win.Function, true);
            win.Function = proxyFunc;
            
            try { win.Function.prototype.constructor = proxyFunc; } catch(e){}
            try { 
                const AsyncFunc = Object.getPrototypeOf(async function(){}).constructor;
                Object.getPrototypeOf(async function(){}).constructor = createProxy(AsyncFunc, true);
            } catch(e){}
            try { 
                const GenFunc = Object.getPrototypeOf(function*(){}).constructor;
                Object.getPrototypeOf(function*(){}).constructor = createProxy(GenFunc, true);
            } catch(e){}

            const realEval = win.eval;
            const fakeEval = function(code) { return realEval(sanitize(code)); };
            proxyMap.set(fakeEval, realEval);
            win.eval = fakeEval;

            try {
                const noop = () => {};
                if (win.console) {
                    ['clear', 'profile', 'profileEnd', 'table'].forEach(method => {
                        Object.defineProperty(win.console, method, {
                            value: noop,
                            writable: false,
                            configurable: false 
                        });
                    });
                }
            } catch (e) {}

            try {
                Object.defineProperty(win, 'outerWidth', { get: () => win.innerWidth, configurable: false });
                Object.defineProperty(win, 'outerHeight', { get: () => win.innerHeight, configurable: false });
            } catch (e) {}

            try {
                const origReplace = win.location.replace;
                const origAssign = win.location.assign;
                
                const safeRedirect = (origFn, url) => {
                    if (typeof url === 'string' && (url.includes('about:blank') || url === '')) {
                        return; // Block redirect silently
                    }
                    return origFn.call(win.location, url);
                };
                
                win.location.replace = function(url) { return safeRedirect(origReplace, url); };
                win.location.assign = function(url) { return safeRedirect(origAssign, url); };
            } catch (e) {}

        } catch(e) {}
    };

    applyHooks(window);

    // ==========================================
    // 5. THEO DÕI VÀ TIÊM VÀO IFRAME LIÊN TỤC
    // ==========================================
    const observeIframes = () => {
        const observer = new MutationObserver((mutations) => {
            for (const mut of mutations) {
                for (const node of mut.addedNodes) {
                    if (node.tagName === 'IFRAME') {
                        try {
                            if (node.contentWindow) applyHooks(node.contentWindow);
                        } catch(e) {}
                        
                        node.addEventListener('load', () => {
                            try {
                                if (node.contentWindow) applyHooks(node.contentWindow);
                            } catch(e) {}
                        }, { once: true });
                    }
                }
            }
        });

        observer.observe(document, { childList: true, subtree: true });
    };

    if (document.documentElement) {
        observeIframes();
    } else {
        window.addEventListener('DOMContentLoaded', observeIframes);
    }

})();