(function() {
    const LOG_PREFIX = "[CezDev Phantom V32.1]";
    
    // ==========================================
    // KỸ THUẬT TÀNG HÌNH: NATIVE FUNCTION SPOOFING
    // ==========================================
    const proxyMap = new WeakMap();
    const origToString = Function.prototype.toString;

    // Ghi đè toString toàn cục để che giấu Proxy
    Function.prototype.toString = function() {
        if (proxyMap.has(this)) {
            return origToString.call(proxyMap.get(this));
        }
        return origToString.call(this);
    };
    // Tự bảo vệ chính hàm toString vừa ghi đè
    proxyMap.set(Function.prototype.toString, origToString);

    function sanitize(code) {
        if (typeof code === 'string' && code.includes('debugger')) {
            return code.replace(/debugger/g, '/*CezDev_Bypassed*/');
        }
        return code;
    }

    function isMalicious(fn) {
        try { 
            if (typeof fn === 'function' && origToString.call(fn).includes('debugger')) {
                return true;
            }
        } catch(e) {}
        return false;
    }

    // ==========================================
    // UNLOCK UI (Mở khóa chuột phải, F12)
    // ==========================================
    function unlockDevTools(win) {
        try {
            const stopProp = (e) => {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J'))) {
                    e.stopImmediatePropagation();
                }
                if (['contextmenu', 'selectstart', 'copy'].includes(e.type)) {
                    e.stopImmediatePropagation();
                }
            };
            win.addEventListener('contextmenu', stopProp, true);
            win.addEventListener('keydown', stopProp, true);
            win.addEventListener('selectstart', stopProp, true);
            win.addEventListener('copy', stopProp, true);
        } catch(e) {}
    }

    // ==========================================
    // PROXY TẠO LỚP BỌC (WRAPPER)
    // ==========================================
    const createProxy = (originalFunc, isConstructor = false) => {
        if (!originalFunc) return originalFunc;
        const handler = {
            apply: function(target, thisArg, args) {
                if (args.length > 0) {
                    if (typeof args[0] === 'string') args[0] = sanitize(args[0]);
                    else if (isMalicious(args[0])) args[0] = function() {};
                }
                if (isConstructor && args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.apply(target, thisArg, args);
            }
        };
        if (isConstructor) {
            handler.construct = function(target, args) {
                if (args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.construct(target, args);
            };
        }
        const proxy = new Proxy(originalFunc, handler);
        proxyMap.set(proxy, originalFunc); // Lưu vết để toString() đọc được
        return proxy;
    };

    // ==========================================
    // CORE: APPLY HOOKS
    // ==========================================
    const applyHooks = (win) => {
        try {
            if (win._cezdev_hooked) return;
            win._cezdev_hooked = true;

            unlockDevTools(win);

            win.setTimeout = createProxy(win.setTimeout);
            win.setInterval = createProxy(win.setInterval);

            const proxyFunc = createProxy(win.Function, true);
            win.Function = proxyFunc;
            
            try { win.Function.prototype.constructor = proxyFunc; } catch(e){}
            try { 
                const AsyncFunc = Object.getPrototypeOf(async function(){}).constructor;
                Object.getPrototypeOf(async function(){}).constructor = createProxy(AsyncFunc, true);
            } catch(e){}
            try { 
                const GenFunc = Object.getPrototypeOf(function*(){}).constructor;
                Object.getPrototypeOf(function*(){}).constructor = createProxy(GenFunc, true);
            } catch(e){}

            const realEval = win.eval;
            const fakeEval = function(code) { return realEval(sanitize(code)); };
            proxyMap.set(fakeEval, realEval); // Tàng hình cho hàm eval giả
            win.eval = fakeEval;

        } catch(e) {}
    };

    applyHooks(window);

    // ==========================================
    // QUẢN LÝ IFRAME (Tách Call Stack bằng MutationObserver)
    // ==========================================
    const observeIframes = () => {
        const observer = new MutationObserver((mutations) => {
            for (const mut of mutations) {
                for (const node of mut.addedNodes) {
                    if (node.tagName === 'IFRAME') {
                        // Cố gắng hook ngay khi node được thêm vào DOM
                        try {
                            if (node.contentWindow) applyHooks(node.contentWindow);
                        } catch(e) {}
                        
                        // Hook lại khi iframe tải xong nội dung (đề phòng bị ghi đè)
                        node.addEventListener('load', () => {
                            try {
                                if (node.contentWindow) applyHooks(node.contentWindow);
                            } catch(e) {}
                        }, { once: true });
                    }
                }
            }
        });

        observer.observe(document, { childList: true, subtree: true });
    };

    // Chạy observer khi DOM đã sẵn sàng (hoặc chạy luôn nếu script tiêm ở document_start)
    if (document.documentElement) {
        observeIframes();
    } else {
        window.addEventListener('DOMContentLoaded', observeIframes);
    }

})();