(function() {
    const LOG_PREFIX = "[CezDev Phantom V32]";
    
    function sanitize(code) {
        if (typeof code === 'string' && code.includes('debugger')) {
            return code.replace(/debugger/g, '/*CezDev_Bypassed*/');
        }
        return code;
    }

    function isMalicious(fn) {
        try { 
            if (typeof fn === 'function' && fn.toString().includes('debugger')) {
                return true;
            }
        } catch(e) {}
        return false;
    }

    // UNLOCK UI (Mở khóa chuột phải, F12)
    function unlockDevTools(win) {
        try {
            const stopProp = (e) => {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J'))) {
                    e.stopImmediatePropagation();
                }
                if (['contextmenu', 'selectstart', 'copy'].includes(e.type)) {
                    e.stopImmediatePropagation();
                }
            };
            win.addEventListener('contextmenu', stopProp, true);
            win.addEventListener('keydown', stopProp, true);
            win.addEventListener('selectstart', stopProp, true);
            win.addEventListener('copy', stopProp, true);
        } catch(e) {}
    }

    // PROXY TÀNG HÌNH
    const createProxy = (originalFunc, isConstructor = false) => {
        if (!originalFunc) return originalFunc;
        const handler = {
            apply: function(target, thisArg, args) {
                if (args.length > 0) {
                    if (typeof args[0] === 'string') args[0] = sanitize(args[0]);
                    else if (isMalicious(args[0])) args[0] = function() {};
                }
                if (isConstructor && args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.apply(target, thisArg, args);
            }
        };
        if (isConstructor) {
            handler.construct = function(target, args) {
                if (args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.construct(target, args);
            };
        }
        return new Proxy(originalFunc, handler);
    };

    const applyHooks = (win) => {
        try {
            if (win._cezdev_hooked) return;
            win._cezdev_hooked = true;

            unlockDevTools(win);

            win.setTimeout = createProxy(win.setTimeout);
            win.setInterval = createProxy(win.setInterval);

            const proxyFunc = createProxy(win.Function, true);
            win.Function = proxyFunc;
            
            try { win.Function.prototype.constructor = proxyFunc; } catch(e){}
            try { 
                const AsyncFunc = Object.getPrototypeOf(async function(){}).constructor;
                Object.getPrototypeOf(async function(){}).constructor = createProxy(AsyncFunc, true);
            } catch(e){}
            try { 
                const GenFunc = Object.getPrototypeOf(function*(){}).constructor;
                Object.getPrototypeOf(function*(){}).constructor = createProxy(GenFunc, true);
            } catch(e){}

            const realEval = win.eval;
            win.eval = function(code) { return realEval(sanitize(code)); };
            win.eval.toString = () => "function eval() { [native code] }";

        } catch(e) {}
    };

    applyHooks(window);

    const hookDOMNode = (methodName) => {
        const origMethod = Element.prototype[methodName];
        Element.prototype[methodName] = function() {
            const result = origMethod.apply(this, arguments);
            try {
                const node = arguments[0];
                if (node && node.nodeName === 'IFRAME' && node.contentWindow) {
                    applyHooks(node.contentWindow);
                }
            } catch (e) {} 
            return result;
        };
    };

    hookDOMNode('appendChild');
    hookDOMNode('insertBefore');
    hookDOMNode('replaceChild');

})();