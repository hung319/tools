(function() {
    // File này chạy ở Isolated World, an toàn để đọc Storage.
    // Nhiệm vụ: báo sang Main World biết domain nào cần "STRICT MODE"
    // (chặn redirect loi*.htm + gỡ bom khung + bypass anti-adblock).
    const DEFAULT_STRICT = [
        'vn2c.my', 'vn2data.com', 'vn2s.com', 'vn2s.net', 'vn2s.org', 'vn2s.tv'
    ];

    const notifyIfTarget = (domains) => {
        try {
            const currentHost = (location.hostname || '').toLowerCase();
            const isStrictTarget = domains.some(domain => {
                const d = String(domain || '').trim().toLowerCase().replace(/^\*\./, '');
                return d && (currentHost === d || currentHost.endsWith('.' + d));
            });
            if (isStrictTarget) {
                // Sự kiện này xuyên qua được ranh giới Isolated/Main World
                window.dispatchEvent(new CustomEvent("ACTIVATE_STRICT_MODE"));
            }
        } catch (e) {}
    };

    try {
        chrome.storage.sync.get(['redirectList'], (result) => {
            const userList = (result && result.redirectList) || [];
            const list = userList.length ? userList.concat(DEFAULT_STRICT) : DEFAULT_STRICT;
            notifyIfTarget(list);
        });
    } catch (e) {
        notifyIfTarget(DEFAULT_STRICT);
    }
})();
