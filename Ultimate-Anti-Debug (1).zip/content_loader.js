(function() {
    // File này chạy ở Isolated World, an toàn để đọc Storage
    chrome.storage.sync.get(['redirectList'], (result) => {
        const domains = result.redirectList || [];
        const currentHost = location.hostname;
        
        // Kiểm tra xem trang này (hoặc iframe này) có nằm trong danh sách đen không
        const isStrictTarget = domains.some(domain => currentHost.includes(domain));
        
        if (isStrictTarget) {
            // Bắn sự kiện sang Main World (nơi protection.js đang chạy)
            // Kỹ thuật này xuyên qua được ranh giới Isolated/Main World
            window.dispatchEvent(new CustomEvent("ACTIVATE_STRICT_MODE"));
        }
    });
})();