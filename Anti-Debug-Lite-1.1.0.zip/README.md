# CezDev Anti-Debug Lite — v1.1.0

Extension tối giản. Chỉ 2 việc, không panel, không cấu hình, không storage.

## Nó làm gì

### 1. Không đăng ký timer chứa `debugger;`
Ở `document_start` (trước mọi script của trang), `setInterval` / `setTimeout` /
`requestAnimationFrame` được bọc bằng `Proxy`:

```js
const src = Function.prototype.toString.call(callback);
if (src.length < 20000 && /\bdebugger\b/.test(src)) {
    // không đăng ký timer này
}
```

⇒ Câu `debugger;` **không bao giờ được thực thi** ⇒ DevTools không dừng, không mở
đúng dòng trong file player, không có overlay "Paused in debugger".

Bọc bằng Proxy nên `setInterval.toString()` vẫn in `[native code]`.
Timer không chứa `debugger` chạy bình thường (đã đo).

### 2. Không cho biên dịch mã chứa `debugger;`
`rophim.net` dùng **console-ban**. Checker của nó:

```js
var t0 = performance.now();
(function(){}).constructor("debugger")();     // ← DevTools dừng ở đây
var open = performance.now() - t0 > 100;
```

Extension bọc `Function` (và `Function.prototype.constructor`, constructor của async /
generator), thay chuỗi `debugger` bằng `0;` trước khi biên dịch:

```
Function("debugger")  →  function anonymous() { 0; }
```

⇒ không còn câu lệnh nào để DevTools dừng, phép đo ~0 ms, detector trả `false`.
`Function.prototype.toString.call(Function)` vẫn `[native code]`,
`(function(){}).constructor === Function` vẫn `true`.

### 3. Treo `DisableDevtool`
Nếu trang dùng thư viện này (`<script disable-devtool-auto src="/error.js">`), extension
chỉ đặt `DisableDevtool.isSuspend = true` — dùng đúng API của nó:

* mọi detector ngừng chạy ⇒ không `history.back()`, không bị đá sang
  `theajack.github.io/disable-devtool/404.html`;
* `DisableDevtool.isRunning` vẫn `true` và object vẫn là bản thật ⇒ trang/player không
  thấy bị can thiệp.

## Nó KHÔNG làm gì (cố ý)

* Không chặn/redirect URL nào (không làm hỏng `Secure stream init`).
* Không đụng `performance.now` (không làm player/stream bị đen hình).
* Không proxy `Function` / `eval`.
* Không sửa `fetch`, `innerHTML`, `location`, `history`, `window.open`.
* Không panel, không công tắc, không danh sách host.

Toàn bộ chỉ là 1 file `protect.js` (~90 dòng) chạy trong mọi frame.

## Kiểm tra
DevTools → console (chọn đúng frame nếu là iframe):

```js
window.__liteBlocked     // số timer chứa debugger đã bỏ
window.__liteSanitized   // số lần chuỗi chứa debugger bị làm sạch khi biên dịch
window.__liteDD          // 1 nếu đã treo được DisableDevtool
```

## Đo

| Ca | Không có extension | Có Lite |
|---|---|---|
| Trang có `setInterval(fn)` với `debugger` trong fn | chạy 120 lần | **0 lần** (timer bị bỏ) |
| Timer bình thường cùng trang | 20 lần | 22 lần (không ảnh hưởng) |
| `setInterval.toString()` | `[native code]` | `[native code]` |
| Trang DisableDevtool + kích detector | `history.back()` | ở lại, `isSuspend=true` |
| console-ban `Function("debugger")` | pause + `isOpen=true` | `0;`, `isOpen=false` |
| `performance.now` sau stall 200 ms | 200 ms | 200 ms (không bị sửa) |

## Cài
1. Gỡ extension cũ (bản có panel) để tránh chồng lớp.
2. `chrome://extensions` → Developer mode → Load unpacked → chọn thư mục này.
