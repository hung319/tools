/* CezDev Anti-Debug Lite — 2 việc, không hơn.
 *
 * 1. KHÔNG đăng ký timer/callback nào chứa `debugger;`
 *    → DevTools không dừng, không nhảy vào file player.
 * 2. Treo DisableDevtool bằng chính API của nó (isSuspend = true)
 *    → detector ngừng, không history.back(), không bị đá sang trang 404.
 *
 * Không panel, không storage, không chặn URL, không đụng performance.now,
 * không proxy Function/eval, không sửa fetch/innerHTML.
 */
(function () {
    'use strict';

    if (window.__liteInstalled) return;
    try { Object.defineProperty(window, '__liteInstalled', { value: true, configurable: true }); } catch (e) {}

    // ------------------------------------------------------------------
    // 1. Bỏ timer chứa `debugger;`
    // ------------------------------------------------------------------
    function hasDebugger(fn) {
        try {
            if (typeof fn !== 'function') return false;
            var src = Function.prototype.toString.call(fn);
            if (!src || src.length > 20000) return false;
            if (src.indexOf('[native code]') !== -1) return false;
            return /\bdebugger\b/.test(src);
        } catch (e) { return false; }
    }

    function guard(name) {
        try {
            var orig = window[name];
            if (typeof orig !== 'function' || orig.__liteGuard) return;
            var patched = new Proxy(orig, {
                apply: function (target, thisArg, args) {
                    if (hasDebugger(args[0])) {
                        window.__liteBlocked = (window.__liteBlocked || 0) + 1;
                        try { console.log('%c[Lite]', 'color:#0aa', 'bỏ ' + name + ' chứa debugger'); } catch (e) {}
                        // setInterval: trả id "câm"; setTimeout/rAF: 0
                        return name === 'setInterval' ? target.call(window, function () {}, 2147483647) : 0;
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });
            try { Object.defineProperty(patched, '__liteGuard', { value: true }); } catch (e) {}
            window[name] = patched;
        } catch (e) {}
    }

    // Cố ý KHÔNG bọc requestAnimationFrame: vòng render của canvas/player có thể
    // chứa chuỗi 'debugger' và bị bỏ ⇒ màn hình đen. Chỉ chặn 2 loại timer.
    guard('setInterval');
    guard('setTimeout');

    // ------------------------------------------------------------------
    // 2. Không cho biên dịch mã chứa `debugger;`
    //    console-ban (dùng trên rophim.net) dò DevTools bằng:
    //        var t0 = performance.now();
    //        (function(){}).constructor("debugger")();     // <-- pause
    //        var open = performance.now() - t0 > 100;
    //    Chặn ngay ở chỗ biên dịch: chuỗi "debugger" được thay bằng "0;" nên
    //    không còn câu lệnh nào để DevTools dừng, và phép đo trả về ~0 ms.
    //    Không đụng performance.now, không đụng fetch/hay DOM.
    // ------------------------------------------------------------------
    function sanitize(code) {
        if (typeof code !== 'string' || code.indexOf('debugger') === -1) return code;
        window.__liteSanitized = (window.__liteSanitized || 0) + 1;
        return code.replace(/\bdebugger\b/g, '0;');
    }

    (function guardFunctionCtor() {
        try {
            var OrigFunction = window.Function;
            if (!OrigFunction || OrigFunction.__liteFn) return;
            var proxied = new Proxy(OrigFunction, {
                apply: function (target, thisArg, args) {
                    var i = args.length - 1;
                    if (i >= 0) args[i] = sanitize(args[i]);
                    return Reflect.apply(target, thisArg, args);
                },
                construct: function (target, args) {
                    var i = args.length - 1;
                    if (i >= 0) args[i] = sanitize(args[i]);
                    return Reflect.construct(target, args);
                }
            });
            try { Object.defineProperty(proxied, '__liteFn', { value: true }); } catch (e) {}
            window.Function = proxied;
            // (function(){}).constructor  -> phải trỏ về bản đã bọc
            try { OrigFunction.prototype.constructor = proxied; } catch (e) {}
            try {
                Object.defineProperty(Object.getPrototypeOf(async function () {}), 'constructor',
                    { value: proxied, configurable: true, writable: true });
            } catch (e) {}
            try {
                Object.defineProperty(Object.getPrototypeOf(function* () {}), 'constructor',
                    { value: proxied, configurable: true, writable: true });
            } catch (e) {}
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 3. Treo DisableDevtool (nếu trang dùng)
    // ------------------------------------------------------------------
    var ticks = 0;
    var fast = null;
    function suspend() {
        try {
            var dd = window.DisableDevtool;
            if (typeof dd === 'function' && dd.isSuspend !== true) {
                dd.isSuspend = true;
                window.__liteDD = (window.__liteDD || 0) + 1;
            }
        } catch (e) {}
        if (++ticks === 300 && fast) {           // ~9 s đầu: 30 ms/lần
            try { clearInterval(fast); } catch (e) {}
            try { setInterval(suspend, 1000); } catch (e) {}
        }
    }
    try { suspend(); fast = setInterval(suspend, 30); } catch (e) {}
})();
