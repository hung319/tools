/* CezDev Anti-Debug Lite 1.3.0 — gọn, không panel.
 *
 * 1. Bỏ timer/callback chứa `debugger;`            → DevTools không dừng
 * 2. Làm sạch chuỗi có `debugger` khi biên dịch     → chặn console-ban
 *    (Function / AsyncFunction / GeneratorFunction — giữ nguyên ngữ nghĩa async)
 * 3. console.clear/table → no-op                    → console không bị xoá liên tục
 * 4. window.devtoolsFormatters → nuốt probe         → chặn checker formatter
 * 5. Bóc `browserGuard` khỏi JSON                   → stream-guard tự tắt (nguonc/streamc)
 * 6. DisableDevtool.isSuspend = true                → hết bị đá lùi trang
 *
 * KHÔNG đụng: performance.now, fetch, innerHTML, location, history, DOM.
 */
(function () {
    'use strict';

    if (window.__liteInstalled) return;
    try { Object.defineProperty(window, '__liteInstalled', { value: true, configurable: true }); } catch (e) {}

    function bump(k) { window[k] = (window[k] || 0) + 1; }

    // ------------------------------------------------------------------
    // 1. Bỏ timer chứa `debugger;`
    // ------------------------------------------------------------------
    function hasDebugger(fn) {
        try {
            if (typeof fn !== 'function') return false;
            var src = Function.prototype.toString.call(fn);
            if (!src || src.length > 20000) return false;
            if (src.indexOf('[native code]') !== -1) return false;
            return /\bdebugger\b/.test(src);
        } catch (e) { return false; }
    }

    function guardTimer(name) {
        try {
            var orig = window[name];
            if (typeof orig !== 'function' || orig.__liteGuard) return;
            var patched = new Proxy(orig, {
                apply: function (target, thisArg, args) {
                    if (hasDebugger(args[0])) {
                        bump('__liteBlocked');
                        return name === 'setInterval' ? target.call(window, function () {}, 2147483647) : 0;
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });
            try { Object.defineProperty(patched, '__liteGuard', { value: true }); } catch (e) {}
            window[name] = patched;
        } catch (e) {}
    }
    guardTimer('setInterval');
    guardTimer('setTimeout');

    // ------------------------------------------------------------------
    // 2. Làm sạch `debugger` khi biên dịch mã từ chuỗi
    //    console-ban: (function(){}).constructor("debugger")()
    // ------------------------------------------------------------------
    function sanitize(code) {
        if (typeof code !== 'string' || code.indexOf('debugger') === -1) return code;
        bump('__liteSanitized');
        return code.replace(/\bdebugger\b/g, '0;');
    }

    function proxifyCtor(orig) {
        if (typeof orig !== 'function') return null;
        try {
            if (orig.__liteCtor) return orig;
        } catch (e) {}
        var p = new Proxy(orig, {
            apply: function (target, thisArg, args) {
                var i = args.length - 1;
                if (i >= 0) args[i] = sanitize(args[i]);
                return Reflect.apply(target, thisArg, args);
            },
            construct: function (target, args) {
                var i = args.length - 1;
                if (i >= 0) args[i] = sanitize(args[i]);
                return Reflect.construct(target, args);
            }
        });
        try { Object.defineProperty(p, '__liteCtor', { value: true }); } catch (e) {}
        return p;
    }

    (function hardenConstructors() {
        try {
            // 2a. Function (toàn cục) + Function.prototype.constructor
            var F = window.Function;
            var pF = proxifyCtor(F);
            if (pF) {
                window.Function = pF;
                try { Object.defineProperty(F.prototype, 'constructor', { value: pF, configurable: true, writable: true }); } catch (e) {}
            }
            // 2b. AsyncFunction / GeneratorFunction: bọc CHÍNH constructor gốc của chúng.
            //     Tuyệt đối không trỏ về Function thường — làm vậy Alpine (Coolify) gọi
            //     `new AsyncFunction(...)().catch()` và nhận undefined ⇒ trang vỡ.
            var asyncCtor;
            try { asyncCtor = Object.getPrototypeOf(async function () {}).constructor; } catch (e) {}
            if (asyncCtor && asyncCtor !== F) {
                var pA = proxifyCtor(asyncCtor);
                if (pA) {
                    try { Object.defineProperty(Object.getPrototypeOf(async function () {}), 'constructor', { value: pA, configurable: true, writable: true }); } catch (e) {}
                }
            }
            var genCtor;
            try { genCtor = Object.getPrototypeOf(function* () {}).constructor; } catch (e) {}
            if (genCtor && genCtor !== F) {
                var pG = proxifyCtor(genCtor);
                if (pG) {
                    try { Object.defineProperty(Object.getPrototypeOf(function* () {}), 'constructor', { value: pG, configurable: true, writable: true }); } catch (e) {}
                }
            }
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 3. console.clear / table → no-op
    // ------------------------------------------------------------------
    (function hardenConsole() {
        try {
            var c = window.console;
            if (!c) return;
            var noop = function () {};
            ['clear', 'table', 'profile', 'profileEnd', 'group', 'groupEnd'].forEach(function (k) {
                try { Object.defineProperty(c, k, { value: noop, writable: false, configurable: false }); } catch (e) {}
            });
            window.__liteConsole = true;
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 4. devtoolsFormatters: nuốt "probe" (header nhưng không có hasBody)
    //    Giữ nguyên formatter thật của DevTools extension nếu có.
    // ------------------------------------------------------------------
    (function hardenFormatters() {
        try {
            var list = [];
            var realPush = Array.prototype.push;
            try {
                Object.defineProperty(list, 'push', {
                    configurable: true,
                    value: function () {
                        for (var i = 0; i < arguments.length; i++) {
                            var f = arguments[i];
                            var isProbe = f && typeof f === 'object' &&
                                typeof f.header === 'function' && !('hasBody' in f);
                            if (isProbe) { bump('__liteFormatter'); continue; }
                            realPush.call(list, f);
                        }
                        return list.length;
                    }
                });
            } catch (e) {}
            Object.defineProperty(window, 'devtoolsFormatters', {
                configurable: true,
                get: function () { return list; },
                set: function () {}
            });
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 5. Bóc `browserGuard` (stream-guard của nguonc/streamc)
    //    Guard đọc: JSON.parse(document.getElementById('stream-bootstrap').textContent)
    //                .browserGuard
    //    và thoát ngay nếu thiếu ⇒ không đo kích thước, không `debugger;`,
    //    không lockSession, không redirect.
    //    Chỉ bóc khi object khớp chữ ký anti-debug của guard.
    // ------------------------------------------------------------------
    (function scrubBrowserGuard() {
        try {
            var isGuardCfg = function (o) {
                try {
                    if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
                    return typeof o.detect_devtools === 'boolean' &&
                           typeof o.anti_adblock === 'boolean' &&
                           ('adblock_action' in o) &&
                           ('block_shortcuts' in o || 'block_context_menu' in o);
                } catch (e) { return false; }
            };
            var strip = function (obj) {
                var hit = false;
                try {
                    if (!obj || typeof obj !== 'object') return false;
                    if (isGuardCfg(obj.browserGuard)) { delete obj.browserGuard; hit = true; }
                    if (isGuardCfg(obj.guard)) { delete obj.guard; hit = true; }
                    for (var k in obj) {
                        var v = obj[k];
                        if (isGuardCfg(v)) { delete obj[k]; hit = true; }
                    }
                } catch (e) {}
                if (hit) bump('__liteGuard');
                return hit;
            };

            var origParse = JSON.parse;
            var patched = function (text, reviver) {
                var out = origParse.apply(this, arguments);
                try { strip(out); } catch (e) {}
                return out;
            };
            try { Object.defineProperty(patched, 'name', { value: 'parse' }); } catch (e) {}
            JSON.parse = patched;

            // Trang nào đã ghi sẵn JSON vào DOM: dọn luôn cho chắc.
            var scrubDom = function () {
                try {
                    var el = document.getElementById('stream-bootstrap');
                    if (!el) return;
                    var txt = el.textContent;
                    if (!txt || txt.indexOf('browserGuard') === -1) return;
                    var obj = origParse(txt);
                    if (obj && obj.browserGuard) {
                        delete obj.browserGuard;
                        el.textContent = JSON.stringify(obj);
                        bump('__liteGuard');
                    }
                } catch (e) {}
            };
            scrubDom();
            document.addEventListener('DOMContentLoaded', function () { scrubDom(); setTimeout(scrubDom, 500); }, { once: true });
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 6. Treo DisableDevtool
    // ------------------------------------------------------------------
    var ticks = 0;
    var fast = null;
    function suspend() {
        try {
            var dd = window.DisableDevtool;
            if (typeof dd === 'function' && dd.isSuspend !== true) {
                dd.isSuspend = true;
                bump('__liteDD');
            }
        } catch (e) {}
        if (++ticks === 300 && fast) {
            try { clearInterval(fast); } catch (e) {}
            try { setInterval(suspend, 1000); } catch (e) {}
        }
    }
    try { suspend(); fast = setInterval(suspend, 30); } catch (e) {}
})();
