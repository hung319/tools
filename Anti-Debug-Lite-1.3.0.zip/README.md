# CezDev Anti-Debug Lite — v1.3.0

Extension tối giản. Không panel, không cấu hình, không storage. 6 lớp, mỗi lớp đều
"hẹp" để không phá trang web bình thường.

## Nó làm gì

### 1. Bỏ timer chứa `debugger;`
`setInterval` / `setTimeout` bọc bằng Proxy: callback có `\bdebugger\b` thì **không đăng ký**
⇒ câu `debugger;` không bao giờ chạy ⇒ DevTools không dừng. Proxy giữ `toString()` =
`[native code]`.

### 2. Làm sạch `debugger` khi biên dịch từ chuỗi
console-ban (rophim.net) dò bằng:

```js
var t0 = performance.now();
(function(){}).constructor("debugger")();     // ← DevTools dừng
var open = performance.now() - t0 > 100;
```

`Function` và `Function.prototype.constructor` được bọc: chuỗi chứa `debugger` bị đổi thành
`0;` trước khi biên dịch ⇒ `function anonymous( ) { 0; }` ⇒ không dừng, đo ~0 ms.

**AsyncFunction / GeneratorFunction được bọc bằng CHÍNH constructor gốc của chúng**,
không trỏ về `Function` thường. (Bản 1.2.0 trỏ về `Function` ⇒ mọi
`new AsyncFunction(...)().catch()` trả `undefined` ⇒ Alpine.js của **Coolify** vỡ với
`n.call(...).catch is not a function`.)

### 3. `console.clear` / `console.table` → no-op
Guard gọi `clear()` liên tục ⇒ đây là lý do console bị xoá. `performanceChecker` của
console-ban đo `console.table` vs `console.log`; table no-op ⇒ không bao giờ `t > 10*f`.

### 4. `window.devtoolsFormatters` → nuốt probe
console-ban push một object `{header(){…}}` rồi `console.log({})`; DevTools mở sẽ gọi
`header()`. Ta chỉ nuốt object **không có `hasBody`** (đúng dạng probe), formatter thật của
DevTools extension vẫn được giữ.

### 5. Bóc `browserGuard` — bypass stream-guard (phim.nguonc.com / streamc.xyz)
`guard-messages-r25.js` mở đầu bằng:

```js
let e;
try { e = JSON.parse(document.getElementById("stream-bootstrap").textContent).browserGuard } catch { return }
if (!e || !["block_shortcuts","block_context_menu","detect_devtools","anti_adblock"]
        .every(k => typeof e[k] === "boolean") || !["notice","pause"].includes(e.adblock_action)) return;
```

Thiếu `browserGuard` là **thoát ngay** ⇒ không đo `outerWidth-innerWidth`, không chạy
`performance.now(); debugger;`, không `lockSession()` (khoá phiên), không
`location.replace("https://phim.nguonc.com/")`.

Ta bọc `JSON.parse` và bóc key đó **chỉ khi** object khớp đúng chữ ký trên
(`detect_devtools` + `anti_adblock` + `adblock_action` + `block_shortcuts|block_context_menu`),
nên JSON khác trên trang không bị chạm. Ngoài ra dọn luôn `#stream-bootstrap` trong DOM.

### 6. Treo `DisableDevtool`
`DisableDevtool.isSuspend = true` (dùng đúng API của lib) ⇒ hết `history.back()` và hết bị
đá sang `theajack.github.io/disable-devtool/404.html`.

## Nó KHÔNG làm gì (cố ý)

Không chặn/redirect URL · không đụng `performance.now` · không sửa `fetch`,
`innerHTML`, `location`, `history`, `window.open` · không proxy cả cây `Function`.

## Kiểm tra

```js
__liteBlocked     // số timer chứa debugger đã bỏ
__liteSanitized   // số chuỗi chứa debugger đã làm sạch khi biên dịch
__liteConsole     // true = console.clear/table đã vô hiệu
__liteFormatter   // số probe formatter đã nuốt
__liteGuard       // số lần đã bóc browserGuard  (>=1 trên nguonc/streamc là ĐÚNG)
__liteDD          // 1 = đã treo DisableDevtool
```

## Đo (harness)

| Ca | Không shield | Lite 1.3.0 |
|---|---|---|
| timer chứa `debugger` | chạy 120 lần | **0** |
| timer thường | 20 lần | 12 (vẫn chạy) |
| `Function("debugger")` | `{ debugger }` | `{ 0; }` |
| `new AsyncFunction(...)().catch()` | promise | **promise** (awaited 42) |
| `GeneratorFunction("yield 1")` | function | function |
| `#stream-bootstrap` có `browserGuard` | guard chạy | **guard tự tắt** (`__liteGuard=1`) |
| `console.clear()` | xoá console | no-op |
| `devtoolsFormatters.push(probe)` | thêm vào mảng | bị nuốt (`length` vẫn 0) |
| `performance.now` sau stall 200 ms | 200 ms | 200 ms (không sửa) |
| DisableDevtool + kích detector | `history.back()` | ở lại, `isSuspend=true` |

## Cài
1. Gỡ bản cũ (Phantom Shield có panel) để tránh chồng lớp.
2. `chrome://extensions` → Developer mode → Load unpacked → chọn thư mục này.
