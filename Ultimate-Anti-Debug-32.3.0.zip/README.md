# CezDev Phantom Shield — v32.3.0

Bản 32.3.0 sửa lỗi: **chặn cú đá tự động sang `phim.nguonc.com` mà bạn VẪN TỰ MỞ được nó.**
(Giữ nguyên mọi tính năng cũ.)

> **Hai bản trước đó có bug — đọc kỹ mục 2 để biết vì sao.**
> Nếu bạn đang dùng 32.2.0/32.2.1: các bản đó **không chặn được** họ player này.

---

## 1. Vì sao 32.0.0 / 32.1.0 không chặn được (đã đo thật, không đoán)

Player ở `https://api.rophim.stream/player/embed?id=<id>` (site `rophim.soy`) dùng một
họ chống-debug **hoàn toàn khác** họ `streamc/guard-messages` mà bản 32.1.0 nhắm tới.
Không có `streamGuard`, không có `browserGuard`, không có `guard-messages-*.js`.
Vì vậy toàn bộ neutralizer cũ **không có gì để bám vào**.

### 1a. Chuỗi thật

1. `rophim.soy/xem-phim/<slug>.<id>` gọi `GET https://api.rophim.stream/api/v1/player/getLink?movie_id=<id>`
   → `{"status":true,"result":"https://api.rophim.stream/player/embed?id=<id>"}`
   rồi nhét URL đó vào `<iframe id="embed-player">`.
2. Trang `embed` nạp `/jquery.js`, `/core_protect.js`, `/decrypt.js`, `/style.js`, `/player.obf.js`,
   `/sw.js` và một inline script bắt đầu bằng:

   ```js
   (async function(){
     const S = await createShield();
     if (!S.checkEnvironment()) throw 2;
     setInterval(() => {
       if (!S.checkEnvironment()) {
         console.clear();
         try { jwplayer('player').remove(); } catch(e) {}
         window.location.replace('/500');          // ← ĐÁ ĐI
       }
     }, 2000);
     ...
     catch(_){ console.clear(); window.location.replace('/500'); }
   })();
   ```

   ⇒ Mở DevTools là bị đá sang `/500` **trong tối đa 2 giây**. "Bị anti-debug detect" chính là đây.

### 1b. `createShield` nằm trong `/jquery.js` — mà file đó **không phải jQuery**

Nó là một module **Emscripten/WASM**. wasm được nhúng dưới dạng một chuỗi ký tự, làm rối bằng

```js
function binaryDecode(bin){ for(var i=0,l=bin.length,o=new Uint8Array(l),c;i<l;++i){ c=bin.charCodeAt(i); o[i]=~c>>8&c } return o }
```

**Cách lấy wasm ra (đã dùng để phân tích):**

```js
// node: trích literal trong /jquery.js sau `findWasmBinary(){return binaryDecode('`
const lit = "…"                    // chuỗi đã unescape (\r \n \t \\ \xNN)
const core = Buffer.from(lit, 'utf8').toString('utf8');   // charCodeAt theo code point
const wasm = Buffer.from([...core].map(ch => ((~ch.charCodeAt(0)) >> 8) & ch.charCodeAt(0) & 0xff));
// → 12 187 byte, "asm\x01\x00\x00\x00"  ⇒ wasm-dis chạy được
```

Export thật chỉ có **6**, tên bị minify:

| export | nghĩa |
|---|---|
| `o` | `memory` |
| `q` | `__indirect_function_table` |
| `p` | `__wasm_call_ctors` |
| `r` | `___getTypeName` |
| `s` | `_malloc` |
| `t` | `_free` |

`checkEnvironment` **không** phải export của wasm — nó được **embind** đăng ký
(`__embind_register_function`) và trỏ vào một hàm trong bảng hàm (index **2**).

Import của wasm (glue khai `var wasmImports={a:…,g:_emscripten_asm_const_int,h:_emscripten_get_now,…}`):

| key | hàm JS |
|---|---|
| `a`…`f`, `i`…`n` | các `__embind_register_*`, `__abort_js`, `__emscripten_resize_heap` |
| **`g`** | `_emscripten_asm_const_int(code, sigPtr, argbuf)` → `ASM_CONSTS[code]()` |
| **`h`** | `_emscripten_get_now = () => performance.now()` |

### 1c. `ASM_CONSTS` — hai quả bom

```js
var ASM_CONSTS = {
  3316: () => { debugger },                                  // ← câu debugger đã biên dịch sẵn
  3326: () => { window.__NEXT_DATA_RAW__ = "BOMBED";         // ← cờ báo bom
                if (document.body) document.body.innerHTML = "" }   // ← xoá sạch body
};
```

### 1d. Hàm wasm (dịch từ `wat`, func `$21`) — chính là `checkEnvironment`

```wat
(func $21 (result i32)
  (local $0 f64) (local $1 i32)
  (local.set $0 (call $h))                      ;; t0 = performance.now()
  (drop (call $g (i32.const 3316) …))           ;; ASM_CONSTS[3316]()  →  `debugger;`
  (if (local.tee $1
        (f64.gt (f64.sub (call $h) (local.get $0)) (f64.const 100)))   ;; elapsed > 100 ms ?
    (then (drop (call $g (i32.const 3326) …))))  ;;      ⇒ BOM
  (i32.eqz (local.get $1))                      ;; return !(elapsed > 100)
)
```

Nghĩa là:

```
t0 = performance.now();
debugger;                                 // DevTools mở ⇒ dừng ở đây hàng trăm ms
if (performance.now() - t0 > 100) {
    window.__NEXT_DATA_RAW__ = "BOMBED";
    document.body.innerHTML = "";         // xoá sạch DOM
}
return (performance.now() - t0) <= 100;   // false ⇒ trang đá sang /500
```

### 1e. Vì sao các lớp cũ vô dụng với họ này

| Lớp của 32.1.0 | Vì sao không ăn |
|---|---|
| proxy `Function` / `eval` + `sanitize('debugger')` | Chỉ làm sạch chuỗi code **mới đưa vào**. Câu `debugger;` nằm trong `ASM_CONSTS[3316]` — một hàm **đã tạo sẵn, đóng băng**, không đi qua `Function`/`eval` lần nào. |
| vô hiệu `console.debug` | Không liên quan — không có phép dò console nào ở đây. |
| `outerWidth - innerWidth` → `innerWidth` | Không liên quan — không đo bố cục. |
| `MutationObserver` bóc `browserGuard` / `streamGuard` | Sai họ. Trang này **không** dùng `browserGuard`/`streamGuard`. |
| `Location` proxy / chặn `location.replace` | Chrome đánh dấu `Location` là `[LegacyUnforgeable]` ⇒ ghi đè bị bỏ qua. Chỉ `declarativeNetRequest` chặn được — mà `/500` lại **cùng host**, nên DNR theo host cũng không chặn. |
| chống xoá DOM (`innerHTML=''`) | May mắn chặn được dòng `document.body.innerHTML=""`, **nhưng** cờ `__NEXT_DATA_RAW__="BOMBED"` vẫn bị ghi ⇒ nếu trang khác đọc cờ này thì vẫn toi. |

---

## 2. v32.2.3 + v32.3.0 sửa gì

Thêm khối **`1B. WASM-GUARD NEUTRALIZER`** trong `protection.js` (MAIN world, `document_start`,
cùng điều kiện chạy cũ). Bốn lớp, mỗi lớp đủ để không bị detect:

| Lớp | Việc làm |
|---|---|
| **1B-a** | Bọc `WebAssembly.instantiate` / `instantiateStreaming`; với **mọi** hàm import: chuyển tiếp nguyên tham số nhưng **chặn đúng mã `3316` và `3326`** (⇒ `debugger;` và bom không bao giờ chạy). Riêng import đồng hồ (`h`) trỏ về `performance.now()` đã bọc. |
| **1B-b** | **Làm phẳng `performance.now()`**: khi đồng hồ nhảy vọt (`delta > 60 ms` — dấu hiệu vừa bị DevTools dừng ở `debugger;`), giữ giá trị trả về gần như đứng yên ⇒ `elapsed` không thể vượt `100 ms`. |
| **1B-c** | Chặn mọi ghi `window.__NEXT_DATA_RAW__` — luôn giữ rỗng. |
| **1B-d** | Nếu bom đã kịp nổ trước khi extension vào: khôi phục `<body>` từ snapshot (bỏ qua nếu đang có `<video>`/player). |

Kiểm tra bằng console: `__phantomWasmStatus()` → mong đợi
`wasmWrapped: true`, `asmBlocked ≥ 1` hoặc `clockFlattens ≥ 1`, `bombFlagBlocks ≥ 1`.

### 2b. v32.3.0 — Redirect Block theo INITIATOR

Như mục 4b: thêm `initiatorDomains` vào rule DNR để chỉ chặn cú đá **từ player**,
không chặn khi người dùng tự mở. Thêm ô **🎬 Player Hosts** trong popup.
Kiểm chứng: `harness/test_dnr.js` — **12/12 PASS**, gồm ca `initiator` rỗng (tự gõ địa chỉ)
phải CHO QUA và ca sub_frame phải CHẶN.

### 2a. Hai bug thật đã mắc và sửa (đừng tái phạm)

1. **32.2.0 — nhận diện import theo TÊN.** Tên import trong wasm bị **minify**: namespace `"a"`,
   key `"g"`. Nên `/emscripten_asm_const_int$/` **không bao giờ khớp** ⇒ `asmBlocked` mãi `0`,
   lớp quan trọng nhất chết lặng. *Cách sửa:* nhận diện theo **hành vi** (bọc tất cả, chặn theo
   giá trị mã), **không** theo tên.
2. **32.2.1 — nhận diện theo `fn.length` (arity).** `WebAssembly` **không** kiểm tra số tham số
   JS, nên hàm import có thể khai 1 hay 3 tham số tuỳ glue ⇒ `arity === 3` là điều kiện **sai**.
   *Cách sửa:* bỏ hẳn arity, dùng phương án "bọc tất cả + chặn theo mã".

> Ghi chú: đừng kiểm tra wrapper bằng `String(WebAssembly.instantiate)` — extension này **có**
> ghi đè `Function.prototype.toString`, nên `String()` trả về **mã gốc** và bạn sẽ tưởng
> wrapper chưa cài. Hãy kiểm bằng cờ trạng thái (`__phantomWasmStatus()`).

---

## 3. Bằng chứng kiểm thử

### 3a. Harness Node — chạy **ĐÚNG wasm thật** (`harness/harness.js`)

Trích wasm từ `/jquery.js` (mục 1b), gọi hàm bảng index 2, mô phỏng "DevTools mở" bằng cách
chèn 300 ms vào đồng hồ ngay khi `ASM_CONSTS[3316]` chạy:

| Kịch bản | `checkEnvironment()` | Bom | Body |
|---|---|---|---|
| DevTools **đóng** + shield gốc | `1` | không | nguyên vẹn |
| DevTools **MỞ** + shield gốc | **`0`** | **NỔ** | **bị xoá** |
| DevTools **MỞ** + Phantom Shield | **`1`** | không | nguyên vẹn |

### 3b. Browser test — A/B trên cùng một trang, cùng wasm (`test/index.html`)

```sh
cd /var/minis/workspace/anti/test && python3 -m http.server 8791 --bind 127.0.0.1 &
# http://127.0.0.1:8791/index.html
```

| | `checkEnvironment()` ×3 | Bom | `<body>` |
|---|---|---|---|
| **A — không shield** | `[false, false, false]` | **NỔ** | **xoá sạch (0 byte)** |
| **B — shield 32.2.3** | `[true, true, true]` | không | **nguyên vẹn (5 852 byte)** |

`__phantomWasmStatus()` trong ca B: `asmBlocked: 3`, `clockFlattens: 3`, `wasmWrapped: true`
⇒ **cả hai lớp cùng hoạt động**, `debugger;` không bao giờ chạy.

### 3c. Không hồi quy (đã kiểm trong browser sau khi nạp shield)

| Tính năng cũ | Kết quả |
|---|---|
| `new Function('debugger; …')` bị làm sạch & vẫn chạy đúng | ✅ |
| `JSON.parse` bóc `browserGuard` | ✅ |
| `innerHTML = ''` vẫn bị chặn trên `<body>` | ✅ |
| `performance.now()` vẫn đơn điệu & giá trị hợp lý | ✅ |
| Nạp shield trên `https://www.rophim.soy/` (trang thật) | ✅ không lỗi, không tác dụng phụ |

---

## 4. Cách dùng

1. Nạp extension đã giải nén (`chrome://extensions` → Load unpacked).
2. Ô **🚫 Redirect Block List** = `phim.nguonc.com` (để nguyên — xem mục 4b).
3. Ô **🎬 Player Hosts** = để trống thì dùng danh sách mặc định
   (`streamc.xyz`, `api.rophim.stream`, `rophim.soy`…). Thêm host khi gặp player mới.
4. Mở player → mở F12. Trong console của **iframe player**, gõ `__phantomWasmStatus()`:
   mong đợi `wasmWrapped: true` và `asmBlocked ≥ 1`.

### 4b. Vì sao bạn VẪN tự mở được `phim.nguonc.com` (v32.3.0)

**Bug của 32.1.0/32.2.x:** rule DNR chặn theo `requestDomains` + `main_frame` nên nó chặn
**cả khi bạn tự gõ địa chỉ**. Bỏ khỏi danh sách thì mất luôn lớp chặn cú đá tự động — mà lớp JS
(`location.replace`) **không** chặn được, vì Chrome đánh dấu thành viên của `Location` là
`[LegacyUnforgeable]`.

**Cách đúng (32.3.0):** thêm `initiatorDomains` — theo tài liệu Chrome:
*"The rule will only match network requests originating from the list of initiatorDomains."*

| Tình huống | `initiator` | Kết quả |
|---|---|---|
| Player tự đá bạn sang `phim.nguonc.com` | `https://embed11.streamc.xyz/` | **CHẶN** |
| Bạn tự gõ địa chỉ / bookmark / mở tab mới | rỗng | **CHO QUA** |
| Bạn bấm link từ Google | `https://www.google.com/` | **CHO QUA** |
| `phim.nguonc.com` bị nhúng dạng `sub_frame` | bất kỳ | **CHẶN** (bạn không bao giờ "tự gõ" vào iframe) |
| Ảnh / script từ `phim.nguonc.com` | — | **CHO QUA** (không chặn tài nguyên tĩnh) |

Để yên ô **Player Hosts** trống = dùng mặc định. Chỉ khi bạn muốn đá *từ* một host khác
mới cần thêm (ví dụ player mới mà extension chưa biết).

## 5. Giới hạn

- Lớp 1B bám vào **giá trị mã** `3316`/`3326`. Nếu site đổi số hằng, lớp 1B-a sẽ trượt —
  nhưng **lớp 1B-b (làm phẳng đồng hồ) vẫn độc lập và vẫn chặn**, vì nó không quan tâm mã nào.
- Lớp 1B-b chỉ can thiệp khi đồng hồ **nhảy vọt** (đúng lúc DevTools dừng ở `debugger;`),
  nên không ảnh hưởng video/player bình thường.
- `ASM_CONSTS` còn mã khác trong tương lai (ví dụ phép dò bố cục) sẽ cần bổ sung — quy trình
  phân tích đã ghi đầy đủ ở mục 1 để lặp lại nhanh.
- **Cú đá bằng `meta refresh` hoặc điều hướng cấp server** không đi qua `initiator` của trang
  theo cách trên; nếu gặp, thêm host đó vào Player Hosts hoặc dùng `excludedInitiatorDomains`.
- Nếu Chrome của bạn **< 101**, `initiatorDomains` không được hỗ trợ và rule đó sẽ bị bỏ qua
  (Chrome ghi cảnh báo cho extension unpacked). Khi đó bạn sẽ phải chọn: hoặc chặn tất cả
  (như 32.2.x), hoặc không chặn. Chrome 101+ phát hành 04/2022 nên hầu như ai cũng đã có.