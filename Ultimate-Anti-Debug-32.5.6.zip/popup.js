document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.sync.get(['whitelist', 'blockList', 'redirectList', 'redirectBlockList', 'playerHosts', 'masterToggle', 'ddSuspend', 'popupGuard'], (res) => {
        document.getElementById('ddSuspend').checked = res.ddSuspend !== false;
        document.getElementById('popupGuard').checked = res.popupGuard !== false;
        if (res.whitelist) document.getElementById('whitelist').value = res.whitelist.join('\n');
        if (res.blockList) document.getElementById('blockList').value = res.blockList.join('\n');
        if (res.redirectList) document.getElementById('redirectList').value = res.redirectList.join('\n');
        document.getElementById('redirectBlockList').value =
            (res.redirectBlockList && res.redirectBlockList.length ? res.redirectBlockList : ['phim.nguonc.com']).join('\n');
        // Để trống = dùng danh sách mặc định trong background.js
        if (res.playerHosts && res.playerHosts.length) {
            document.getElementById('playerHosts').value = res.playerHosts.join('\n');
        }
        document.getElementById('masterToggle').checked = res.masterToggle !== false; 
    });
});

function cleanDomainInput(text) {
    return text.split('\n')
        .map(line => {
            let clean = line.trim();
            if (!clean) return null;
            try {
                if (clean.includes('://')) return new URL(clean).hostname;
                return clean.split('/')[0].split(':')[0];
            } catch (e) { return clean; }
        })
        .filter(v => v)
        .filter((v, i, a) => a.indexOf(v) === i);
}

document.getElementById('save').addEventListener('click', () => {
    const status = document.getElementById('status');
    const masterToggle = document.getElementById('masterToggle').checked;
    
    const rawWhitelist = document.getElementById('whitelist').value;
    const whitelist = cleanDomainInput(rawWhitelist);
    document.getElementById('whitelist').value = whitelist.join('\n');

    const blockList = document.getElementById('blockList').value
        .split('\n')
        .map(s => s.trim())
        .filter(s => s && !s.startsWith('#'));

    const redirectList = cleanDomainInput(document.getElementById('redirectList').value);
    document.getElementById('redirectList').value = redirectList.join('\n');

    const redirectBlockList = cleanDomainInput(document.getElementById('redirectBlockList').value);
    document.getElementById('redirectBlockList').value = redirectBlockList.join('\n');

    // Để trống => KHÔNG ghi khoá này, background sẽ dùng DEFAULT_PLAYER_HOSTS
    const rawPlayerHosts = document.getElementById('playerHosts').value;
    const playerHosts = cleanDomainInput(rawPlayerHosts);

    const ddSuspend = document.getElementById('ddSuspend').checked;
    const popupGuard = document.getElementById('popupGuard').checked;

    chrome.storage.sync.set({ whitelist, blockList, redirectList, redirectBlockList, playerHosts, masterToggle, ddSuspend, popupGuard }, () => {
        chrome.runtime.sendMessage({ action: "UPDATE_RULES" }, (response) => {
            status.textContent = masterToggle ? '✅ Đã lưu & Kích hoạt!' : '⚠️ Đã lưu (Đang Tắt)';
            status.style.color = masterToggle ? '#27ae60' : '#e67e22';
            setTimeout(() => status.textContent = '', 3000);
        });
    });
});

document.getElementById('masterToggle').addEventListener('change', () => {
    document.getElementById('save').click();
});
