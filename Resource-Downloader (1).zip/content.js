// content.js
(function() {
    const visitedUrls = new Set();
    const resources = [];

    function addResource(url, typeSource = 'unknown') {
        // [FIXED] Kiểm tra null/undefined và đảm bảo url phải là một chuỗi (string)
        // Xử lý cả trường hợp SVGAnimatedString (có thuộc tính baseVal)
        if (typeof url === 'object' && url !== null && url.baseVal) {
            url = url.baseVal;
        }
        
        if (!url || typeof url !== 'string') return;
        
        if (url.startsWith('data:') || url.startsWith('chrome-extension:')) return;
        
        try {
            const absoluteUrl = new URL(url, document.baseURI).href;
            if (visitedUrls.has(absoluteUrl)) return;
            visitedUrls.add(absoluteUrl);
            
            let ext = absoluteUrl.split('.').pop().split(/[?#]/)[0].toLowerCase();
            let finalType = typeSource;
            if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'ico'].includes(ext)) finalType = 'img';
            if (['css'].includes(ext)) finalType = 'css';
            if (['js'].includes(ext)) finalType = 'js';

            resources.push({
                url: absoluteUrl,
                filename: absoluteUrl.substring(absoluteUrl.lastIndexOf('/') + 1).split('?')[0] || 'index.html',
                path: new URL(absoluteUrl).pathname,
                type: finalType
            });
        } catch (e) {
            // Ignore các URL bị lỗi format (vd: javascript:void(0))
        }
    }

    // 1. Quét Performance API
    performance.getEntriesByType("resource").forEach(e => addResource(e.name, e.initiatorType));

    // 2. Quét DOM cơ bản
    document.querySelectorAll('[src], [href], [srcset]').forEach(el => {
        if (el.src) addResource(el.src);
        if (el.href) addResource(el.href);
        if (el.srcset) el.srcset.split(',').forEach(s => addResource(s.trim().split(' ')[0]));
    });

    // 3. Quét TreeWalker (Styles ẩn & Data-Attributes)
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null, false);
    let node = walker.currentNode;
    while (node) {
        const bg = window.getComputedStyle(node).getPropertyValue('background-image');
        if (bg && bg.includes('url(')) {
            const urls = bg.match(/url\(['"]?(.*?)['"]?\)/g);
            if (urls) urls.forEach(u => addResource(u.replace(/^url\(['"]?/, '').replace(/['"]?\)$/, '')));
        }
        Array.from(node.attributes).forEach(attr => {
            if (attr.name.startsWith('data-') && attr.value.match(/^https?:\/\//)) addResource(attr.value);
        });
        node = walker.nextNode();
    }

    // 4. Quét CSSOM (Đọc xuyên qua các file CSS nhúng ngoài)
    try {
        Array.from(document.styleSheets).forEach(sheet => {
            try {
                Array.from(sheet.cssRules).forEach(rule => {
                    if (rule.style && rule.style.backgroundImage) {
                        const bg = rule.style.backgroundImage;
                        if (bg.includes('url(')) {
                            const urls = bg.match(/url\(['"]?(.*?)['"]?\)/g);
                            if (urls) urls.forEach(u => addResource(u.replace(/^url\(['"]?/, '').replace(/['"]?\)$/, '')));
                        }
                    }
                });
            } catch(e) {} 
        });
    } catch(e) {}

    return resources;
})();