// popup.js
let allResources = [];
let currentTabUrl = "";

document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ action: "getDownloadState" }, (res) => {
        if (res && res.isDownloading) lockUI(res.currentStatus);
    });

    scanCurrentPage();
    setupEventHandlers();
});

// Hàm hỗ trợ gửi Message có retry để chống lỗi Deadlock Service Worker
async function sendMsgWithRetry(message, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            return await new Promise((resolve, reject) => {
                chrome.runtime.sendMessage(message, (response) => {
                    if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
                    resolve(response);
                });
            });
        } catch (e) {
            if (i === retries - 1) console.error("SW Wakeup failed:", e.message);
            await new Promise(res => setTimeout(res, 500)); // Đợi 500ms rồi thử lại
        }
    }
}

// Hàm khởi tạo tải xuống (Hỗ trợ tải trực tiếp nếu chỉ có 1 file)
async function triggerDownload(files, zipNameHint, useTree) {
    if (!files || files.length === 0) return updateStatus("No files selected.");
    
    // Tải trực tiếp không cần ZIP nếu chỉ 1 file
    if (files.length === 1) {
        chrome.downloads.download({ url: files[0].url, saveAs: true });
        return updateStatus(`Downloading ${files[0].filename}...`);
    }

    lockUI("Preparing batch data...");
    
    // Lưu mảng file vào storage để tránh tràn RAM khi truyền qua Message
    await chrome.storage.local.set({ 'downloadQueue': files });

    const response = await sendMsgWithRetry({
        action: "startDownload",
        payload: { zipNameHint: zipNameHint, useTree: useTree }
    });

    if (response && !response.success) {
        unlockUI("Download failed to start or already running.");
    }
}

function setupEventHandlers() {
    document.getElementById('btnAll').onclick = () => toggleCheckboxes(true);
    document.getElementById('btnNone').onclick = () => toggleCheckboxes(false);
    
    document.getElementById('btnImg').onclick = () => toggleByType('img');
    document.getElementById('btnCss').onclick = () => toggleByType('css');
    document.getElementById('btnJs').onclick = () => toggleByType('js');
    
    const btnMap = document.getElementById('btnMap');
    if (btnMap) btnMap.onclick = () => toggleByType('map');
    
    document.getElementById('btnDownload').onclick = () => {
        const checkedFiles = getCheckedFiles();
        const useTree = document.getElementById('chkTreeStructure').checked;
        
        let mainDomain = "Source_Files";
        try { if (currentTabUrl) mainDomain = new URL(currentTabUrl).hostname; } catch(e) {}

        triggerDownload(checkedFiles, mainDomain, useTree);
    };
}

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "popupUpdate") {
        updateStatus(request.status);
        if (!request.isDownloading) unlockUI();
    }
});

function lockUI(msg) {
    document.getElementById('btnDownload').disabled = true;
    document.getElementById('btnDownload').style.opacity = '0.5';
    if (msg) updateStatus(msg);
}

function unlockUI(msg) {
    document.getElementById('btnDownload').disabled = false;
    document.getElementById('btnDownload').style.opacity = '1';
    if (msg) updateStatus(msg);
}

// --- TÌM SOURCE MAPS ---
async function findSourceMaps(resources) {
    updateStatus("Extracting Source Maps...");
    const targetFiles = resources.filter(r => r.type === 'js' || r.type === 'css');
    const mapResources = [];
    const urlSet = new Set(resources.map(r => r.url));
    let idCounter = resources.length; 

    const mapRegex = /(?:\/\/[@#][ \t]+sourceMappingURL=([^\s'"]+?)[ \t]*$)|(?:\/\*[@#][ \t]+sourceMappingURL=([^\*]+?)[ \t]*(?:\*\/)[ \t]*$)/m;

    await Promise.allSettled(targetFiles.map(async (file) => {
        try {
            const response = await fetch(file.url, { credentials: 'omit' });
            if (!response.ok) return;
            
            const text = await response.text();
            const match = text.match(mapRegex);
            
            if (match) {
                const mapUrlRaw = match[1] || match[2];
                const absoluteMapUrl = new URL(mapUrlRaw, file.url).href;
                
                if (!urlSet.has(absoluteMapUrl)) {
                    urlSet.add(absoluteMapUrl);
                    mapResources.push({
                        id: idCounter++,
                        url: absoluteMapUrl,
                        filename: absoluteMapUrl.split('/').pop().split(/[?#]/)[0] || 'unknown.map',
                        path: file.path, 
                        type: 'map'
                    });
                }
            }
        } catch (e) {}
    }));

    return mapResources;
}

// --- SCANNING ---
async function scanCurrentPage() {
    updateStatus("Scanning Network & DOM...");
    try {
        let tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs || tabs.length === 0) tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        
        const tab = tabs[0];
        if (!tab || !tab.id) throw new Error("Cannot detect active tab.");
        currentTabUrl = tab.url || "";

        // [FIXED] Kiểm tra URL có bị cấm nhúng Script hay không
        const isRestrictedUrl = currentTabUrl.startsWith('chrome://') || 
                                currentTabUrl.startsWith('chrome-extension://') || 
                                currentTabUrl.startsWith('edge://') || 
                                currentTabUrl.startsWith('about:');

        if (isRestrictedUrl) {
            updateStatus("System page detected. DOM scan disabled.");
        }

        sendMsgWithRetry({ action: "setReferer", referer: currentTabUrl });

        // Chỉ thực thi content.js nếu không phải trang hệ thống
        let domScanPromise = Promise.resolve([]);
        if (!isRestrictedUrl) {
            domScanPromise = chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                files: ['content.js']
            }).catch(e => {
                console.warn("DOM Scan Skipped:", e.message);
                return [];
            });
        }

        const [netRes, domResults] = await Promise.all([
            sendMsgWithRetry({ action: "getNetworkResources", tabId: tab.id }),
            domScanPromise
        ]);

        const networkItems = netRes?.resources || [];
        let domItems = [];
        if (domResults) domResults.forEach(f => { if (f.result) domItems = domItems.concat(f.result); });

        const urlSet = new Set();
        allResources = [];
        let idCounter = 0;

        const processItem = (item) => {
            if (!item || !item.url || item.url.startsWith('data:') || item.url.startsWith('chrome-extension:')) return;
            if (urlSet.has(item.url)) return;
            urlSet.add(item.url);

            let filename = item.filename || 'unknown';
            let path = item.path || '/';
            if (filename === 'unknown') {
                try {
                    const u = new URL(item.url);
                    filename = u.pathname.substring(u.pathname.lastIndexOf('/') + 1) || 'index.html';
                    path = u.pathname;
                } catch(e){}
            }

            let type = item.type || 'other';
            if (['image'].includes(type)) type = 'img';
            if (['stylesheet'].includes(type)) type = 'css';
            if (['script'].includes(type)) type = 'js';

            allResources.push({ id: idCounter++, url: item.url, filename, path, type });
        };

        networkItems.forEach(processItem);
        domItems.forEach(processItem);

        if (allResources.length > 0) {
            renderDomainTree(allResources);
            updateStatus(`Found ${allResources.length} files. Checking Source Maps...`);

            findSourceMaps(allResources).then(mapFiles => {
                if (mapFiles && mapFiles.length > 0) {
                    allResources = allResources.concat(mapFiles);
                    renderDomainTree(allResources); 
                    updateStatus(`Found ${allResources.length} files (Included Maps).`);
                } else {
                    updateStatus(`Found ${allResources.length} files.`);
                }
            });
        } else {
            document.getElementById('tree-container').innerHTML = '<div style="padding:10px">No resources found.</div>';
            updateStatus("Empty.");
        }
    } catch (e) {
        document.getElementById('tree-container').innerHTML = `<div style="color:#d00; padding:10px;">Error: ${e.message}</div>`;
        updateStatus("Failed.");
    }
}

// --- RENDER GIAO DIỆN ---
function renderDomainTree(resources) {
    const container = document.getElementById('tree-container');
    container.innerHTML = '';
    const domains = {};
    
    resources.forEach(res => {
        let domain = 'unknown';
        try { domain = new URL(res.url).hostname; } catch (e) {}
        if (!domains[domain]) domains[domain] = [];
        domains[domain].push(res);
    });

    Object.keys(domains).sort().forEach(domain => {
        const domainFiles = domains[domain];
        const domainDiv = document.createElement('div');
        domainDiv.className = 'domain-group';

        const header = document.createElement('div');
        header.className = 'domain-header';
        header.innerHTML = `<div><span class="domain-title">${domain}</span> <span class="domain-count">(${domainFiles.length})</span></div>`;
        
        const btnDomainDL = createMiniDownloadBtn(() => {
            triggerDownload(domainFiles, domain, document.getElementById('chkTreeStructure').checked);
        });

        header.appendChild(btnDomainDL);
        domainDiv.appendChild(header);

        const rootNode = buildTreeStructure(domainFiles);
        const treeUl = buildHtmlList(rootNode);
        treeUl.style.padding = "5px";
        
        domainDiv.appendChild(treeUl);
        container.appendChild(domainDiv);
    });
}

function buildTreeStructure(files) {
    const root = {};
    files.forEach((res) => {
        const parts = res.path.split('/').filter(p => p);
        if (parts.length === 0) parts.push(res.filename);
        let currentLevel = root;
        parts.forEach((part, idx) => {
            if (idx === parts.length - 1) {
                if (!currentLevel._files) currentLevel._files = [];
                currentLevel._files.push(res);
            } else {
                if (!currentLevel[part]) currentLevel[part] = {};
                currentLevel = currentLevel[part];
            }
        });
    });
    return root;
}

function buildHtmlList(node, level = 0) {
    const ul = document.createElement('ul');
    if (level === 0) { ul.style.paddingLeft = '5px'; ul.style.borderLeft = 'none'; }

    Object.keys(node).forEach(key => {
        if (key === '_files') return;
        const li = document.createElement('li');
        const divRow = document.createElement('div');
        
        const spanIcon = document.createElement('span'); spanIcon.textContent = '📂 ';
        const spanName = document.createElement('span'); spanName.className = 'folder'; spanName.textContent = key;
        const spacer = document.createElement('span'); spacer.className = 'spacer';

        const btnFolderDL = createMiniDownloadBtn(() => {
            triggerDownload(collectFilesFromNode(node[key]), key, document.getElementById('chkTreeStructure').checked);
        });

        divRow.append(spanIcon, spanName, spacer, btnFolderDL);
        li.appendChild(divRow);
        
        const subUl = buildHtmlList(node[key], level + 1);
        subUl.style.display = 'block'; 
        spanName.onclick = () => {
            const isHidden = subUl.style.display === 'none';
            subUl.style.display = isHidden ? 'block' : 'none';
            spanIcon.textContent = isHidden ? '📂 ' : '📁 ';
        };
        li.appendChild(subUl);
        ul.appendChild(li);
    });

    if (node._files) {
        node._files.forEach(file => {
            const li = document.createElement('li'); li.className = 'file';
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox'; checkbox.value = file.id; checkbox.dataset.type = file.type;
            
            const label = document.createElement('span'); label.className = 'filename';
            label.textContent = file.filename; label.title = file.url;
            
            if (file.type === 'map') {
                label.style.color = '#d9534f';
                label.style.fontWeight = 'bold';
            }

            label.onclick = () => { checkbox.checked = !checkbox.checked; };

            const spacer = document.createElement('span'); spacer.className = 'spacer';
            
            const btnFileDL = createMiniDownloadBtn(() => {
                triggerDownload([file], "Single_File", false);
            });

            li.append(checkbox, label, spacer, btnFileDL);
            ul.appendChild(li);
        });
    }
    return ul;
}

// --- HELPER FUNCTIONS ---
function createMiniDownloadBtn(action) {
    const btn = document.createElement('button');
    btn.className = 'btn-mini-download'; btn.textContent = '⬇';
    btn.onclick = (e) => { e.stopPropagation(); action(); };
    return btn;
}

function collectFilesFromNode(node) {
    let files = [];
    if (node._files) files = files.concat(node._files);
    Object.keys(node).forEach(key => {
        if (key !== '_files') files = files.concat(collectFilesFromNode(node[key]));
    });
    return files;
}

function getCheckedFiles() {
    const cbs = Array.from(document.querySelectorAll('#tree-container input[type="checkbox"]:checked'));
    const ids = cbs.map(cb => parseInt(cb.value));
    return allResources.filter(r => r && typeof r.id !== 'undefined' && ids.includes(r.id));
}

function toggleCheckboxes(state) { document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => cb.checked = state); }
function toggleByType(type) { document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => cb.checked = (cb.dataset.type === type)); }
function updateStatus(msg) { document.getElementById('status').textContent = msg; }