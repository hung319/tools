// offscreen.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "runOffscreenZip") {
        handleBackgroundDownload(request.payload.zipNameHint, request.payload.useTree);
    }
});

function reportProgress(msg, done = false) {
    chrome.runtime.sendMessage({ action: "updateProgress", status: msg, done: done });
}

async function handleBackgroundDownload(zipNameHint, useTree) {
    try {
        // [MỚI] Nhờ Background lấy mảng files từ Storage
        const response = await chrome.runtime.sendMessage({ action: "getStorageData" });
        const files = response.files;

        if (!files || files.length === 0) {
            throw new Error("Không tìm thấy dữ liệu tải xuống trong kho lưu trữ.");
        }

        const opfsRoot = await navigator.storage.getDirectory();
        const batchId = `DL_${Date.now()}`;
        const tempDir = await opfsRoot.getDirectoryHandle(batchId, { create: true });
        
        let successCount = 0;
        let failCount = 0;
        let errorLogs = []; 
        
        reportProgress("Phase 1: Concurrent Download & Stream to Virtual Disk...");

        // ---------------------------------------------------------
        // GIAI ĐOẠN 1: Tải file (Worker Pool - Max 5 Concurrent)
        // ---------------------------------------------------------
        const MAX_CONCURRENT = 5;
        let currentIndex = 0;

        async function processFile(file) {
            try {
                // Mang theo cookies để bypass Auth/CORS
                const response = await fetch(file.url, { credentials: 'include' });
                if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);

                // Detect Content-Type nếu file mất đuôi
                let filename = file.filename;
                const contentType = response.headers.get('content-type');
                if (contentType && !filename.includes('.')) {
                    const extMap = {
                        'image/jpeg': '.jpg', 'image/png': '.png', 'image/gif': '.gif', 'image/webp': '.webp',
                        'text/css': '.css', 'application/javascript': '.js', 'text/javascript': '.js'
                    };
                    const mappedExt = extMap[contentType.split(';')[0].trim()];
                    if (mappedExt) filename += mappedExt;
                    file.filename = filename; // Cập nhật lại filename để ZIP dùng
                }

                // Xử lý tạo thư mục con trong OPFS nếu user chọn "Keep structure"
                let targetDir = tempDir;
                if (useTree && file.path) {
                    const parts = file.path.split('/').filter(p => p && !p.includes('.'));
                    for (const part of parts) {
                        targetDir = await targetDir.getDirectoryHandle(part, { create: true });
                    }
                }

                const opfsFileHandle = await targetDir.getFileHandle(filename, { create: true });
                const writable = await opfsFileHandle.createWritable();
                await response.body.pipeTo(writable);
                
                successCount++;
            } catch (e) {
                failCount++;
                const timestamp = new Date().toISOString();
                errorLogs.push(`[${timestamp}] FAILED: ${file.url}\n -> Reason: ${e.message}\n`);
            }
        }

        const workers = Array(MAX_CONCURRENT).fill(null).map(async () => {
            while (currentIndex < files.length) {
                const file = files[currentIndex++];
                await processFile(file);
                
                if (currentIndex % 5 === 0 || currentIndex === files.length) {
                    reportProgress(`Downloading: ${successCount + failCount}/${files.length}`);
                }
            }
        });

        await Promise.all(workers);

        if (successCount === 0) throw new Error("All downloads failed.");

        // ---------------------------------------------------------
        // GIAI ĐOẠN 2: Nén ZIP
        // ---------------------------------------------------------
        reportProgress(`Phase 2: Zipping ${successCount} files...`);
        
        const safeHint = zipNameHint.replace(/[^a-z0-9\._-]/gi, '_');
        const finalZipName = `${safeHint}_${batchId}.zip`;
        const zipFileHandle = await opfsRoot.getFileHandle(finalZipName, { create: true });
        const zipWritable = await zipFileHandle.createWritable();

        let writePromise = Promise.resolve();
        
        const zip = new fflate.Zip((err, chunk, final) => {
            if (err) errorLogs.push(`[ZIP ERROR] ${err.message}`);
            if (chunk && chunk.length > 0) {
                writePromise = writePromise.then(() => zipWritable.write(chunk));
            }
            if (final) {
                writePromise = writePromise.then(() => zipWritable.close());
            }
        });

        for (const file of files) {
            try {
                // Tìm lại thư mục đã lưu file trên OPFS
                let targetDir = tempDir;
                if (useTree && file.path) {
                    const parts = file.path.split('/').filter(p => p && !p.includes('.'));
                    for (const part of parts) {
                        targetDir = await targetDir.getDirectoryHandle(part);
                    }
                }

                const opfsFileHandle = await targetDir.getFileHandle(file.filename);
                const opfsFile = await opfsFileHandle.getFile(); 
                
                let domain = 'unknown_domain';
                try { domain = new URL(file.url).hostname; } catch(e) {}

                let relativePath = (useTree && file.path && file.path.startsWith('/')) ? file.path.slice(1) : file.filename;
                relativePath = `${domain}/${relativePath}`;

                const zipPassThrough = new fflate.ZipPassThrough(relativePath);
                zip.add(zipPassThrough);

                const reader = opfsFile.stream().getReader();
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        zipPassThrough.push(new Uint8Array(0), true); 
                        break;
                    }
                    zipPassThrough.push(value); 
                    await writePromise; 
                }
            } catch (e) {
                // Ignore file lỗi không tồn tại
            }
        }

        if (errorLogs.length > 0) {
            errorLogs.unshift(`=== DOWNLOAD ERROR LOG (${safeHint}) ===\nTotal failed: ${failCount}\n======================================\n\n`);
            const logContent = errorLogs.join('\n');
            const logBytes = new TextEncoder().encode(logContent);
            const logPassThrough = new fflate.ZipPassThrough('error.log');
            zip.add(logPassThrough);
            logPassThrough.push(logBytes, true);
            await writePromise;
        }
        
        zip.end();
        await writePromise;

        // ---------------------------------------------------------
        // GIAI ĐOẠN 3: Xuất file
        // ---------------------------------------------------------
        reportProgress("Phase 3: Exporting file...", true);
        
        const finalFile = await zipFileHandle.getFile();
        const blobUrl = URL.createObjectURL(finalFile);
        
        chrome.runtime.sendMessage({
            action: "triggerFinalDownload",
            url: blobUrl,
            filename: finalZipName,
            batchId: batchId
        });

    } catch (error) {
        reportProgress(`Error: ${error.message}`, true);
        setTimeout(() => window.close(), 3000);
    }
}