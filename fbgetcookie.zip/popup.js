document.addEventListener('DOMContentLoaded', () => {
    const uidDisplay = document.getElementById('uid-display');
    const cookieTextarea = document.getElementById('cookie-textarea');
    const copyBtn = document.getElementById('copy-btn');
    const clearBtn = document.getElementById('clear-btn');
    const savedCookiesList = document.getElementById('saved-cookies-list');

    const FACEBOOK_URL = "https://www.facebook.com";

    // Hàm chính: Lấy cookie hiện tại và hiển thị
    async function getCurrentCookie() {
        try {
            const cookies = await chrome.cookies.getAll({ domain: "facebook.com" });

            if (cookies.length === 0) {
                uidDisplay.textContent = 'Not logged in';
                cookieTextarea.value = '';
                return;
            }
            
            // Tìm cookie 'c_user' để lấy UID
            const uidCookie = cookies.find(cookie => cookie.name === 'c_user');
            if (!uidCookie) {
                uidDisplay.textContent = 'UID not found';
                cookieTextarea.value = '';
                return;
            }

            const uid = uidCookie.value;
            uidDisplay.textContent = uid;

            // Chuyển đổi mảng cookie thành chuỗi string chuẩn
            const cookieString = cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
            cookieTextarea.value = cookieString;

            // Tự động lưu cookie mới lấy được
            await saveCookie(uid, cookieString);
        } catch (error) {
            console.error('Error getting cookies:', error);
            uidDisplay.textContent = 'Error';
        }
    }

    // Hàm lưu cookie vào chrome.storage
    async function saveCookie(uid, cookieString) {
        const { savedCookies = [] } = await chrome.storage.local.get('savedCookies');
        
        // Kiểm tra xem UID đã tồn tại chưa, nếu rồi thì không lưu trùng
        const existingCookieIndex = savedCookies.findIndex(c => c.uid === uid);

        if (existingCookieIndex === -1) {
            savedCookies.push({ uid, cookie: cookieString });
            await chrome.storage.local.set({ savedCookies });
            displaySavedCookies(); // Cập nhật lại danh sách hiển thị
        }
    }

    // Hàm hiển thị danh sách các cookie đã lưu
    async function displaySavedCookies() {
        const { savedCookies = [] } = await chrome.storage.local.get('savedCookies');
        savedCookiesList.innerHTML = ''; // Xóa danh sách cũ

        savedCookies.forEach((saved, index) => {
            const listItem = document.createElement('li');
            listItem.dataset.index = index; // Lưu index để xử lý sự kiện
            
            const uidInfo = document.createElement('span');
            uidInfo.className = 'uid-info';
            uidInfo.textContent = `${index + 1}. UID: ${saved.uid}`;
            
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-cookie-btn';
            deleteBtn.textContent = 'Delete';
            deleteBtn.dataset.index = index;

            listItem.appendChild(uidInfo);
            listItem.appendChild(deleteBtn);
            savedCookiesList.appendChild(listItem);
        });
    }

    // Hàm xóa toàn bộ cookie của Facebook trên trình duyệt
    async function clearBrowserCookies() {
        try {
            const cookies = await chrome.cookies.getAll({ domain: "facebook.com" });
            // Promise.all để đảm bảo tất cả các thao tác xóa đều hoàn tất
            await Promise.all(
                cookies.map(cookie => {
                    const url = `https://${cookie.domain.replace(/^\./, '')}${cookie.path}`;
                    return chrome.cookies.remove({ url: url, name: cookie.name });
                })
            );
            // Cập nhật lại UI sau khi xóa
            uidDisplay.textContent = 'Logged Out';
            cookieTextarea.value = '';
        } catch (error) {
            console.error('Error clearing cookies:', error);
        }
    }

    // Hàm set cookie mới vào trình duyệt
    async function setBrowserCookies(cookieString) {
        const cookies = cookieString.split(';').map(c => c.trim());
        const domain = ".facebook.com";

        await Promise.all(
            cookies.map(cookie => {
                const parts = cookie.split('=');
                if (parts.length < 2) return Promise.resolve();
                const name = parts.shift();
                const value = parts.join('=');
                
                return chrome.cookies.set({
                    url: FACEBOOK_URL,
                    name: name,
                    value: value,
                    domain: domain,
                    path: '/',
                    secure: true,
                    httpOnly: (name === 'datr' || name === 'sb'), // Một số cookie quan trọng là httpOnly
                    expirationDate: Math.floor(Date.now() / 1000) + (365 * 24 * 60 * 60) // Hết hạn sau 1 năm
                });
            })
        );
    }

    // Gán sự kiện cho các nút
    copyBtn.addEventListener('click', async () => {
    const cookieValue = cookieTextarea.value;
    if (!cookieValue) return; // Không làm gì nếu textarea rỗng

    try {
        await navigator.clipboard.writeText(cookieValue);
        copyBtn.textContent = 'Copied!';
    } catch (err) {
        console.error('Failed to copy: ', err);
        copyBtn.textContent = 'Error!';
    } finally {
        setTimeout(() => { copyBtn.textContent = 'Copy Cookie'; }, 2000);
    }
});

    clearBtn.addEventListener('click', async () => {
        await clearBrowserCookies();
        alert('Facebook cookies cleared. You are now logged out.');
    });

    // Xử lý sự kiện click trên danh sách cookie đã lưu
    savedCookiesList.addEventListener('click', async (event) => {
        const target = event.target;
        const index = target.dataset.index;

        if (index === undefined) return;
        
        const { savedCookies = [] } = await chrome.storage.local.get('savedCookies');

        // Nếu click vào nút Delete
        if (target.classList.contains('delete-cookie-btn')) {
            event.stopPropagation(); // Ngăn sự kiện click vào cả thẻ li
            savedCookies.splice(index, 1);
            await chrome.storage.local.set({ savedCookies });
            displaySavedCookies(); // Cập nhật lại danh sách
            return;
        }

        // Nếu click vào thẻ li để đăng nhập
        const selectedCookie = savedCookies[index];
        if (selectedCookie) {
            console.log(`Applying cookie for UID: ${selectedCookie.uid}`);
            await clearBrowserCookies(); // Xóa cookie cũ
            await setBrowserCookies(selectedCookie.cookie); // Set cookie mới
            
            // Reload lại tab Facebook đang mở
            const [tab] = await chrome.tabs.query({ active: true, url: "*://*.facebook.com/*" });
            if (tab) {
                chrome.tabs.reload(tab.id);
            } else {
                // Nếu không có tab fb nào, mở tab mới
                chrome.tabs.create({ url: FACEBOOK_URL });
            }
            window.close(); // Đóng popup
        }
    });

    // Chạy các hàm khởi tạo khi mở popup
    getCurrentCookie();
    displaySavedCookies();
});