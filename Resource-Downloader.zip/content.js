// content.js
(function() {
    // Set dùng để lọc trùng lặp URL ngay lập tức
    const visitedUrls = new Set();
    const resources = [];

    // Hàm helper: Lấy tên file từ URL
    function getFilenameFromUrl(url) {
        try {
            const urlObj = new URL(url);
            const path = urlObj.pathname;
            const name = path.substring(path.lastIndexOf('/') + 1);
            // Nếu không có tên file (vd: url kết thúc bằng /), lấy tên mặc định
            return name || 'index.html';
        } catch (e) {
            return 'unknown_file';
        }
    }

    // Hàm helper: Xác định loại file (img, css, js, other)
    function getFileType(url, initiatorType) {
        const ext = url.split('.').pop().split(/[?#]/)[0].toLowerCase();
        
        if (['jpg', 'jpeg', 'png', 'gif', 'svg', 'webp', 'ico', 'bmp'].includes(ext)) return 'img';
        if (['css', 'scss', 'less'].includes(ext)) return 'css';
        if (['js', 'jsx', 'ts', 'tsx', 'json', 'map'].includes(ext)) return 'js';
        if (['mp4', 'webm', 'ogg', 'mp3', 'wav'].includes(ext)) return 'media';
        
        // Nếu không có đuôi file rõ ràng, dựa vào initiatorType của browser
        if (initiatorType === 'script') return 'js';
        if (initiatorType === 'css' || initiatorType === 'link') return 'css';
        if (initiatorType === 'img' || initiatorType === 'image') return 'img';
        
        return 'other';
    }

    // Hàm thêm resource vào danh sách
    function addResource(url, typeSource = 'unknown') {
        // Chuẩn hóa URL
        if (!url || url.startsWith('data:') || url.startsWith('blob:') || url.startsWith('chrome-extension:')) return;
        
        try {
            // Chuyển relative path thành absolute
            const absoluteUrl = new URL(url, document.baseURI).href;
            
            if (visitedUrls.has(absoluteUrl)) return;
            visitedUrls.add(absoluteUrl);

            const urlObj = new URL(absoluteUrl);
            const type = getFileType(absoluteUrl, typeSource);

            resources.push({
                url: absoluteUrl,
                filename: getFilenameFromUrl(absoluteUrl),
                path: urlObj.pathname, // Giữ đường dẫn thư mục ảo
                type: type
            });
        } catch (e) {
            // Bỏ qua url lỗi
        }
    }

    // --- CẤP ĐỘ 1: Performance API (Mạnh nhất - Bắt dynamic chunks) ---
    // API này chứa danh sách mọi thứ browser đã tải về (giống tab Network)
    const perfEntries = performance.getEntriesByType("resource");
    perfEntries.forEach(entry => {
        addResource(entry.name, entry.initiatorType);
    });

    // --- CẤP ĐỘ 2: DOM Scanning (Bổ sung những gì Performance có thể sót) ---
    const elements = document.querySelectorAll('img, script, link[rel="stylesheet"], source, video, audio, object');
    elements.forEach(el => {
        if (el.src) addResource(el.src, el.tagName.toLowerCase());
        if (el.href) addResource(el.href, el.tagName.toLowerCase() === 'link' ? 'css' : 'other');
        if (el.srcset) {
            // Xử lý srcset="img1.jpg 1x, img2.jpg 2x"
            el.srcset.split(',').forEach(srcPart => {
                const url = srcPart.trim().split(' ')[0];
                addResource(url, 'img');
            });
        }
    });

    // --- CẤP ĐỘ 3: CSS Computed Style (Bắt ảnh background) ---
    // Quét tất cả thẻ div, span, section... xem có background-image không
    // Lưu ý: Quét toàn bộ DOM có thể hơi nặng, nên ta giới hạn quét body và các div chính thôi
    const allNodes = document.querySelectorAll('*');
    allNodes.forEach(node => {
        const bgImage = window.getComputedStyle(node).backgroundImage;
        if (bgImage && bgImage !== 'none' && bgImage.startsWith('url(')) {
            // Clean string: url("http://...") -> http://...
            const cleanUrl = bgImage.slice(4, -1).replace(/["']/g, "");
            addResource(cleanUrl, 'img');
        }
    });

    // Trả kết quả về cho Popup
    return resources;
})();