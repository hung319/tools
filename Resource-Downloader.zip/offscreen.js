// offscreen.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "runOffscreenZip") {
        handleBackgroundDownload(request.payload.files, request.payload.zipNameHint, request.payload.useTree);
    }
});

function reportProgress(msg, done = false) {
    chrome.runtime.sendMessage({ action: "updateProgress", status: msg, done: done });
}

async function handleBackgroundDownload(files, zipNameHint, useTree) {
    try {
        const opfsRoot = await navigator.storage.getDirectory();
        const batchId = `DL_${Date.now()}`;
        const tempDir = await opfsRoot.getDirectoryHandle(batchId, { create: true });
        
        let successCount = 0;
        let failCount = 0;
        // --- MẢNG LƯU TRỮ LOG LỖI ---
        let errorLogs = []; 
        
        reportProgress("Phase 1: Streaming files to Virtual Disk...");

        // ---------------------------------------------------------
        // GIAI ĐOẠN 1: Tải file
        // ---------------------------------------------------------
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            try {
                const response = await fetch(file.url, { credentials: 'omit' });
                if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);

                const opfsFileHandle = await tempDir.getFileHandle(file.filename, { create: true });
                const writable = await opfsFileHandle.createWritable();

                await response.body.pipeTo(writable);
                successCount++;
                reportProgress(`Downloading: ${successCount + failCount}/${files.length}`);
            } catch (e) {
                failCount++;
                // Lưu im lặng vào mảng thay vì văng lỗi ra Console
                const timestamp = new Date().toISOString();
                errorLogs.push(`[${timestamp}] FAILED: ${file.url}\n -> Reason: ${e.message}\n`);
            }
        }

        if (successCount === 0) throw new Error("All downloads failed.");

        // ---------------------------------------------------------
        // GIAI ĐOẠN 2: Nén ZIP
        // ---------------------------------------------------------
        reportProgress(`Phase 2: Zipping ${successCount} files...`);
        
        const safeHint = zipNameHint.replace(/[^a-z0-9\._-]/gi, '_');
        const finalZipName = `${safeHint}_${batchId}.zip`;
        const zipFileHandle = await opfsRoot.getFileHandle(finalZipName, { create: true });
        const zipWritable = await zipFileHandle.createWritable();

        let writePromise = Promise.resolve();
        
        const zip = new fflate.Zip((err, chunk, final) => {
            if (err) errorLogs.push(`[ZIP ERROR] ${err.message}`);
            if (chunk && chunk.length > 0) {
                writePromise = writePromise.then(() => zipWritable.write(chunk));
            }
            if (final) {
                writePromise = writePromise.then(() => zipWritable.close());
            }
        });

        for (const file of files) {
            try {
                const opfsFileHandle = await tempDir.getFileHandle(file.filename);
                const opfsFile = await opfsFileHandle.getFile(); 
                
                let domain = 'unknown_domain';
                try { domain = new URL(file.url).hostname; } catch(e) {}

                let relativePath = (useTree && file.path && file.path.startsWith('/')) ? file.path.slice(1) : file.filename;
                relativePath = `${domain}/${relativePath}`;

                const zipPassThrough = new fflate.ZipPassThrough(relativePath);
                zip.add(zipPassThrough);

                const reader = opfsFile.stream().getReader();
                while (true) {
                    const { done, value } = await reader.read();
                    if (done) {
                        zipPassThrough.push(new Uint8Array(0), true); 
                        break;
                    }
                    zipPassThrough.push(value); 
                    await writePromise; 
                }
            } catch (e) {
                // Ignore file mapping errors
            }
        }

        // --- TẠO VÀ NHÉT FILE ERROR.LOG VÀO ZIP ---
        if (errorLogs.length > 0) {
            // Thêm header cho file log cho chuyên nghiệp
            errorLogs.unshift(`=== DOWNLOAD ERROR LOG (${safeHint}) ===\nTotal failed: ${failCount}\n======================================\n\n`);
            
            const logContent = errorLogs.join('\n');
            
            // TextEncoder chuyển String thành Uint8Array để fflate có thể nén
            const logBytes = new TextEncoder().encode(logContent);
            
            const logPassThrough = new fflate.ZipPassThrough('error.log');
            zip.add(logPassThrough);
            logPassThrough.push(logBytes, true); // Push 1 lần và đóng file log luôn
            
            await writePromise;
        }
        // ------------------------------------------
        
        // Kết thúc ZIP
        zip.end();
        await writePromise;

        // ---------------------------------------------------------
        // GIAI ĐOẠN 3: Xuất file
        // ---------------------------------------------------------
        reportProgress("Phase 3: Exporting file...", true);
        
        const finalFile = await zipFileHandle.getFile();
        const blobUrl = URL.createObjectURL(finalFile);
        
        chrome.runtime.sendMessage({
            action: "triggerFinalDownload",
            url: blobUrl,
            filename: finalZipName,
            batchId: batchId
        });

    } catch (error) {
        reportProgress(`Error: ${error.message}`, true);
        setTimeout(() => window.close(), 3000);
    }
}