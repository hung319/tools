// popup.js
let allResources = [];
let currentTabUrl = "";

document.addEventListener('DOMContentLoaded', () => {
    chrome.runtime.sendMessage({ action: "getDownloadState" }, (res) => {
        if (res && res.isDownloading) lockUI(res.currentStatus);
    });

    scanCurrentPage();
    setupEventHandlers();
});

function setupEventHandlers() {
    document.getElementById('btnAll').onclick = () => toggleCheckboxes(true);
    document.getElementById('btnNone').onclick = () => toggleCheckboxes(false);
    
    document.getElementById('btnImg').onclick = () => toggleByType('img');
    document.getElementById('btnCss').onclick = () => toggleByType('css');
    document.getElementById('btnJs').onclick = () => toggleByType('js');
    
    // Nút MAP cần có id="btnMap" trong popup.html nhé
    const btnMap = document.getElementById('btnMap');
    if (btnMap) btnMap.onclick = () => toggleByType('map');
    
    document.getElementById('btnDownload').onclick = () => {
        const checkedFiles = getCheckedFiles();
        if (checkedFiles.length === 0) return updateStatus("No files selected.");
        
        const useTree = document.getElementById('chkTreeStructure').checked;
        lockUI("Sending to Background Engine...");

        // --- Lấy tên Web hiện tại làm tên tệp ZIP ---
        let mainDomain = "Source_Files";
        try { 
            if (currentTabUrl) {
                mainDomain = new URL(currentTabUrl).hostname; 
            }
        } catch(e) {}

        chrome.runtime.sendMessage({
            action: "startDownload",
            payload: { files: checkedFiles, zipNameHint: mainDomain, useTree: useTree }
        }, (response) => {
            if (response && !response.success) unlockUI("Download failed to start or already running.");
        });
    };
}

chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "popupUpdate") {
        updateStatus(request.status);
        if (!request.isDownloading) unlockUI();
    }
});

function lockUI(msg) {
    document.getElementById('btnDownload').disabled = true;
    document.getElementById('btnDownload').style.opacity = '0.5';
    if (msg) updateStatus(msg);
}

function unlockUI(msg) {
    document.getElementById('btnDownload').disabled = false;
    document.getElementById('btnDownload').style.opacity = '1';
    if (msg) updateStatus(msg);
}

// --- TÌM SOURCE MAPS ---
async function findSourceMaps(resources) {
    updateStatus("Extracting Source Maps...");
    const targetFiles = resources.filter(r => r.type === 'js' || r.type === 'css');
    const mapResources = [];
    const urlSet = new Set(resources.map(r => r.url));
    let idCounter = resources.length; 

    const mapRegex = /(?:\/\/[@#][ \t]+sourceMappingURL=([^\s'"]+?)[ \t]*$)|(?:\/\*[@#][ \t]+sourceMappingURL=([^\*]+?)[ \t]*(?:\*\/)[ \t]*$)/m;

    await Promise.allSettled(targetFiles.map(async (file) => {
        try {
            const response = await fetch(file.url, { credentials: 'omit' });
            if (!response.ok) return;
            
            const text = await response.text();
            const match = text.match(mapRegex);
            
            if (match) {
                const mapUrlRaw = match[1] || match[2];
                const absoluteMapUrl = new URL(mapUrlRaw, file.url).href;
                
                if (!urlSet.has(absoluteMapUrl)) {
                    urlSet.add(absoluteMapUrl);
                    mapResources.push({
                        id: idCounter++,
                        url: absoluteMapUrl,
                        filename: absoluteMapUrl.split('/').pop().split(/[?#]/)[0] || 'unknown.map',
                        path: file.path, 
                        type: 'map'
                    });
                }
            }
        } catch (e) {
            // Im lặng bỏ qua lỗi
        }
    }));

    return mapResources;
}

// --- SCANNING ---
async function scanCurrentPage() {
    updateStatus("Scanning Network & DOM...");
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.id) throw new Error("Cannot access page.");
        
        currentTabUrl = tab.url;

        // Fake Referer
        await new Promise(resolve => chrome.runtime.sendMessage({ action: "setReferer", referer: currentTabUrl }, resolve));

        // Network Data
        const netRes = await new Promise(res => chrome.runtime.sendMessage({ action: "getNetworkResources", tabId: tab.id }, res));
        const networkItems = netRes?.resources || [];

        // DOM Data
        const domResults = await chrome.scripting.executeScript({
            target: { tabId: tab.id, allFrames: true },
            files: ['content.js']
        });
        
        let domItems = [];
        if (domResults) domResults.forEach(f => { if (f.result) domItems = domItems.concat(f.result); });

        // Gộp data
        const urlSet = new Set();
        allResources = [];
        let idCounter = 0;

        const processItem = (item) => {
            if (!item.url || item.url.startsWith('data:') || item.url.startsWith('chrome-extension:')) return;
            if (urlSet.has(item.url)) return;
            urlSet.add(item.url);

            let filename = item.filename || 'unknown';
            let path = item.path || '/';
            if (filename === 'unknown') {
                try {
                    const u = new URL(item.url);
                    filename = u.pathname.substring(u.pathname.lastIndexOf('/') + 1) || 'index.html';
                    path = u.pathname;
                } catch(e){}
            }

            let type = item.type || 'other';
            if (['image'].includes(type)) type = 'img';
            if (['stylesheet'].includes(type)) type = 'css';
            if (['script'].includes(type)) type = 'js';

            allResources.push({ id: idCounter++, url: item.url, filename, path, type });
        };

        networkItems.forEach(processItem);
        domItems.forEach(processItem);

        // Kích hoạt quét Source Maps
        if (allResources.length > 0) {
            const mapFiles = await findSourceMaps(allResources);
            allResources = allResources.concat(mapFiles);
            
            renderDomainTree(allResources);
            updateStatus(`Found ${allResources.length} files.`);
        } else {
            document.getElementById('tree-container').innerHTML = '<div style="padding:10px">No resources found.</div>';
            updateStatus("Empty.");
        }
    } catch (e) {
        document.getElementById('tree-container').innerHTML = `<div style="color:#d00; padding:10px;">Error: ${e.message}</div>`;
        updateStatus("Failed.");
    }
}

// --- RENDER GIAO DIỆN CÂY THƯ MỤC ---
function renderDomainTree(resources) {
    const container = document.getElementById('tree-container');
    container.innerHTML = '';
    const domains = {};
    
    resources.forEach(res => {
        let domain = 'unknown';
        try { domain = new URL(res.url).hostname; } catch (e) {}
        if (!domains[domain]) domains[domain] = [];
        domains[domain].push(res);
    });

    Object.keys(domains).sort().forEach(domain => {
        const domainFiles = domains[domain];
        const domainDiv = document.createElement('div');
        domainDiv.className = 'domain-group';

        const header = document.createElement('div');
        header.className = 'domain-header';
        header.innerHTML = `<div><span class="domain-title">${domain}</span> <span class="domain-count">(${domainFiles.length})</span></div>`;
        
        const btnDomainDL = createMiniDownloadBtn(() => {
            lockUI();
            chrome.runtime.sendMessage({
                action: "startDownload",
                payload: { files: domainFiles, zipNameHint: domain, useTree: document.getElementById('chkTreeStructure').checked }
            });
        });

        header.appendChild(btnDomainDL);
        domainDiv.appendChild(header);

        const rootNode = buildTreeStructure(domainFiles);
        const treeUl = buildHtmlList(rootNode);
        treeUl.style.padding = "5px";
        
        domainDiv.appendChild(treeUl);
        container.appendChild(domainDiv);
    });
}

function buildTreeStructure(files) {
    const root = {};
    files.forEach((res) => {
        const parts = res.path.split('/').filter(p => p);
        if (parts.length === 0) parts.push(res.filename);
        let currentLevel = root;
        parts.forEach((part, idx) => {
            if (idx === parts.length - 1) {
                if (!currentLevel._files) currentLevel._files = [];
                currentLevel._files.push(res);
            } else {
                if (!currentLevel[part]) currentLevel[part] = {};
                currentLevel = currentLevel[part];
            }
        });
    });
    return root;
}

function buildHtmlList(node, level = 0) {
    const ul = document.createElement('ul');
    if (level === 0) { ul.style.paddingLeft = '5px'; ul.style.borderLeft = 'none'; }

    Object.keys(node).forEach(key => {
        if (key === '_files') return;
        const li = document.createElement('li');
        const divRow = document.createElement('div');
        
        const spanIcon = document.createElement('span'); spanIcon.textContent = '📂 ';
        const spanName = document.createElement('span'); spanName.className = 'folder'; spanName.textContent = key;
        const spacer = document.createElement('span'); spacer.className = 'spacer';

        const btnFolderDL = createMiniDownloadBtn(() => {
            lockUI();
            chrome.runtime.sendMessage({
                action: "startDownload",
                payload: { files: collectFilesFromNode(node[key]), zipNameHint: key, useTree: document.getElementById('chkTreeStructure').checked }
            });
        });

        divRow.append(spanIcon, spanName, spacer, btnFolderDL);
        li.appendChild(divRow);
        
        const subUl = buildHtmlList(node[key], level + 1);
        subUl.style.display = 'block'; 
        spanName.onclick = () => {
            const isHidden = subUl.style.display === 'none';
            subUl.style.display = isHidden ? 'block' : 'none';
            spanIcon.textContent = isHidden ? '📂 ' : '📁 ';
        };
        li.appendChild(subUl);
        ul.appendChild(li);
    });

    if (node._files) {
        node._files.forEach(file => {
            const li = document.createElement('li'); li.className = 'file';
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox'; checkbox.value = file.id; checkbox.dataset.type = file.type;
            
            const label = document.createElement('span'); label.className = 'filename';
            label.textContent = file.filename; label.title = file.url;
            
            if (file.type === 'map') {
                label.style.color = '#d9534f';
                label.style.fontWeight = 'bold';
            }

            label.onclick = () => { checkbox.checked = !checkbox.checked; };

            const spacer = document.createElement('span'); spacer.className = 'spacer';
            
            const btnFileDL = createMiniDownloadBtn(() => {
                lockUI();
                chrome.runtime.sendMessage({
                    action: "startDownload",
                    payload: { files: [file], zipNameHint: "Single_File", useTree: false }
                });
            });

            li.append(checkbox, label, spacer, btnFileDL);
            ul.appendChild(li);
        });
    }
    return ul;
}

// --- HELPER FUNCTIONS ---
function createMiniDownloadBtn(action) {
    const btn = document.createElement('button');
    btn.className = 'btn-mini-download'; btn.textContent = '⬇';
    btn.onclick = (e) => { e.stopPropagation(); action(); };
    return btn;
}

function collectFilesFromNode(node) {
    let files = [];
    if (node._files) files = files.concat(node._files);
    Object.keys(node).forEach(key => {
        if (key !== '_files') files = files.concat(collectFilesFromNode(node[key]));
    });
    return files;
}

function getCheckedFiles() {
    const cbs = Array.from(document.querySelectorAll('#tree-container input[type="checkbox"]:checked'));
    const ids = cbs.map(cb => parseInt(cb.value));
    return allResources.filter(r => r && typeof r.id !== 'undefined' && ids.includes(r.id));
}

function toggleCheckboxes(state) { document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => cb.checked = state); }
function toggleByType(type) { document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => cb.checked = (cb.dataset.type === type)); }
function updateStatus(msg) { document.getElementById('status').textContent = msg; }