let allResources = [];

document.addEventListener('DOMContentLoaded', () => {
    scanCurrentPage();
    setupEventHandlers();
});

function setupEventHandlers() {
    // Toolbar buttons
    document.getElementById('btnAll').onclick = () => toggleCheckboxes(true);
    document.getElementById('btnNone').onclick = () => toggleCheckboxes(false);
    
    document.getElementById('btnImg').onclick = () => toggleByType('img');
    document.getElementById('btnCss').onclick = () => toggleByType('css');
    document.getElementById('btnJs').onclick = () => toggleByType('js');
    
    // Main Download Button (Footer)
    document.getElementById('btnDownload').onclick = () => {
        const checkedFiles = getCheckedFiles();
        // Mặc định tên là "Selected_Files" nếu bấm nút to
        handleDownload(checkedFiles, "Selected_Files");
    };
}

// --- 1. SCANNING ---
async function scanCurrentPage() {
    updateStatus("Scanning...");
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ['content.js']
        });
        
        if (results && results[0] && results[0].result) {
            allResources = results[0].result;
            allResources.forEach((r, i) => r.id = i); // Assign IDs
            
            renderDomainTree(allResources);
            updateStatus(`Found ${allResources.length} files.`);
        } else {
            document.getElementById('tree-container').innerHTML = '<div style="padding:10px">No resources found.</div>';
            updateStatus("Empty.");
        }
    } catch (e) {
        document.getElementById('tree-container').innerHTML = `<div style="color:#d00; padding:10px">Error: ${e.message}</div>`;
    }
}

// --- 2. RENDER LOGIC (DOMAIN GROUPING) ---

function renderDomainTree(resources) {
    const container = document.getElementById('tree-container');
    container.innerHTML = '';

    const domains = {};
    resources.forEach(res => {
        let domain = 'unknown';
        try { domain = new URL(res.url).hostname; } catch (e) {}
        
        if (!domains[domain]) domains[domain] = [];
        domains[domain].push(res);
    });

    const sortedDomains = Object.keys(domains).sort();
    
    sortedDomains.forEach(domain => {
        const domainFiles = domains[domain];
        
        const domainDiv = document.createElement('div');
        domainDiv.className = 'domain-group';

        const header = document.createElement('div');
        header.className = 'domain-header';
        
        const titleDiv = document.createElement('div');
        titleDiv.innerHTML = `<span class="domain-title">${domain}</span> <span class="domain-count">(${domainFiles.length})</span>`;
        
        // Nút download Domain -> Tên file sẽ là Domain_Time.zip
        const btnDomainDL = createMiniDownloadBtn(() => {
            handleDownload(domainFiles, domain);
        });

        header.appendChild(titleDiv);
        header.appendChild(btnDomainDL);
        domainDiv.appendChild(header);

        const rootNode = buildTreeStructure(domainFiles);
        const treeUl = buildHtmlList(rootNode);
        treeUl.style.padding = "5px";
        
        domainDiv.appendChild(treeUl);
        container.appendChild(domainDiv);
    });
}

function buildTreeStructure(files) {
    const root = {};
    files.forEach((res) => {
        const parts = res.path.split('/').filter(p => p);
        if (parts.length === 0) parts.push(res.filename);

        let currentLevel = root;
        parts.forEach((part, idx) => {
            if (idx === parts.length - 1) {
                if (!currentLevel._files) currentLevel._files = [];
                currentLevel._files.push(res);
            } else {
                if (!currentLevel[part]) currentLevel[part] = {};
                currentLevel = currentLevel[part];
            }
        });
    });
    return root;
}

function buildHtmlList(node, level = 0) {
    const ul = document.createElement('ul');
    if (level === 0) {
        ul.style.paddingLeft = '5px';
        ul.style.borderLeft = 'none';
    }

    // A. Render Folders
    Object.keys(node).forEach(key => {
        if (key === '_files') return;
        
        const li = document.createElement('li');
        const divRow = document.createElement('div');
        
        const spanIcon = document.createElement('span');
        spanIcon.textContent = '📂 ';
        
        const spanName = document.createElement('span');
        spanName.className = 'folder';
        spanName.textContent = key;
        
        const spacer = document.createElement('span');
        spacer.className = 'spacer';

        // Nút download Folder -> Tên file sẽ là FolderName_Time.zip
        const btnFolderDL = createMiniDownloadBtn(() => {
            const folderFiles = collectFilesFromNode(node[key]);
            handleDownload(folderFiles, key); 
        });

        divRow.appendChild(spanIcon);
        divRow.appendChild(spanName);
        divRow.appendChild(spacer);
        divRow.appendChild(btnFolderDL);
        li.appendChild(divRow);
        
        const subUl = buildHtmlList(node[key], level + 1);
        subUl.style.display = 'block'; 
        
        spanName.onclick = () => {
            const isHidden = subUl.style.display === 'none';
            subUl.style.display = isHidden ? 'block' : 'none';
            spanIcon.textContent = isHidden ? '📂 ' : '📁 ';
        };

        li.appendChild(subUl);
        ul.appendChild(li);
    });

    // B. Render Files
    if (node._files) {
        node._files.forEach(file => {
            const li = document.createElement('li');
            li.className = 'file';
            
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.value = file.id;
            checkbox.dataset.type = file.type;
            
            const label = document.createElement('span');
            label.className = 'filename';
            label.textContent = file.filename;
            label.title = file.url;
            label.onclick = () => { checkbox.checked = !checkbox.checked; };

            const spacer = document.createElement('span');
            spacer.className = 'spacer';

            // Nút download file lẻ -> Tự lấy tên gốc của file
            const btnFileDL = createMiniDownloadBtn(() => {
                handleDownload([file]); 
            });

            li.appendChild(checkbox);
            li.appendChild(label);
            li.appendChild(spacer);
            li.appendChild(btnFileDL);
            ul.appendChild(li);
        });
    }
    return ul;
}

// --- 3. HELPER FUNCTIONS ---

function createMiniDownloadBtn(action) {
    const btn = document.createElement('button');
    btn.className = 'btn-mini-download';
    btn.textContent = '⬇';
    btn.title = 'Download zip with timestamp';
    btn.onclick = (e) => {
        e.stopPropagation(); 
        action();
    };
    return btn;
}

function collectFilesFromNode(node) {
    let files = [];
    if (node._files) files = files.concat(node._files);
    Object.keys(node).forEach(key => {
        if (key !== '_files') files = files.concat(collectFilesFromNode(node[key]));
    });
    return files;
}

function getCheckedFiles() {
    const cbs = Array.from(document.querySelectorAll('#tree-container input[type="checkbox"]:checked'));
    const ids = cbs.map(cb => parseInt(cb.value));
    return allResources.filter(r => ids.includes(r.id));
}

function toggleCheckboxes(state) {
    document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => cb.checked = state);
}

function toggleByType(type) {
    document.querySelectorAll('#tree-container input[type="checkbox"]').forEach(cb => {
        cb.checked = (cb.dataset.type === type);
    });
}

// Helper: Tạo chuỗi thời gian YYYYMMDD_HHmmss
function getTimestampString() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return now.getFullYear() +
           pad(now.getMonth() + 1) +
           pad(now.getDate()) + '_' +
           pad(now.getHours()) +
           pad(now.getMinutes()) +
           pad(now.getSeconds());
}

// --- 4. DOWNLOAD CORE ---

function getParentFolderName(path) {
    const parts = path.split('/').filter(p => p);
    if (parts.length < 2) return 'root';
    return parts[parts.length - 2];
}

function getUniqueFilename(existingNames, file) {
    let name = file.filename;
    if (!existingNames.has(name)) { existingNames.add(name); return name; }
    
    const parent = getParentFolderName(file.path);
    let newName = `(${parent})${name}`;
    if (!existingNames.has(newName)) { existingNames.add(newName); return newName; }

    let counter = 1;
    let finalName = newName;
    while (existingNames.has(finalName)) {
        const dotIndex = newName.lastIndexOf('.');
        if (dotIndex !== -1) {
            finalName = `${newName.substring(0, dotIndex)}_${counter}${newName.substring(dotIndex)}`;
        } else {
            finalName = `${newName}_${counter}`;
        }
        counter++;
    }
    existingNames.add(finalName);
    return finalName;
}

/**
 * @param {Array} files - Danh sách file cần tải
 * @param {String} zipNameHint - Tên gợi ý (Domain, Folder, v.v.)
 */
async function handleDownload(files, zipNameHint = 'resources') {
    if (!files || files.length === 0) {
        updateStatus("No files selected.");
        return;
    }

    const useTree = document.getElementById('chkTreeStructure').checked;

    // 1. Tải 1 file lẻ thì giữ nguyên tên gốc, không thêm timestamp loằng ngoằng
    if (files.length === 1 && !useTree) {
        updateStatus("Downloading single file...");
        chrome.downloads.download({
            url: files[0].url,
            filename: files[0].filename
        });
        return;
    }

    // 2. Tải ZIP -> Thêm Timestamp
    updateStatus(`Preparing ${files.length} files...`);
    const zip = new JSZip();
    
    // Logic tạo tên file ZIP: Hint + Timestamp
    const timestamp = getTimestampString();
    // Loại bỏ ký tự đặc biệt trong tên Domain/Folder để tránh lỗi hệ điều hành
    const safeHint = zipNameHint.replace(/[^a-z0-9\._-]/gi, '_'); 
    
    // Kết quả: google.com_20231025_143005
    const rootZipName = `${safeHint}_${timestamp}`;
    
    const rootFolder = zip.folder(rootZipName);

    const usedNames = new Set();
    let successCount = 0;
    let failCount = 0;

    await Promise.all(files.map(async (file) => {
        try {
            const response = await fetch(file.url, { credentials: 'omit' });
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            const blob = await response.blob();

            if (useTree) {
                let cleanPath = file.path.startsWith('/') ? file.path.slice(1) : file.path;
                rootFolder.file(cleanPath, blob);
            } else {
                const uniqueName = getUniqueFilename(usedNames, file);
                rootFolder.file(uniqueName, blob);
            }
            successCount++;
        } catch (e) {
            console.warn("Err", file.url, e);
            rootFolder.file(`ERRORS/${file.filename}.txt`, `Failed: ${file.url}\n${e.message}`);
            failCount++;
        } finally {
            updateStatus(`Processing: ${successCount + failCount}/${files.length}`);
        }
    }));

    if (successCount === 0 && failCount > 0) {
        updateStatus("Failed all downloads.");
        return;
    }

    updateStatus("Compressing Zip...");
    try {
        const content = await zip.generateAsync({ type: "blob" });
        const url = URL.createObjectURL(content);
        
        // Tên file ZIP tải về
        chrome.downloads.download({
            url: url,
            filename: `${rootZipName}.zip`,
            saveAs: true
        });
        updateStatus("Done!");
    } catch (e) {
        updateStatus("Zip Error!");
    }
}

function updateStatus(msg) {
    document.getElementById('status').textContent = msg;
}