// background.js
const tabResources = {};
let isDownloading = false;
let currentStatus = "Ready";

// --- 1. MẠNG & REFERER ---
chrome.webRequest.onCompleted.addListener((details) => {
    const tabId = details.tabId;
    if (tabId >= 0 && details.method === "GET") {
        if (!tabResources[tabId]) tabResources[tabId] = new Set();
        tabResources[tabId].add({ url: details.url, type: details.type });
    }
}, { urls: ["<all_urls>"] });

chrome.tabs.onRemoved.addListener((tabId) => delete tabResources[tabId]);

// --- 2. QUẢN LÝ TIẾN TRÌNH & OFFSCREEN ---
let creatingOffscreen;

async function setupOffscreenDocument(path) {
    const existingContexts = await chrome.runtime.getContexts({
        contextTypes: ['OFFSCREEN_DOCUMENT'],
        documentUrls: [chrome.runtime.getURL(path)]
    });
    if (existingContexts.length > 0) return;
    if (creatingOffscreen) { await creatingOffscreen; return; }
    
    creatingOffscreen = chrome.offscreen.createDocument({
        url: path,
        reasons: ['BLOBS'],
        justification: 'Background ZIP generation'
    });
    await creatingOffscreen;
    creatingOffscreen = null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Popup hỏi data mạng
    if (request.action === "getNetworkResources") {
        sendResponse({ resources: tabResources[request.tabId] ? Array.from(tabResources[request.tabId]) : [] });
        return true;
    }
    
    // Đè Referer chống CORS/Hotlink
    if (request.action === "setReferer") {
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: [1],
            addRules: [{
                "id": 1, "priority": 1,
                "action": { "type": "modifyHeaders", "requestHeaders": [{ "header": "Referer", "operation": "set", "value": request.referer }] },
                "condition": { "resourceTypes": ["xmlhttprequest"] }
            }]
        }).then(() => sendResponse({ success: true }));
        return true; 
    }

    // --- LOGIC GIAO TIẾP POPUP <-> OFFSCREEN ---
    if (request.action === "startDownload") {
        if (isDownloading) {
            sendResponse({ success: false, message: "A download is already running." });
            return;
        }
        isDownloading = true;
        currentStatus = "Starting background engine...";
        
        setupOffscreenDocument('offscreen.html').then(() => {
            // Chỉ truyền payload, không truyền mảng files nặng nề qua đây nữa
            chrome.runtime.sendMessage({ action: "runOffscreenZip", payload: request.payload });
        });
        sendResponse({ success: true });
    }

    if (request.action === "getDownloadState") {
        sendResponse({ isDownloading, currentStatus });
    }

    if (request.action === "updateProgress") {
        currentStatus = request.status;
        if (request.done) isDownloading = false;
        chrome.runtime.sendMessage({ action: "popupUpdate", status: currentStatus, isDownloading: isDownloading });
    }

    // Nhận lệnh tải xuống từ Offscreen
    if (request.action === "triggerFinalDownload") {
        chrome.downloads.download({
            url: request.url,
            filename: request.filename,
            saveAs: true
        }, (downloadId) => {
            setTimeout(async () => {
                try {
                    const opfsRoot = await navigator.storage.getDirectory();
                    await opfsRoot.removeEntry(request.batchId, { recursive: true });
                    await chrome.offscreen.closeDocument();
                } catch (e) {
                    console.warn("Cleanup error:", e);
                }
            }, 10000); 
        });
        
        sendResponse({ success: true });
        return true;
    }
});