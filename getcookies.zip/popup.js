document.addEventListener('DOMContentLoaded', () => {
  // Lấy các element trên UI
  const urlDisplay = document.getElementById('current-url');
  const cookieDisplay = document.getElementById('cookie-display');
  const copyBtn = document.getElementById('copy-btn');
  const outBtn = document.getElementById('out-btn'); 
  const savedList = document.getElementById('saved-list');
  const deleteAllBtn = document.getElementById('delete-all-btn');

  // Biến toàn cục
  let currentDomain = '';
  let currentCookies = []; 
  let currentCookieString = ''; 

  // 1. Khởi tạo
  async function initialize() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab && tab.url) {
      try {
        const url = new URL(tab.url);
        currentDomain = url.hostname;
        urlDisplay.textContent = currentDomain;

        // === THAY ĐỔI QUAN TRỌNG ===
        // Lấy cookie bằng URL đầy đủ (để lấy cả cookie .domain.com)
        // thay vì: chrome.cookies.getAll({ domain: currentDomain });
        currentCookies = await chrome.cookies.getAll({ url: tab.url });
        // === KẾT THÚC THAY ĐỔI ===
        
        if (currentCookies.length > 0) {
          currentCookieString = currentCookies
            .map(c => `${c.name}=${c.value}`)
            .join('; ');
          
          cookieDisplay.value = currentCookieString;
          
          // CẬP NHẬT: Gửi cả MẢNG OBJECT và CHUỖI STRING
          await handleSave(currentCookies, currentCookieString);
          
        } else {
          cookieDisplay.value = "Không tìm thấy cookie nào cho trang này.";
        }
      } catch (error) {
        console.error("Lỗi khi lấy cookie:", error);
        urlDisplay.textContent = "Không thể lấy URL (tab hệ thống?)";
        cookieDisplay.value = "Không thể lấy cookie.";
      }
    }
    loadSavedCookies();
  }

  // CẬP NHẬT: Hàm tự động lưu trữ
  async function handleSave(cookieObjects, cookieDataString) {
    if (!currentDomain || cookieObjects.length === 0) {
      return; 
    }
    
    const result = await chrome.storage.local.get({ savedCookies: [] });
    const cookies = result.savedCookies;

    const mainCookieName = cookieObjects[0].name;

    const newEntry = {
      id: `cookie_${currentDomain}_${Date.now()}`,
      domain: currentDomain,
      name: mainCookieName, // Tên định danh mới
      timestamp: new Date().toLocaleString('vi-VN'),
      cookies_objects: cookieObjects, // Lưu mảng object để restore
      cookies_string: cookieDataString // Lưu chuỗi string để copy
    };
    
    cookies.push(newEntry);
    await chrome.storage.local.set({ savedCookies: cookies });
  }

  // Hàm "Out Cookie" (Chỉ xóa)
  async function handleOut() {
    if (!currentDomain || currentCookies.length === 0) {
      alert('Không có cookie nào để "out".');
      return;
    }
    
    try {
      for (const cookie of currentCookies) {
        const url = `http${cookie.secure ? 's' : ''}://${cookie.domain.replace(/^\./, '')}${cookie.path}`;
        await chrome.cookies.remove({
          url: url,
          name: cookie.name,
          storeId: cookie.storeId
        });
      }
    } catch (e) {
      console.error("Lỗi khi xóa cookie:", e);
      alert("Đã xảy ra lỗi khi xóa cookie.");
      return; 
    }
    
    currentCookies = [];
    currentCookieString = '';
    cookieDisplay.value = 'Đã xóa cookie khỏi trình duyệt.';
    
    outBtn.textContent = 'Đã Out!';
    outBtn.disabled = true; 
  }

  // 2. Tải và hiển thị danh sách (CẬP NHẬT)
  async function loadSavedCookies() {
    const result = await chrome.storage.local.get({ savedCookies: [] });
    
    const filteredCookies = result.savedCookies.filter(
      item => item.domain === currentDomain
    );
    
    savedList.innerHTML = ''; 

    if (filteredCookies.length === 0) {
      savedList.innerHTML = '<div class="saved-item empty"><span>Chưa có cookie nào được lưu cho trang này.</span></div>';
      deleteAllBtn.style.display = 'none'; 
      return;
    }
    
    deleteAllBtn.style.display = 'block'; 

    filteredCookies.reverse().forEach((item, index) => {
      const itemEl = document.createElement('div');
      itemEl.className = 'saved-item';
      
      const textEl = document.createElement('span');
      textEl.textContent = `${filteredCookies.length - index}. ${item.name} | ${item.timestamp}`;
      
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Xóa';
      deleteBtn.dataset.id = item.id; 
      
      deleteBtn.addEventListener('click', handleDelete);
      
      itemEl.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON') {
          return;
        }
        handleRestore(item);
      });

      itemEl.appendChild(textEl);
      itemEl.appendChild(deleteBtn);
      savedList.appendChild(itemEl);
    });
  }

  // 3. Xử lý sự kiện Xóa 1 item (đã lưu)
  async function handleDelete(event) {
    event.stopPropagation(); 
    
    const idToDelete = event.target.dataset.id;
    const result = await chrome.storage.local.get({ savedCookies: [] });
    const newList = result.savedCookies.filter(item => item.id !== idToDelete);
    await chrome.storage.local.set({ savedCookies: newList });
    loadSavedCookies(); 
  }

  // 4. Xử lý sự kiện Xóa tất cả (đã lưu cho domain hiện tại)
  async function handleDeleteAll() {
    if (confirm(`Bạn có chắc muốn xóa TẤT CẢ cookie đã lưu cho ${currentDomain}?`)) {
      const result = await chrome.storage.local.get({ savedCookies: [] });
      const newList = result.savedCookies.filter(
        item => item.domain !== currentDomain
      );
      await chrome.storage.local.set({ savedCookies: newList });
      loadSavedCookies(); 
    }
  }

  // 5. Xử lý sự kiện Sao chép
  copyBtn.addEventListener('click', () => {
    if (cookieDisplay.value && cookieDisplay.value.includes('=')) {
      navigator.clipboard.writeText(cookieDisplay.value);
      copyBtn.textContent = 'Đã chép!';
      setTimeout(() => { copyBtn.textContent = 'Sao chép'; }, 1500);
    }
  });

  // 6. (MỚI) Hàm Khôi phục (Restore) Cookie
  async function handleRestore(itemToRestore) {
    const cookiesToSet = itemToRestore.cookies_objects;
    if (!cookiesToSet || cookiesToSet.length === 0) {
      alert('Không có dữ liệu cookie object để khôi phục.');
      return;
    }

    try {
      // Xóa cookie cũ (nếu có) trước khi set
      const oldCookies = await chrome.cookies.getAll({ url: tab.url }); // Dùng url ở đây
      for (const oldCookie of oldCookies) {
        const url = `http${oldCookie.secure ? 's' : ''}://${oldCookie.domain.replace(/^\./, '')}${oldCookie.path}`;
        await chrome.cookies.remove({ url: url, name: oldCookie.name, storeId: oldCookie.storeId });
      }

      // Set cookie mới
      for (const cookie of cookiesToSet) {
        const url = `http${cookie.secure ? 's' : ''}://${cookie.domain.replace(/^\./, '')}${cookie.path}`;
        
        const newCookie = {
          url: url,
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: cookie.path,
          secure: cookie.secure,
          httpOnly: cookie.httpOnly,
          storeId: cookie.storeId
        };
        
        if (!cookie.session) {
          newCookie.expirationDate = cookie.expirationDate;
        }

        await chrome.cookies.set(newCookie);
      }
      
      alert('Đã khôi phục cookie! Trang sẽ được tải lại.');
      // Tải lại tab hiện tại để áp dụng cookie mới
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].id) {
          chrome.tabs.reload(tabs[0].id);
        }
      });
      window.close(); // Tự động đóng popup

    } catch (e) {
      console.error("Lỗi khi khôi phục cookie:", e);
      alert('Đã xảy ra lỗi khi khôi phục cookie. Kiểm tra console (F12).');
    }
  }
  
  // 7. Gán sự kiện
  outBtn.addEventListener('click', handleOut); 
  deleteAllBtn.addEventListener('click', handleDeleteAll);

  // Chạy
  initialize();
});