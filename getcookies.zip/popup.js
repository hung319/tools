document.addEventListener('DOMContentLoaded', () => {
  // Lấy các element trên UI
  const urlDisplay = document.getElementById('current-url');
  const cookieDisplay = document.getElementById('cookie-display');
  const saveBtn = document.getElementById('save-btn'); // THÊM LẠI
  const outBtn = document.getElementById('out-btn'); 
  const savedList = document.getElementById('saved-list');
  const deleteAllBtn = document.getElementById('delete-all-btn');

  // Biến toàn cục
  let currentDomain = '';
  let currentCookies = []; 
  let currentCookieString = ''; 

  // Hàm tạo ID ngẫu nhiên 6 ký tự
  function generateRandomId() {
    return Math.random().toString(36).substring(2, 8);
  }

  // 1. Khởi tạo (Không tự động lưu)
  async function initialize() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab && tab.url) {
      try {
        const url = new URL(tab.url);
        currentDomain = url.hostname;
        urlDisplay.textContent = currentDomain;

        currentCookies = await chrome.cookies.getAll({ url: tab.url });
        
        if (currentCookies.length > 0) {
          currentCookieString = currentCookies
            .map(c => `${c.name}=${c.value}`)
            .join('; ');
          
          cookieDisplay.value = currentCookieString;
        } else {
          cookieDisplay.value = "Không tìm thấy cookie nào cho trang này.";
        }
      } catch (error) {
        console.error("Lỗi khi lấy cookie:", error);
        urlDisplay.textContent = "Không thể lấy URL (tab hệ thống?)";
        cookieDisplay.value = "Không thể lấy cookie.";
      }
    }
    loadSavedCookies();
  }

  // CẬP NHẬT: Hàm lưu trữ (Manual Save) - Được gọi bằng NÚT LƯU
  async function handleSave() {
    if (!currentDomain || currentCookies.length === 0) {
      alert('Không có cookie để lưu.');
      return;
    }
    
    // Bỏ logic check trùng lặp
    
    const result = await chrome.storage.local.get({ savedCookies: [] });
    const allCookies = result.savedCookies;

    const randomId = generateRandomId();

    const newEntry = {
      id: `cookie_${currentDomain}_${Date.now()}`,
      domain: currentDomain,
      name: randomId, // Tên hiển thị (DisplayName)
      timestamp: new Date().toLocaleString('vi-VN'),
      cookies_objects: currentCookies, 
      cookies_string: currentCookieString
    };
    
    allCookies.push(newEntry);
    await chrome.storage.local.set({ savedCookies: allCookies });

    loadSavedCookies();
    
    // Feedback trên NÚT LƯU
    saveBtn.textContent = `Đã lưu! (${randomId})`;
    saveBtn.disabled = true;
    setTimeout(() => {
      saveBtn.textContent = "Lưu Cookie";
      saveBtn.disabled = false;
    }, 2000);
  }

  // Hàm "Out Cookie" (Chỉ xóa)
  async function handleOut() {
    if (!currentDomain || currentCookies.length === 0) {
      alert('Không có cookie nào để "out".');
      return;
    }
    
    try {
      for (const cookie of currentCookies) {
        const url = `http${cookie.secure ? 's' : ''}://${cookie.domain.replace(/^\./, '')}${cookie.path}`;
        await chrome.cookies.remove({
          url: url,
          name: cookie.name,
          storeId: cookie.storeId
        });
      }
    } catch (e) {
      console.error("Lỗi khi xóa cookie:", e);
      alert("Đã xảy ra lỗi khi xóa cookie.");
      return; 
    }
    
    currentCookies = [];
    currentCookieString = '';
    cookieDisplay.value = 'Đã xóa cookie khỏi trình duyệt.';
    
    outBtn.textContent = 'Đã Out!';
    outBtn.disabled = true; 
  }

  // 2. Tải và hiển thị danh sách
  async function loadSavedCookies() {
    const result = await chrome.storage.local.get({ savedCookies: [] });
    
    const filteredCookies = result.savedCookies.filter(
      item => item.domain === currentDomain
    );
    
    savedList.innerHTML = ''; 

    if (filteredCookies.length === 0) {
      savedList.innerHTML = '<div class="saved-item empty"><span>Chưa có cookie nào được lưu cho trang này.</span></div>';
      deleteAllBtn.style.display = 'none'; 
      return;
    }
    
    deleteAllBtn.style.display = 'block'; 

    filteredCookies.reverse().forEach((item, index) => {
      const itemEl = document.createElement('div');
      itemEl.className = 'saved-item';
      
      const textEl = document.createElement('span');
      // Hiển thị ID 6 ký tự ngẫu nhiên
      textEl.textContent = `${filteredCookies.length - index}. [${item.name}] | ${item.timestamp}`;
      
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Xóa';
      deleteBtn.dataset.id = item.id; 
      
      deleteBtn.addEventListener('click', handleDelete);
      
      itemEl.addEventListener('click', (e) => {
        if (e.target.tagName === 'BUTTON') {
          return;
        }
        handleRestore(item);
      });

      itemEl.appendChild(textEl);
      itemEl.appendChild(deleteBtn);
      savedList.appendChild(itemEl);
    });
  }

  // 3. Xử lý sự kiện Xóa 1 item (đã lưu)
  async function handleDelete(event) {
    event.stopPropagation(); 
    
    const idToDelete = event.target.dataset.id;
    const result = await chrome.storage.local.get({ savedCookies: [] });
    const newList = result.savedCookies.filter(item => item.id !== idToDelete);
    await chrome.storage.local.set({ savedCookies: newList });
    loadSavedCookies(); 
  }

  // 4. Xử lý sự kiện Xóa tất cả (đã lưu cho domain hiện tại)
  async function handleDeleteAll() {
    if (confirm(`Bạn có chắc muốn xóa TẤT CẢ cookie đã lưu cho ${currentDomain}?`)) {
      const result = await chrome.storage.local.get({ savedCookies: [] });
      const newList = result.savedCookies.filter(
        item => item.domain !== currentDomain
      );
      await chrome.storage.local.set({ savedCookies: newList });
      loadSavedCookies(); 
    }
  }

  // 5. THÊM MỚI: Hàm Sao chép (Copy) - Được gọi bằng CLICK TEXTBOX
  function handleCopy() {
    // Chỉ sao chép nếu có cookie string VÀ NÓ KHÔNG PHẢI là chuỗi thông báo
    if (currentCookieString && cookieDisplay.value.includes('=')) {
      navigator.clipboard.writeText(currentCookieString);
      
      // Tạm thời thay đổi placeholder để feedback
      cookieDisplay.placeholder = 'Đã sao chép vào clipboard!';
      setTimeout(() => {
        cookieDisplay.placeholder = "Click vào đây để SAO CHÉP cookie...";
      }, 2000);
    }
  }

  // 6. Hàm Khôi phục (Restore) Cookie
  async function handleRestore(itemToRestore) {
    const cookiesToSet = itemToRestore.cookies_objects;
    if (!cookiesToSet || cookiesToSet.length === 0) {
      alert('Không có dữ liệu cookie object để khôi phục.');
      return;
    }

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url) {
        alert('Không tìm thấy tab đang hoạt động.');
        return;
    }

    try {
      const oldCookies = await chrome.cookies.getAll({ url: tab.url });
      for (const oldCookie of oldCookies) {
        const url = `http${oldCookie.secure ? 's' : ''}://${oldCookie.domain.replace(/^\./, '')}${oldCookie.path}`;
        await chrome.cookies.remove({ url: url, name: oldCookie.name, storeId: oldCookie.storeId });
      }

      for (const cookie of cookiesToSet) {
        const url = `http${cookie.secure ? 's' : ''}://${cookie.domain.replace(/^\./, '')}${cookie.path}`;
        
        const newCookie = {
          url: url,
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: cookie.path,
          secure: cookie.secure,
          httpOnly: cookie.httpOnly,
          storeId: cookie.storeId
        };
        
        if (!cookie.session) {
          newCookie.expirationDate = cookie.expirationDate;
        }

        await chrome.cookies.set(newCookie);
      }
      
      alert('Đã khôi phục cookie! Trang sẽ được tải lại.');
      chrome.tabs.reload(tab.id);
      window.close(); 

    } catch (e) {
      console.error("Lỗi khi khôi phục cookie:", e);
      alert('Đã xảy ra lỗi khi khôi phục cookie. Kiểm tra console (F12).');
    }
  }
  
  // 7. Gán sự kiện (CẬP NHẬT)
  saveBtn.addEventListener('click', handleSave);     // Nút LƯU
  outBtn.addEventListener('click', handleOut);      // Nút OUT
  deleteAllBtn.addEventListener('click', handleDeleteAll); // Nút XÓA HẾT
  cookieDisplay.addEventListener('click', handleCopy); // Textbox CLICK ĐỂ COPY

  // Chạy
  initialize();
});