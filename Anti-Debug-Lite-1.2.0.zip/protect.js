/* CezDev Anti-Debug Lite — 2 việc, không hơn.
 *
 * 1. KHÔNG đăng ký timer/callback nào chứa `debugger;`
 *    → DevTools không dừng, không nhảy vào file player.
 * 2. Treo DisableDevtool bằng chính API của nó (isSuspend = true)
 *    → detector ngừng, không history.back(), không bị đá sang trang 404.
 *
 * Không panel, không storage, không chặn URL, không đụng performance.now,
 * không proxy Function/eval, không sửa fetch/innerHTML.
 */
(function () {
    'use strict';

    if (window.__liteInstalled) return;
    try { Object.defineProperty(window, '__liteInstalled', { value: true, configurable: true }); } catch (e) {}

    // ------------------------------------------------------------------
    // 1. Bỏ timer chứa `debugger;`
    // ------------------------------------------------------------------
    function hasDebugger(fn) {
        try {
            if (typeof fn !== 'function') return false;
            var src = Function.prototype.toString.call(fn);
            if (!src || src.length > 20000) return false;
            if (src.indexOf('[native code]') !== -1) return false;
            return /\bdebugger\b/.test(src);
        } catch (e) { return false; }
    }

    function guard(name) {
        try {
            var orig = window[name];
            if (typeof orig !== 'function' || orig.__liteGuard) return;
            var patched = new Proxy(orig, {
                apply: function (target, thisArg, args) {
                    if (hasDebugger(args[0])) {
                        window.__liteBlocked = (window.__liteBlocked || 0) + 1;
                        try { console.log('%c[Lite]', 'color:#0aa', 'bỏ ' + name + ' chứa debugger'); } catch (e) {}
                        // setInterval: trả id "câm"; setTimeout/rAF: 0
                        return name === 'setInterval' ? target.call(window, function () {}, 2147483647) : 0;
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });
            try { Object.defineProperty(patched, '__liteGuard', { value: true }); } catch (e) {}
            window[name] = patched;
        } catch (e) {}
    }

    // Cố ý KHÔNG bọc requestAnimationFrame: vòng render của canvas/player có thể
    // chứa chuỗi 'debugger' và bị bỏ ⇒ màn hình đen. Chỉ chặn 2 loại timer.
    guard('setInterval');
    guard('setTimeout');

    // ------------------------------------------------------------------
    // 2. Không cho biên dịch mã chứa `debugger;`
    //    console-ban (dùng trên rophim.net) dò DevTools bằng:
    //        var t0 = performance.now();
    //        (function(){}).constructor("debugger")();     // <-- pause
    //        var open = performance.now() - t0 > 100;
    //    Chặn ngay ở chỗ biên dịch: chuỗi "debugger" được thay bằng "0;" nên
    //    không còn câu lệnh nào để DevTools dừng, và phép đo trả về ~0 ms.
    //    Không đụng performance.now, không đụng fetch/hay DOM.
    // ------------------------------------------------------------------
    function sanitize(code) {
        if (typeof code !== 'string' || code.indexOf('debugger') === -1) return code;
        window.__liteSanitized = (window.__liteSanitized || 0) + 1;
        return code.replace(/\bdebugger\b/g, '0;');
    }

    (function guardFunctionCtor() {
        try {
            var OrigFunction = window.Function;
            if (!OrigFunction || OrigFunction.__liteFn) return;
            var proxied = new Proxy(OrigFunction, {
                apply: function (target, thisArg, args) {
                    var i = args.length - 1;
                    if (i >= 0) args[i] = sanitize(args[i]);
                    return Reflect.apply(target, thisArg, args);
                },
                construct: function (target, args) {
                    var i = args.length - 1;
                    if (i >= 0) args[i] = sanitize(args[i]);
                    return Reflect.construct(target, args);
                }
            });
            try { Object.defineProperty(proxied, '__liteFn', { value: true }); } catch (e) {}
            window.Function = proxied;
            // (function(){}).constructor  -> phải trỏ về bản đã bọc
            try { OrigFunction.prototype.constructor = proxied; } catch (e) {}
            try {
                Object.defineProperty(Object.getPrototypeOf(async function () {}), 'constructor',
                    { value: proxied, configurable: true, writable: true });
            } catch (e) {}
            try {
                Object.defineProperty(Object.getPrototypeOf(function* () {}), 'constructor',
                    { value: proxied, configurable: true, writable: true });
            } catch (e) {}
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 3. Vô hiệu hoá các API mà console-ban dùng để dò DevTools
    //    • console.clear  → thư viện gọi liên tục để xoá console (đúng hiện tượng
    //      "clear console liên tục"). Vô hiệu ⇒ console của bạn không bị xoá nữa.
    //    • console.table  → performanceChecker so thời gian console.log(bigArray)
    //      với console.table(bigArray); table thành no-op ⇒ hiệu số ~0 ⇒ không detect.
    //    Không đụng console.log/warn/error.
    // ------------------------------------------------------------------
    (function hardenConsole() {
        try {
            var c = window.console;
            if (!c) return;
            var noop = function () {};
            ['clear', 'table', 'profile', 'profileEnd', 'group', 'groupEnd'].forEach(function (k) {
                try { Object.defineProperty(c, k, { value: noop, writable: false, configurable: false }); } catch (e) {}
            });
            window.__liteConsole = true;
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 4. Vô hiệu checker "DevtoolsFormatters"
    //    console-ban đăng ký một formatter rồi console.log({}); nếu DevTools mở,
    //    DevTools gọi formatter.header() ⇒ nó biết DevTools đang mở.
    //    Cho window.devtoolsFormatters thành mảng "câm" (push không thêm gì)
    //    ⇒ DevTools không có formatter nào để gọi ⇒ không detect.
    // ------------------------------------------------------------------
    (function blockFormatters() {
        try {
            var sink = [];
            try {
                Object.defineProperty(sink, 'push', {
                    value: function () {
                        window.__liteFormatter = (window.__liteFormatter || 0) + 1;
                        return sink.length;          // không thêm phần tử
                    }
                });
            } catch (e) {}
            Object.defineProperty(window, 'devtoolsFormatters', {
                configurable: true,
                get: function () { return sink; },
                set: function () {}
            });
        } catch (e) {}
    })();

    // ------------------------------------------------------------------
    // 5. Treo DisableDevtool (nếu trang dùng)
    // ------------------------------------------------------------------
    var ticks = 0;
    var fast = null;
    function suspend() {
        try {
            var dd = window.DisableDevtool;
            if (typeof dd === 'function' && dd.isSuspend !== true) {
                dd.isSuspend = true;
                window.__liteDD = (window.__liteDD || 0) + 1;
            }
        } catch (e) {}
        if (++ticks === 300 && fast) {           // ~9 s đầu: 30 ms/lần
            try { clearInterval(fast); } catch (e) {}
            try { setInterval(suspend, 1000); } catch (e) {}
        }
    }
    try { suspend(); fast = setInterval(suspend, 30); } catch (e) {}
})();
