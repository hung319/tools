(function() {
    // ==========================================================================
    // 0. STREAM-GUARD NEUTRALIZER — chống "mở F12 là bị đá sang phim.nguonc.com"
    //    (player họ *.streamc.xyz, bundle guard-messages-r25.js)
    //
    //    Vì sao các lớp cũ không ăn:
    //      - Guard tự đọc cấu hình ANTI-DEVTOOLS từ JSON bootstrap:
    //        browserGuard{detect_devtools, devtools_redirect_url:"https://phim.nguonc.com/"}
    //        rồi khi phát hiện DevTools gọi location.replace() từ chính document.
    //      - Chặn redirect kiểu "/loi*.htm" hay ghi đè location.replace/assign
    //        KHÔNG chặn được: Chrome đánh dấu thành viên của Location là
    //        [LegacyUnforgeable] nên gán đè bị bỏ qua âm thầm (đã đo thực tế).
    //      - Proxy Function/eval của Phantom Shield chỉ làm sạch chuỗi code MỚI,
    //        không chạm được câu lệnh `debugger;` đã biên dịch trong guard-messages*.js,
    //        nên phép đo thời gian quanh `debugger;` vẫn báo "đã mở DevTools".
    //
    //    => Cách sửa: chặn guard ngay từ gốc — bóc cấu hình anti-devtools khỏi mọi
    //       payload JSON trước khi guard đọc. Guard thoát ở dòng đầu
    //       (`if (!e || ...) return;`) nên detect_devtools / anti_adblock / chặn phím
    //       / chuyển hướng KHÔNG bao giờ bật. Lớp chặn chuyển hướng thật nằm ở
    //       background.js (declarativeNetRequest block main_frame + sub_frame).
    // ==========================================================================
    const SG_LOCK_KEY = 'stream-guard:devtools-session-lock:v1';
    const sgState = { stripped: 0, hosts: [] };
    const sgLog = (m) => { try { console.log('%c[PhantomShield]', 'color:#0aa', m); } catch (e) {} };

    function sgHostBlocked(url) {
        try {
            if (!url) return false;
            const h = new URL(String(url), location.href).hostname.toLowerCase();
            return sgState.hosts.some(d => h === d || h.endsWith('.' + d));
        } catch (e) { return false; }
    }

    // --- 0a. Bóc cấu hình anti-devtools khỏi mọi kết quả JSON.parse ---
    (function sgPatchJsonParse() {
        const origParse = JSON.parse;
        const stripConfig = (obj) => {
            let hit = false;
            try {
                if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return false;
                if (obj.browserGuard && typeof obj.browserGuard === 'object') {
                    delete obj.browserGuard; hit = true;
                }
                if (obj.guard && typeof obj.guard === 'object' && 'devtools_redirect_url' in obj.guard) {
                    delete obj.guard; hit = true;
                }
                // Tổng quát: object con nào mang đủ dấu hiệu anti-devtools thì bóc
                for (const k in obj) {
                    const v = obj[k];
                    if (v && typeof v === 'object' && !Array.isArray(v) &&
                        ('devtools_redirect_url' in v) && ('detect_devtools' in v)) {
                        delete obj[k]; hit = true;
                    }
                }
            } catch (e) {}
            return hit;
        };
        const patched = function (text, reviver) {
            const out = origParse.call(this, text, reviver);
            try {
                if (stripConfig(out)) {
                    sgState.stripped++;
                    sgLog('Đã bóc cấu hình anti-devtools (browserGuard) — guard sẽ không chạy');
                }
            } catch (e) {}
            return out;
        };
        try {
            Object.defineProperty(patched, 'name', { value: 'parse' });
            Object.defineProperty(patched, 'length', { value: 2 });
        } catch (e) {}
        JSON.parse = patched;
    })();

    // --- 0b. Nếu trang tự ghi lại JSON vào #stream-bootstrap (cdn-start làm vậy) ---
    function sgScrubBootstrap() {
        try {
            const el = document.getElementById('stream-bootstrap');
            if (!el) return;
            const txt = el.textContent;
            if (!txt || txt.indexOf('browserGuard') === -1) return;
            const obj = JSON.parse(txt);
            if (obj && typeof obj === 'object' && obj.browserGuard) {
                delete obj.browserGuard;
                window.__phantomScrubbing = true;
                el.textContent = JSON.stringify(obj);
                window.__phantomScrubbing = false;
                sgState.stripped++;
                sgLog('Đã bóc browserGuard trong #stream-bootstrap');
            }
        } catch (e) {}
    }
    try {
        const startObserver = () => {
            new MutationObserver((records) => {
                if (window.__phantomScrubbing) return;
                for (const rec of records) {
                    const t = rec.target;
                    const el = (t && t.nodeType === 1) ? t : (t && t.parentNode);
                    if (el && (el.id === 'stream-bootstrap' || (el.closest && el.closest('#stream-bootstrap')))) {
                        sgScrubBootstrap();
                        return;
                    }
                }
            }).observe(document.documentElement || document, { childList: true, characterData: true, subtree: true });
            sgScrubBootstrap();
        };
        if (document.documentElement) startObserver();
        else document.addEventListener('readystatechange', function h() {
            if (document.documentElement) { document.removeEventListener('readystatechange', h); startObserver(); }
        });
    } catch (e) {}

    // --- 0c. Khoá phiên DevTools: xoá + chặn ghi ---
    try { sessionStorage.removeItem(SG_LOCK_KEY); } catch (e) {}
    try {
        const store = Storage.prototype, origSet = store.setItem, origGet = store.getItem;
        store.setItem = function (k, v) {
            if (k === SG_LOCK_KEY) { sgLog('Chặn ghi khoá phiên DevTools'); return undefined; }
            return origSet.call(this, k, v);
        };
        store.getItem = function (k) {
            if (k === SG_LOCK_KEY) return null;
            return origGet.call(this, k);
        };
    } catch (e) {}

    // --- 0d. Vô hiệu phép dò console (guard so console.debug phải là hàm native) ---
    try {
        if (window.console && typeof window.console.debug === 'function') {
            const realDebug = window.console.debug.bind(window.console);
            const wrapped = function () { return realDebug.apply(null, arguments); };
            try { Object.defineProperty(wrapped, 'name', { value: 'debug' }); } catch (e) {}
            window.console.debug = wrapped;
        }
    } catch (e) {}

    // --- 0e. Nếu guard đã kịp chạy (script nạp muộn) thì vô hiệu hoá ---
    try {
        if (window.streamGuard && window.streamGuard.__phantomDisabled !== true) {
            window.streamGuard.waitForAccess = async function () {};
            window.streamGuard.isBlocked = function () { return false; };
            try { Object.defineProperty(window.streamGuard, '__phantomDisabled', { value: true }); } catch (e) {}
            sgLog('Đã vô hiệu streamGuard đang chạy');
        }
    } catch (e) {}

    // Danh sách host chặn chuyển hướng do background/bridge đẩy sang
    window.addEventListener('PHANTOM_REDIRECT_HOSTS', function (ev) {
        try {
            const list = (ev && ev.detail && ev.detail.hosts) || [];
            sgState.hosts = list.map(h => String(h || '').trim().toLowerCase())
                .filter(h => h && h.indexOf('/') === -1);
            sgLog('Host chặn chuyển hướng: ' + (sgState.hosts.join(', ') || '(trống)'));
        } catch (e) {}
    });
    window.__phantomGuardStatus = function () {
        let st = null;
        try { st = window.streamGuard && window.streamGuard.status ? window.streamGuard.status() : null; } catch (e) {}
        return {
            version: 'phantom-32.2.3',
            guardPresent: !!window.streamGuard,
            guardDetectDevtools: !!(st && st.detectDevtools),
            configStripped: sgState.stripped,
            sessionLock: (function () { try { return sessionStorage.getItem(SG_LOCK_KEY); } catch (e) { return 'n/a'; } })(),
            redirectHosts: sgState.hosts
        };
    };

    // ==========================================
    // 1. TÀNG HÌNH PROXY (NATIVE FUNCTION SPOOFING)
    // ==========================================
    const proxyMap = new WeakMap();
    const origToString = Function.prototype.toString;

    Function.prototype.toString = function() {
        if (proxyMap.has(this)) {
            return origToString.call(proxyMap.get(this));
        }
        return origToString.call(this);
    };
    proxyMap.set(Function.prototype.toString, origToString);

    function sanitize(code) {
        if (typeof code === 'string' && code.includes('debugger')) {
            return code.replace(/debugger/g, '/*CezDev_Bypassed*/');
        }
        return code;
    }

    function isMalicious(fn) {
        try { 
            if (typeof fn === 'function' && origToString.call(fn).includes('debugger')) {
                return true;
            }
        } catch(e) {}
        return false;
    }

// ==========================================================================
    // 1B. WASM-GUARD NEUTRALIZER — anti-debug của player rổ phim
    //     (api.rophim.stream/player/embed  →  /jquery.js + /core_protect.js)
    //
    //     ĐÃ ĐO THẬT (2026-10-17) — reverse trực tiếp từ file đang chạy:
    //
    //     a) Player page có inline script:
    //          const S = await createShield();
    //          if (!S.checkEnvironment()) throw 2;
    //          setInterval(() => { if (!S.checkEnvironment()) {
    //              console.clear(); jwplayer('player').remove();
    //              window.location.replace('/500'); } }, 2000);
    //        ⇒ MỞ DEVTOOLS là bị đá sang /500 sau tối đa 2 giây. "Bị detect" chính là đây.
    //
    //     b) `createShield` nằm trong /jquery.js — file đó KHÔNG phải jQuery, mà là
    //        module Emscripten/WASM: wasm nhúng dạng chuỗi đã obfuscate bằng
    //        `binaryDecode(bin)` = mỗi ký tự `~c>>8&c`. Export thật chỉ có:
    //          o=memory, q=table, p=__wasm_call_ctors, r=___getTypeName, s=_malloc, t=_free
    //        Glue:
    //          var wasmImports={l:__abort_js, e:__embind_register_bigint,
    //            j:__embind_register_bool, n:__embind_register_emval,
    //            d:__embind_register_float, f:__embind_register_function,
    //            b:__embind_register_integer, a:__embind_register_memory_view,
    //            i:__embind_register_std_string, c:__embind_register_std_wstring,
    //            k:__embind_register_void, g:_emscripten_asm_const_int,
    //            h:_emscripten_get_now, m:_emscripten_resize_heap};
    //          var _emscripten_get_now=()=>performance.now();
    //
    //     c) ASM_CONSTS (hằng số chuỗi của emscripten, nhúng cuối glue):
    //          3316: () => { debugger }
    //          3326: () => { window.__NEXT_DATA_RAW__="BOMBED";
    //                        if(document.body) document.body.innerHTML="" }
    //
    //     d) Hàm wasm thật (func $21, gọi qua bảng hàm để embind expose thành
    //        checkEnvironment) — dịch từ wat:
    //            t0 = get_now();
    //            asm_const(3316);                        // <-- `debugger;`
    //            if (get_now() - t0 > 100) asm_const(3326);   // <-- BOM
    //            return (get_now()-t0) > 100 ? 0 : 1;
    //
    //     ⇒ Đây là phép ĐO THỜI GIAN QUANH MỘT CÂU `debugger;` ĐÃ BIÊN DỊCH SẴN.
    //       Vì vậy toàn bộ lớp cũ (mục 1..4) vô dụng với họ này:
    //         • proxy Function/eval chỉ làm sạch chuỗi code MỚI — câu `debugger;` đã
    //           nằm trong ASM_CONSTS (hàm tạo sẵn, đóng băng), không đi qua đâu cả;
    //         • vô hiệu console.debug / outerWidth-innerWidth / banner guard… không liên quan;
    //         • MutationObserver bóc `browserGuard` cũng không liên quan — player rổ
    //           KHÔNG dùng streamGuard/guard-messages (đó là họ streamc khác).
    //       Thêm nữa bom 3326 còn xoá sạch <body>: lớp "chống xoá DOM" ở mục 2 chỉ
    //       bắt `innerHTML=""` nên may chặn được dòng đó, nhưng cờ `__NEXT_DATA_RAW__`
    //       vẫn bị ghi ⇒ nếu trang khác đọc cờ này thì vẫn toi.
    //
    //     ⇒ CÁCH SỬA — 2 lớp độc lập, lớp nào cũng đủ để không bị detect:
    //       (1B-a) Bọc WebAssembly.instantiate: thay hàm import
    //              `emscripten_asm_const_int` bằng bản an toàn KHÔNG gọi
    //              ASM_CONSTS[3316]/[3326]; và import `emscripten_get_now` trỏ về
    //              performance.now đã bọc. ⇒ `debugger;` và bom không bao giờ chạy.
    //       (1B-b) Nếu site đổi tên import hoặc gọi thẳng ASM_CONSTS, lớp (1B-b) đỡ:
    //              "làm phẳng" performance.now() khi thấy đồng hồ nhảy vọt (dấu hiệu
    //              vừa bị DevTools dừng ở `debugger;`) ⇒ elapsed ≤ 100 ms.
    //       (1B-c) Chặn ghi cờ `__NEXT_DATA_RAW__` (tín hiệu bom) — luôn giữ rỗng.
    //       (1B-d) Nếu bom đã kịp nổ trước khi extension vào: khôi phục <body> từ snapshot.
    //     Đã kiểm chứng bằng harness chạy ĐÚNG wasm thật (xem README mục Bằng chứng).
    // ==========================================================================
    // ---- Trạng thái: gắn vào window để nạp lại (SPA re-inject / extension update)
    // KHÔNG dùng closure thuần — nếu script chạy 2 lần, lần 2 sẽ tạo wgState mới
    // trong khi wrapper cũ vẫn trỏ vào wgState cũ ⇒ asmBlocked không tăng (bug đã gặp).
    const wgState = window.__wgState || (window.__wgState = {
        clockFlattens: 0, bombFlags: 0, asmBlocked: 0, bodyRestored: 0, wasmWrapped: false
    });
    const wgLog = (m) => { try { console.log('%c[PhantomShield]', 'color:#0aa', m); } catch (e) {} };

    // ---- (1B-c) Cờ báo bom: nuốt mọi giá trị ghi vào ----
    try {
        let rawNext = '';
        Object.defineProperty(window, '__NEXT_DATA_RAW__', {
            configurable: true,
            get: () => rawNext,
            set: (v) => {
                wgState.bombFlags++;
                wgLog('Wasm-Guard: chặn cờ bom __NEXT_DATA_RAW__');
            }
        });
    } catch (e) {}

    // ---- (1B-b) Làm phẳng performance.now() khi đồng hồ nhảy vọt ----
    // Khi DevTools mở, câu `debugger;` làm đồng hồ nhảy vọt hàng trăm ms. Ta phát hiện
    // delta bất thường và "đóng băng" giá trị trả về ⇒ phép trừ elapsed của wasm
    // không thể vượt ngưỡng 100 ms. Chỉ can thiệp khi thật sự có cú nhảy, nên không
    // đụng tới video/player bình thường.
    //
    // Chi tiết quan trọng: cú nhảy có thể rơi vào BẤT KỲ lần gọi nào trong 2 lần
    // wasm lấy mốc (t0 và t1). Vì vậy:
    //   • luôn so delta với lần gọi TRƯỚC để bắt cú nhảy;
    //   • sau khi làm phẳng, giữ "thời gian ảo" chỉ trôi rất chậm trong một cửa sổ
    //     đủ dài để t1 cũng nằm trong đó (WG_FREEZE_WINDOW), rồi tự trả về thời gian thật.
    const WG_FREEZE_WINDOW = 1200;        // ms — phải phủ trọn 1 vòng đo của wasm
    try {
        const perf = window.performance;
        if (perf && typeof perf.now === 'function' && !perf.__wgPatched) {
            const origNow = perf.now.bind(perf);
            let last = origNow();
            let virtual = last;                    // "thời gian ảo" trả về cho caller
            let freezeUntil = -1;
            const wgNow = function () {
                const t = origNow();
                const d = t - last;
                if (d > 60) {                      // nhảy vọt ⇒ vừa bị dừng ở `debugger;`
                    freezeUntil = t + WG_FREEZE_WINDOW;
                    virtual = last + 1;            // coi như chỉ trôi 1 ms
                    wgState.clockFlattens++;
                } else if (t < freezeUntil) {
                    virtual = Math.min(t, virtual + 0.5);   // trong cửa sổ: trôi rất chậm
                } else {
                    virtual = t;                   // hết cửa sổ: trả về thời gian thật
                }
                last = t;
                return Math.min(t, virtual);
            };
            try { Object.defineProperty(wgNow, 'name', { value: 'now' }); } catch (e) {}
            try { Object.defineProperty(wgNow, 'length', { value: 0 }); } catch (e) {}
            try {
                Object.defineProperty(perf, 'now', { value: wgNow, configurable: true, writable: true });
                Object.defineProperty(perf, '__wgPatched', { value: true, configurable: true });
            } catch (e) {
                try { perf.now = wgNow; } catch (e2) {}
            }
            // Bản sao trên prototype (nếu có) để không lọt đường vòng
            try {
                const proto = Object.getPrototypeOf(perf);
                if (proto && typeof proto.now === 'function' && proto.now !== wgNow) {
                    Object.defineProperty(proto, 'now', { value: wgNow, configurable: true, writable: true });
                }
            } catch (e) {}
        }
    } catch (e) {}

    // ---- (1B-a) Bọc WebAssembly.instantiate để vô hiệu asm_const độc hại ----
    try {
        // Bọc ĐÚNG MỘT LẦN: dùng cờ trên window, nhưng mọi thống kê đi vào wgState
        // (cũng trên window) nên nạp lại script vẫn dùng chung một state.
        if (!window.__wgWasmWrapped) {
            window.__wgWasmWrapped = true;
            wgState.wasmWrapped = true;

            // CÁCH NHẬN DIỆN IMPORT (bài học 32.2.1 → 32.2.2):
            //  • Tên import trong wasm bị MINIFY ("a"."g") ⇒ không thể khớp theo tên.
            //  • `fn.length` (arity) KHÔNG đáng tin: WebAssembly không kiểm tra số tham
            //    số JS, nên hàm g có thể khai 1 hay 3 tham số tuỳ cách build/glue.
            //  ⇒ Nhận diện theo HÀNH VI: gọi thử hàm với probe và xem dấu vết.
            //    an toàn vì (a) import chỉ được wasm gọi SAU khi instantiate,
            //    (b) tham số probe là số nguyên vô hại, (c) mọi lỗi đều nuốt.
            //
            //  Với asm_const_int: gọi `fn(-2147483648, 0, 0)` … không tốt vì hàm thật sẽ
            //  tra ASM_CONSTS[code] ⇒ không có ⇒ trả 0. Thay vào đó nhận diện gián tiếp:
            //  hàm asm_const LUÔN được wasm gọi với tham số ĐẦU là hằng số nhỏ (địa chỉ/
            //  chỉ số hằng). Ta bọc MỌI hàm import, và chỉ can thiệp khi thấy
            //  `code === 3316 || 3326` — tức là ta không cần biết trước hàm nào là asm_const:
            //  chỉ cần bọc tất cả, và chặn đúng 2 mã độc.
            //  Riêng get_now thì cần thiết: bọc mọi hàm 0-tham số trả về số và cho nó
            //  đọc performance.now() của ta.
            const patchImports = (imports) => {
                try {
                    if (!imports || typeof imports !== 'object') return imports;
                    for (const ns of Object.keys(imports)) {
                        const table = imports[ns];
                        if (!table || typeof table !== 'object') continue;
                        for (const name of Object.keys(table)) {
                            const orig = table[name];
                            if (typeof orig !== 'function') continue;
                            if (orig.__wgSafe) continue;

                            const looksLikeNowRes = /get_now_res/i.test(name);
                            const looksLikeNow = !looksLikeNowRes && (/emscripten_get_now/i.test(name) ||
                                (name.length <= 2 && orig.length === 0));   // "h" minify

                            if (looksLikeNowRes) {
                                const resFn = function () { return 1000; };   // 1 ms
                                resFn.__wgSafe = true;
                                table[name] = resFn;
                                proxyMap.set(resFn, orig);
                                continue;
                            }

                            if (looksLikeNow) {
                                const nowFn = function () {
                                    try { return window.performance.now(); } catch (e) { return Date.now(); }
                                };
                                nowFn.__wgSafe = true;
                                table[name] = nowFn;
                                proxyMap.set(nowFn, orig);
                                continue;
                            }

                            // Mặc định: bọc "hộp đen" — chuyển tiếp nguyên tham số, nhưng
                            // chặn 2 mã độc của player rổ phim nếu có xuất hiện.
                            const guarded = function () {
                                const args = arguments;
                                if (args.length > 0) {
                                    const code = args[0];
                                    if (code === 3316 || code === 3326) {
                                        wgState.asmBlocked++;
                                        return 0;
                                    }
                                }
                                try { return orig.apply(null, args); } catch (e) { return 0; }
                            };
                            guarded.__wgSafe = true;
                            table[name] = guarded;
                            proxyMap.set(guarded, orig);
                        }
                    }
                } catch (e) {}
                return imports;
            };

            const origInstantiate = WebAssembly.instantiate;
            const origStreaming = WebAssembly.instantiateStreaming;
            const wgInstantiate = function (buf, imports) {
                return origInstantiate.call(WebAssembly, buf, patchImports(imports));
            };
            const wgStreaming = origStreaming ? function (resp, imports) {
                return origStreaming.call(WebAssembly, resp, patchImports(imports));
            } : undefined;
            proxyMap.set(wgInstantiate, origInstantiate);
            WebAssembly.instantiate = wgInstantiate;
            if (wgStreaming) {
                proxyMap.set(wgStreaming, origStreaming);
                WebAssembly.instantiateStreaming = wgStreaming;
            }
            wgState.wasmWrapped = true;
            wgLog('Wasm-Guard: đã bọc WebAssembly.instantiate (chặn `debugger;` + bom của player rổ phim)');
        }
    } catch (e) {}

    // ---- (1B-d) Khôi phục <body> nếu bom đã nổ trước khi extension kịp vào ----
    let wgBodyHtml = null;
    const wgSnapshotBody = () => {
        try {
            if (document.body && wgBodyHtml === null && document.body.innerHTML.length > 40) {
                wgBodyHtml = document.body.innerHTML;
            }
        } catch (e) {}
    };
    const wgRestoreBody = () => {
        try {
            if (!wgBodyHtml || !document.body) return;
            const cur = document.body.innerHTML;
            if (cur && cur.length > 40) return;                 // còn nội dung ⇒ bình thường
            if (document.querySelector('video, #player, #embed-player, .jwplayer')) return; // đang phát ⇒ đừng phá
            document.body.innerHTML = wgBodyHtml;
            wgState.bodyRestored++;
            wgLog('Wasm-Guard: khôi phục <body> bị bom xoá');
        } catch (e) {}
    };
    try {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', wgSnapshotBody, { once: true });
        } else {
            wgSnapshotBody();
        }
        setInterval(wgRestoreBody, 1500);
    } catch (e) {}

    // Tình trạng: gọi __phantomGuardStatus() / __phantomWasmStatus() trong console
    window.__phantomWasmStatus = function () {
        return {
            version: 'phantom-32.2.3-wasm',
            wasmWrapped: wgState.wasmWrapped,
            asmBlocked: wgState.asmBlocked,
            clockFlattens: wgState.clockFlattens,
            bombFlagBlocks: wgState.bombFlags,
            bodyRestored: wgState.bodyRestored,
            perfPatched: !!(window.performance && window.performance.__wgPatched)
        };
    };

    // ==========================================
    // 2. MỞ KHÓA UI & CHỐNG CLEAR DOM
    // ==========================================
    function unlockDevTools(win) {
        try {
            const stopProp = (e) => {
                if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'C' || e.key === 'J'))) {
                    e.stopImmediatePropagation();
                }
                if (['contextmenu', 'selectstart', 'copy'].includes(e.type)) {
                    e.stopImmediatePropagation();
                }
            };
            win.addEventListener('contextmenu', stopProp, true);
            win.addEventListener('keydown', stopProp, true);
            win.addEventListener('selectstart', stopProp, true);
            win.addEventListener('copy', stopProp, true);

            // [v32.2.0] Bản cũ yêu cầu document.body phải tồn tại -> ở document_start
            // body còn null nên lớp chống xoá DOM KHÔNG BAO GIỜ được cài (bug thật).
            // Giờ cài vô điều kiện: chỉ can thiệp khi đối tượng là <body>.
            if (win.document && win.document.documentElement) {
                const bodyDesc = Object.getOwnPropertyDescriptor(Element.prototype, 'innerHTML');
                if (bodyDesc && bodyDesc.set) {
                    const origSet = bodyDesc.set;
                    Object.defineProperty(Element.prototype, 'innerHTML', {
                        configurable: bodyDesc.configurable,
                        enumerable: bodyDesc.enumerable,
                        get: bodyDesc.get,
                        set: function(val) {
                            if (this.tagName === 'BODY' && (val === '' || val.trim() === '')) {
                                return; // Block DOM clear silently
                            }
                            return origSet.call(this, val);
                        }
                    });
                }
            }
        } catch(e) {}
    }

    // ==========================================
    // 3. BỌC PROXY CHO CÁC HÀM HỆ THỐNG
    // ==========================================
    const createProxy = (originalFunc, isConstructor = false) => {
        if (!originalFunc) return originalFunc;
        const handler = {
            apply: function(target, thisArg, args) {
                if (args.length > 0) {
                    if (typeof args[0] === 'string') args[0] = sanitize(args[0]);
                    else if (isMalicious(args[0])) args[0] = function() {}; 
                }
                if (isConstructor && args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.apply(target, thisArg, args);
            }
        };
        if (isConstructor) {
            handler.construct = function(target, args) {
                if (args.length > 0 && typeof args[args.length - 1] === 'string') {
                    args[args.length - 1] = sanitize(args[args.length - 1]);
                }
                return Reflect.construct(target, args);
            };
        }
        const proxy = new Proxy(originalFunc, handler);
        proxyMap.set(proxy, originalFunc);
        return proxy;
    };

    // ==========================================
    // 4. BYPASS ANTI-ADBLOCK + CHẶN REDIRECT "LOI" (vn2c / vn2data / ...)
    //    - Khoá biến kenhvn2 luôn = 1 (site dùng nó để quyết định phát hay hiện loi3.htm)
    //    - Giả lập response 200 cho request dò adblock (/Images/ads/*, contineljs.com)
    //      => chuỗi fetch().catch(...) của site không bao giờ rơi vào catch
    //    - Chặn mọi chuyển hướng tới /loi.htm, /loi2.htm, /loi3.htm
    //    - (strict) vô hiệu hoá check "window.top !== window.self" chống nhúng iframe
    // ==========================================
    /*__CEZDEV_BYPASS_START__*/
    function installBypass(win, strict) {
        try {
            if (win.__cezdev_bypass) return;
            win.__cezdev_bypass = true;
        } catch (e) { return; }

        // ----- A. KHOÁ BIẾN CHỐNG-ADBLOCK (kenhvn2) -----
        // Logic site (play.php) đảo ngược:
        //   kenhvn2 = "" (ban đầu)   -> if (kenhvn2 > 0) FALSE -> nạp link thật
        //   mobi2.js đặt kenhvn2 = 1 -> check lần 2 giữ nguyên link thật
        //   bị phát hiện adblock     -> mobi2 đặt kenhvn2 = "" -> xoá link + hiện /loi3.htm
        // => chỉ nhận giá trị TRUTHY, còn falsy (chuỗi rỗng) thì nuốt đi.
        let __kenhvn2;
        try {
            Object.defineProperty(win, 'kenhvn2', {
                configurable: true,
                get: function() { return __kenhvn2; },
                set: function(v) { if (v) __kenhvn2 = v; }
            });
        } catch (e) {}

        // ----- B. REQUEST DÒ ADBLOCK LUÔN "THÀNH CÔNG" -----
        const PROBE_PATTERNS = ['/images/ads/', 'contineljs.com', 'ads/300.gif', 'adblock'];
        const isProbe = (url) => {
            const low = String(url).toLowerCase();
            return PROBE_PATTERNS.some(function(p) { return low.indexOf(p) !== -1; });
        };
        const fakeResponse = () => {
            try {
                const R = win.Response;
                if (typeof R === 'function') return Promise.resolve(new R(null, { status: 200, statusText: 'OK' }));
            } catch (e) {}
            return Promise.resolve({
                ok: true, status: 200, statusText: 'OK', type: 'opaque',
                text: () => Promise.resolve(''),
                arrayBuffer: () => Promise.resolve(new ArrayBuffer(0)),
                blob: () => Promise.resolve(new Blob([]))
            });
        };
        const localMap = (typeof proxyMap !== 'undefined' && proxyMap) ? proxyMap : new WeakMap();
        try {
            const origFetch = win.fetch;
            if (typeof origFetch === 'function' && !origFetch.__cezdev) {
                const patchedFetch = function(input, init) {
                    let url = '';
                    try { url = (typeof input === 'string') ? input : ((input && input.url) || ''); } catch (e) {}
                    if (isProbe(url)) return fakeResponse();
                    return origFetch.apply(this, arguments);
                };
                patchedFetch.__cezdev = true;
                try { localMap.set(patchedFetch, origFetch); } catch (e) {}
                win.fetch = patchedFetch;
            }
        } catch (e) {}

        // ----- C. CHẶN CHUYỂN HƯỚNG SANG TRANG "LOI" -----
        const BLOCKED_NAV = [/\/loi[0-9]*\.html?/i, /^about:blank/i];
        const isBlockedNav = (url) => {
            if (url === undefined || url === null) return false;
            const u = String(url).trim().toLowerCase();
            if (u === '') return true;
            // Host trong "Redirect Block List" (mặc định: phim.nguonc.com)
            if (sgHostBlocked(url)) return true;
            return BLOCKED_NAV.some(function(re) { return re.test(u); });
        };

        try {
            const loc = win.location;
            if (loc) {
                const wrapLoc = (fn) => function(url) {
                    if (isBlockedNav(url)) return undefined;
                    return fn.apply(loc, arguments);
                };
                if (typeof loc.replace === 'function') loc.replace = wrapLoc(loc.replace);
                if (typeof loc.assign === 'function') loc.assign = wrapLoc(loc.assign);
            }
        } catch (e) {}

        try {
            if (typeof Location !== 'undefined' && Location.prototype) {
                const desc = Object.getOwnPropertyDescriptor(Location.prototype, 'href');
                if (desc && desc.set) {
                    Object.defineProperty(Location.prototype, 'href', {
                        configurable: true,
                        enumerable: desc.enumerable,
                        get: desc.get,
                        set: function(url) {
                            if (isBlockedNav(url)) return;
                            return desc.set.call(this, url);
                        }
                    });
                }
            }
        } catch (e) {}

        try {
            const hist = win.history;
            if (hist) {
                const wrapState = (fn) => function(state, title, url) {
                    if (arguments.length >= 3 && isBlockedNav(url)) return undefined;
                    return fn.apply(hist, arguments);
                };
                if (typeof hist.pushState === 'function') hist.pushState = wrapState(hist.pushState);
                if (typeof hist.replaceState === 'function') hist.replaceState = wrapState(hist.replaceState);
            }
        } catch (e) {}

        try {
            const origOpen = win.open;
            if (typeof origOpen === 'function') {
                win.open = function(url) {
                    if (isBlockedNav(url)) return null;
                    return origOpen.apply(win, arguments);
                };
            }
        } catch (e) {}

        // ----- D. GỠ BOM KHUNG (chỉ bật ở chế độ STRICT) -----
        if (strict) applyStrictMode(win);
    }

    function applyStrictMode(win) {
        try {
            if (win.__cezdev_strict) return;
            win.__cezdev_strict = true;
            // window.top là [Replaceable] -> ghi đè được, khiến check
            // "window.top !== window.self" luôn sai => không bị đá sang /loi.htm
            Object.defineProperty(win, 'top', {
                configurable: true,
                get: function() { return win.self; }
            });
        } catch (e) {}
    }
    /*__CEZDEV_BYPASS_END__*/

    // Domain mặc định bật STRICT (thêm/bớt tuỳ ý; popup cũng đẩy thêm qua bridge)
    const DEFAULT_STRICT_HOSTS = [
        'vn2c.my', 'vn2data.com', 'vn2s.com', 'vn2s.net', 'vn2s.org', 'vn2s.tv'
    ];
    function hostInStrictList() {
        try {
            const h = String(location.hostname || '').toLowerCase();
            if (!h) return false;
            return DEFAULT_STRICT_HOSTS.some(function(d) {
                return h === d || h.endsWith('.' + d);
            });
        } catch (e) { return false; }
    }

    let strictMode = hostInStrictList();

    // Bridge (Isolated World) bắn sự kiện khi domain nằm trong Redirect List của user
    window.addEventListener('ACTIVATE_STRICT_MODE', function() {
        strictMode = true;
        applyStrictMode(window);
        document.querySelectorAll('iframe').forEach(function(f) {
            try { if (f.contentWindow) applyStrictMode(f.contentWindow); } catch (e) {}
        });
    });

    // ==========================================
    // 5. LÕI BẢO VỆ (APPLY HOOKS)
    // ==========================================
    const applyHooks = (win) => {
        try {
            if (win._cezdev_hooked) return;
            win._cezdev_hooked = true;

            unlockDevTools(win);

            win.setTimeout = createProxy(win.setTimeout);
            win.setInterval = createProxy(win.setInterval);
            win.requestAnimationFrame = createProxy(win.requestAnimationFrame); 

            const proxyFunc = createProxy(win.Function, true);
            win.Function = proxyFunc;
            
            try { win.Function.prototype.constructor = proxyFunc; } catch(e){}
            try { 
                const AsyncFunc = Object.getPrototypeOf(async function(){}).constructor;
                Object.getPrototypeOf(async function(){}).constructor = createProxy(AsyncFunc, true);
            } catch(e){}
            try { 
                const GenFunc = Object.getPrototypeOf(function*(){}).constructor;
                Object.getPrototypeOf(function*(){}).constructor = createProxy(GenFunc, true);
            } catch(e){}

            const realEval = win.eval;
            const fakeEval = function(code) { return realEval(sanitize(code)); };
            proxyMap.set(fakeEval, realEval);
            win.eval = fakeEval;

            try {
                const noop = () => {};
                if (win.console) {
                    ['clear', 'profile', 'profileEnd', 'table'].forEach(method => {
                        Object.defineProperty(win.console, method, {
                            value: noop,
                            writable: false,
                            configurable: false 
                        });
                    });
                }
            } catch (e) {}

            try {
                Object.defineProperty(win, 'outerWidth', { get: () => win.innerWidth, configurable: false });
                Object.defineProperty(win, 'outerHeight', { get: () => win.innerHeight, configurable: false });
            } catch (e) {}

            // Bypass anti-adblock / chặn redirect "loi" (đã gồm cả block about:blank cũ)
            installBypass(win, strictMode);

            if (strictMode) applyStrictMode(win);

        } catch(e) {}
    };

    applyHooks(window);

    // ==========================================
    // 6. THEO DÕI VÀ TIÊM VÀO IFRAME LIÊN TỤC
    // ==========================================
    const observeIframes = () => {
        const observer = new MutationObserver((mutations) => {
            for (const mut of mutations) {
                for (const node of mut.addedNodes) {
                    if (node.tagName === 'IFRAME') {
                        try {
                            if (node.contentWindow) applyHooks(node.contentWindow);
                        } catch(e) {}
                        
                        node.addEventListener('load', () => {
                            try {
                                if (node.contentWindow) applyHooks(node.contentWindow);
                            } catch(e) {}
                        }, { once: true });
                    }
                }
            }
        });

        observer.observe(document, { childList: true, subtree: true });
    };

    if (document.documentElement) {
        observeIframes();
    } else {
        window.addEventListener('DOMContentLoaded', observeIframes);
    }

})();