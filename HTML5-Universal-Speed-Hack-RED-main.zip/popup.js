let currentConfig = {
    speed: 1.0,
    cbSetIntervalChecked: false,
    cbSetTimeoutChecked: false,
    cbPerformanceNowChecked: false,
    cbDateNowChecked: false,
    cbRequestAnimationFrameChecked: false,
};

const speedRange = document.getElementById('speedRange');
const speedValue = document.getElementById('speedValue');
const btnReset = document.getElementById('btnReset');
const checkboxes = {
    cbSetIntervalChecked: document.getElementById('cbSetIntervalChecked'),
    cbSetTimeoutChecked: document.getElementById('cbSetTimeoutChecked'),
    cbRequestAnimationFrameChecked: document.getElementById('cbRequestAnimationFrameChecked'),
    cbPerformanceNowChecked: document.getElementById('cbPerformanceNowChecked'),
    cbDateNowChecked: document.getElementById('cbDateNowChecked'),
};

// Hàm gửi tin nhắn an toàn tới Tab
function sendMessageToTab(command, payload = {}) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (!activeTab || !activeTab.id) return;

        // Bỏ qua các trang hệ thống
        if (activeTab.url.startsWith("chrome://") || 
            activeTab.url.startsWith("edge://") || 
            activeTab.url.startsWith("about:")) {
            return;
        }

        // --- DEBUG LOG (Đã đặt đúng chỗ) ---
        console.log("[SpeedHack] Sending to tab:", command, payload);

        chrome.tabs.sendMessage(activeTab.id, {
            command: command,
            config: payload
        }, (response) => {
            // Xử lý lỗi connection
            if (chrome.runtime.lastError) {
                console.log("Chưa kết nối được với Page. Hãy reload trang web.");
                return;
            }
            if (command === "getSpeedConfig" && response) {
                console.log("[SpeedHack] Got config from tab:", response);
                currentConfig = { ...currentConfig, ...response };
                updateUI();
            }
        });
    });
}

function updateUI() {
    speedRange.value = currentConfig.speed;
    speedValue.textContent = parseFloat(currentConfig.speed).toFixed(1);

    for (const key in checkboxes) {
        if (checkboxes[key]) {
            checkboxes[key].checked = currentConfig[key];
        }
    }
}

// --- Events ---
document.addEventListener('DOMContentLoaded', () => {
    sendMessageToTab("getSpeedConfig");
});

speedRange.addEventListener('input', (e) => {
    const val = parseFloat(e.target.value);
    currentConfig.speed = val;
    speedValue.textContent = val.toFixed(1);
    sendMessageToTab("setSpeedConfig", currentConfig);
});

for (const key in checkboxes) {
    checkboxes[key].addEventListener('change', (e) => {
        currentConfig[key] = e.target.checked;
        sendMessageToTab("setSpeedConfig", currentConfig);
    });
}

// Logic Nút Reset
btnReset.addEventListener('click', () => {
    currentConfig = {
        speed: 1.0,
        cbSetIntervalChecked: false,
        cbSetTimeoutChecked: false,
        cbPerformanceNowChecked: false,
        cbDateNowChecked: false,
        cbRequestAnimationFrameChecked: false,
    };
    updateUI();
    sendMessageToTab("setSpeedConfig", currentConfig);
});