// pageScript.js - Final Edition (For-Loop + WeakMap + Stealth)

(function () {
  "use strict";

  let speedConfig = {
    speed: 1.0,
    cbSetIntervalChecked: false,
    cbSetTimeoutChecked: false,
    cbPerformanceNowChecked: false,
    cbDateNowChecked: false,
    cbRequestAnimationFrameChecked: false,
  };

  // --- STEALTH HELPER ---
  function makeNative(mockFunc, originalFunc) {
    try {
      Object.defineProperties(mockFunc, {
        name: { value: originalFunc.name },
        length: { value: originalFunc.length },
        toString: { value: () => originalFunc.toString() }
      });
    } catch {}
    return mockFunc;
  }

  // --- 1. CAPTURE ORIGINALS (SAFE BIND) ---
  const rawOriginals = {
    setTimeout: window.setTimeout,
    clearTimeout: window.clearTimeout,
    setInterval: window.setInterval,
    clearInterval: window.clearInterval,
    requestAnimationFrame: window.requestAnimationFrame,
    performanceNow: window.performance.now,
    dateNow: Date.now,
    Worker: window.Worker
  };

  const exec = {
    setTimeout: window.setTimeout.bind(window),
    clearTimeout: window.clearTimeout.bind(window),
    setInterval: window.setInterval.bind(window),
    clearInterval: window.clearInterval.bind(window),
    requestAnimationFrame: window.requestAnimationFrame.bind(window),
    performanceNow: window.performance.now.bind(window.performance),
    dateNow: Date.now,
    wSelf: self 
  };

  // --- 2. TIMER MANAGER (Map Optimization) ---
  const activeTimers = new Map();

  const reloadTimers = () => {
    const nextTimers = new Map();
    
    for (const [id, timer] of activeTimers.entries()) {
      exec.clearInterval(timer.realId);
      
      if (!timer.finished) {
        const delay = speedConfig.cbSetIntervalChecked
            ? timer.originalTimeout / speedConfig.speed
            : timer.originalTimeout;

        const newId = exec.setInterval(timer.handler, delay, ...timer.args);
        
        nextTimers.set(newId, {
          realId: newId,
          handler: timer.handler,
          originalTimeout: timer.originalTimeout,
          args: timer.args
        });
      }
    }
    
    activeTimers.clear();
    for (const [key, val] of nextTimers.entries()) {
        activeTimers.set(key, val);
    }
  };

  // --- 3. RAF MANAGER (WeakMap Optimization) ---
  const rafState = new WeakMap(); 

  // --- 4. OVERRIDES ---

  // A. clearInterval
  window.clearInterval = makeNative((id) => {
    exec.clearInterval(id);
    if (activeTimers.has(id)) {
        activeTimers.delete(id);
    }
  }, rawOriginals.clearInterval);

  // B. clearTimeout
  window.clearTimeout = makeNative((id) => {
    exec.clearTimeout(id);
  }, rawOriginals.clearTimeout);

  // C. setInterval
  window.setInterval = makeNative((handler, timeout = 0, ...args) => {
    const actualTimeout = speedConfig.cbSetIntervalChecked 
        ? timeout / speedConfig.speed 
        : timeout;
        
    const id = exec.setInterval(handler, actualTimeout, ...args);
    
    activeTimers.set(id, {
      realId: id,
      handler: handler,
      originalTimeout: timeout,
      args: args
    });
    
    return id;
  }, rawOriginals.setInterval);

  // D. setTimeout
  window.setTimeout = makeNative((handler, timeout = 0, ...args) => {
    const actualTimeout = speedConfig.cbSetTimeoutChecked 
        ? timeout / speedConfig.speed 
        : timeout;
    return exec.setTimeout(handler, actualTimeout, ...args);
  }, rawOriginals.setTimeout);

  // E. Performance.now & Date.now
  (function() {
      let pVal = null, pPrev = null;
      window.performance.now = makeNative(() => {
          const real = exec.performanceNow();
          if (pVal !== null) {
              pVal += (real - pPrev) * (speedConfig.cbPerformanceNowChecked ? speedConfig.speed : 1);
          } else pVal = real;
          pPrev = real;
          return Math.floor(pVal);
      }, rawOriginals.performanceNow);

      let dVal = null, dPrev = null;
      Date.now = makeNative(() => {
          const real = exec.dateNow();
          if (dVal !== null) {
              dVal += (real - dPrev) * (speedConfig.cbDateNowChecked ? speedConfig.speed : 1);
          } else dVal = real;
          dPrev = real;
          return Math.floor(dVal);
      }, rawOriginals.dateNow);
  })();

  // F. RequestAnimationFrame (FOR LOOP LOGIC)
  (function() {
      let disableRAF = false;

      window.requestAnimationFrame = makeNative((callback) => {
          if (disableRAF) return 1;

          return exec.requestAnimationFrame((timestamp) => {
              let tick = rafState.get(callback) || 0;

              if (!speedConfig.cbRequestAnimationFrameChecked) {
                  callback(exec.performanceNow());
                  if (tick !== 0) rafState.set(callback, 0); 
                  return;
              }

              tick += speedConfig.speed;
              
              const iterations = Math.floor(tick);

              if (iterations >= 1) {
                  const startTime = exec.performanceNow();
                  
                  // Giới hạn số vòng lặp để tránh treo trình duyệt
                  const cappedIterations = Math.min(iterations, 10);
                  
                  for (let i = 0; i < cappedIterations; i++) {
                      try {
                          callback(exec.performanceNow());
                      } catch (e) {
                          console.error(e);
                      }
                      
                      disableRAF = true;
                      tick -= 1; 
                      
                      if (exec.performanceNow() - startTime > 15) {
                          break;
                      }
                  }
                  disableRAF = false;
              } else {
                  window.requestAnimationFrame(callback);
              }

              rafState.set(callback, tick);
          });
      }, rawOriginals.requestAnimationFrame);
  })();

  // G. Worker (Hook)
  if (rawOriginals.Worker) {
    window.Worker = makeNative(function(scriptURL, options) {
        if (speedConfig.speed !== 1.0) {
            console.warn("[SpeedHack] Worker detected while speed manipulation is active.");
        }
        return new rawOriginals.Worker(scriptURL, options);
    }, rawOriginals.Worker);
  }

  // --- COMMUNICATION ---
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data.command === "setSpeedConfig") {
      speedConfig = e.data.config;
      reloadTimers();
    }
  });
  
  window.postMessage({ command: "getSpeedConfig" }, "*"); 

})();