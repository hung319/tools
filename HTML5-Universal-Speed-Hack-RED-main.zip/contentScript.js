// contentScript.js
// Bridge: Popup UI <-> Content Script (Isolated) <-> Page Script (Main)

let speedConfig = {
  speed: 1.0,
  cbSetIntervalChecked: false,
  cbSetTimeoutChecked: false,
  cbPerformanceNowChecked: false,
  cbDateNowChecked: false,
  cbRequestAnimationFrameChecked: false,
};

// 1. Load config ban đầu (nếu có) nhưng không bắt buộc
chrome.storage.local.get("speedConfig", (data) => {
  if (data.speedConfig) {
    speedConfig = data.speedConfig;
  }
  // Sync xuống Main World
  window.postMessage({
    command: "setSpeedConfig",
    config: speedConfig,
  });
});

// 2. Nhận lệnh từ Popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.command === "setSpeedConfig") {
    speedConfig = request.config;
    // Chuyển tiếp xuống pageScript
    window.postMessage(request);
    // Phản hồi để đóng kết nối extension
    sendResponse({ status: "success" });
  } 
  else if (request.command === "getSpeedConfig") {
    sendResponse(speedConfig);
  }
  return true; // Async response
});

// 3. Nhận yêu cầu từ pageScript (Main World)
window.addEventListener("message", (e) => {
  if (e.source === window && e.data.command === "getSpeedConfig") {
    // Gửi lại config hiện có cho pageScript
    window.postMessage({
        command: "setSpeedConfig",
        config: speedConfig
    });
  }
});