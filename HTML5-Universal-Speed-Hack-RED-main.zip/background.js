// background.js
// Chỉ chạy khi sự kiện cài đặt diễn ra

const defaultConfig = {
  speed: 1.0,
  cbSetIntervalChecked: false,
  cbSetTimeoutChecked: false,
  cbPerformanceNowChecked: false,
  cbDateNowChecked: false,
  cbRequestAnimationFrameChecked: false,
};

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.storage.local.set({ speedConfig: defaultConfig });
  }
});