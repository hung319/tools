/* CezDev Anti-Debug Lite — 2 việc, không hơn.
 *
 * 1. KHÔNG đăng ký timer/callback nào chứa `debugger;`
 *    → DevTools không dừng, không nhảy vào file player.
 * 2. Treo DisableDevtool bằng chính API của nó (isSuspend = true)
 *    → detector ngừng, không history.back(), không bị đá sang trang 404.
 *
 * Không panel, không storage, không chặn URL, không đụng performance.now,
 * không proxy Function/eval, không sửa fetch/innerHTML.
 */
(function () {
    'use strict';

    if (window.__liteInstalled) return;
    try { Object.defineProperty(window, '__liteInstalled', { value: true, configurable: true }); } catch (e) {}

    // ------------------------------------------------------------------
    // 1. Bỏ timer chứa `debugger;`
    // ------------------------------------------------------------------
    function hasDebugger(fn) {
        try {
            if (typeof fn !== 'function') return false;
            var src = Function.prototype.toString.call(fn);
            if (!src || src.length > 20000) return false;
            if (src.indexOf('[native code]') !== -1) return false;
            return /\bdebugger\b/.test(src);
        } catch (e) { return false; }
    }

    function guard(name) {
        try {
            var orig = window[name];
            if (typeof orig !== 'function' || orig.__liteGuard) return;
            var patched = new Proxy(orig, {
                apply: function (target, thisArg, args) {
                    if (hasDebugger(args[0])) {
                        window.__liteBlocked = (window.__liteBlocked || 0) + 1;
                        try { console.log('%c[Lite]', 'color:#0aa', 'bỏ ' + name + ' chứa debugger'); } catch (e) {}
                        // setInterval: trả id "câm"; setTimeout/rAF: 0
                        return name === 'setInterval' ? target.call(window, function () {}, 2147483647) : 0;
                    }
                    return Reflect.apply(target, thisArg, args);
                }
            });
            try { Object.defineProperty(patched, '__liteGuard', { value: true }); } catch (e) {}
            window[name] = patched;
        } catch (e) {}
    }

    // Cố ý KHÔNG bọc requestAnimationFrame: vòng render của canvas/player có thể
    // chứa chuỗi 'debugger' và bị bỏ ⇒ màn hình đen. Chỉ chặn 2 loại timer.
    guard('setInterval');
    guard('setTimeout');

    // ------------------------------------------------------------------
    // 2. Treo DisableDevtool (nếu trang dùng)
    // ------------------------------------------------------------------
    var ticks = 0;
    var fast = null;
    function suspend() {
        try {
            var dd = window.DisableDevtool;
            if (typeof dd === 'function' && dd.isSuspend !== true) {
                dd.isSuspend = true;
                window.__liteDD = (window.__liteDD || 0) + 1;
            }
        } catch (e) {}
        if (++ticks === 300 && fast) {           // ~9 s đầu: 30 ms/lần
            try { clearInterval(fast); } catch (e) {}
            try { setInterval(suspend, 1000); } catch (e) {}
        }
    }
    try { suspend(); fast = setInterval(suspend, 30); } catch (e) {}
})();
