#!/system/bin/sh
MODDIR=${0%/*}
CHROOT_PATH="/data/local/debian_chroot"
ROOTFS_URL="https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/dist-arm64v8/stable/oci/blobs/rootfs.tar.gz"

# Đợi máy boot xong và có mạng (thử tối đa 30s)
sleep 60

if [ ! -d "$CHROOT_PATH/bin" ]; then
    mkdir -p "$CHROOT_PATH"
    
    # Dùng wget của BusyBox để tải
    /system/bin/curl -L "$ROOTFS_URL" -o "$CHROOT_PATH/rootfs.tar.gz"
    
    # Giải nén bằng BusyBox tar
    cd "$CHROOT_PATH"
    /system/bin/tar -xzf rootfs.tar.gz
    rm rootfs.tar.gz
    
    # Cấu hình DNS cơ bản
    echo "nameserver 8.8.8.8" > "$CHROOT_PATH/etc/resolv.conf"
fi