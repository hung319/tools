#!/system/bin/sh

# Đặt các biến này theo chuẩn Magisk/APatch
SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
SERVICES=true # Bật lại true để APatch tìm service.sh

print_modname() {
  ui_print "*******************************"
  ui_print "  Debian Chroot for Yuu Onii-chan "
  ui_print "    - REBOOT AUTO-RUN FIX -    "
  ui_print "*******************************"
}

on_install() {
  ui_print "- Đang giải nén hệ thống..."
  unzip -o "$ZIPFILE" 'system/*' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'service.sh' -d "$MODPATH" >&2
  unzip -o "$ZIPFILE" 'uninstall.sh' -d "$MODPATH" >&2

  # --- PHẦN QUAN TRỌNG ĐỂ HẾT LỖI CP ---
  # Tạo thư mục tạm giống như APatch mong muốn
  mkdir -p /dev/tmp
  # Copy file vào đó để lệnh 'cp' mặc định của APatch tìm thấy
  cp "$MODPATH/service.sh" /dev/tmp/service.sh
  ui_print "- Đã xử lý lỗi tương thích APatch! ✨"
}

set_permissions() {
  ui_print "- Thiết lập quyền thực thi..."
  set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
  set_perm "$MODPATH/service.sh" 0 0 0755
  set_perm "$MODPATH/uninstall.sh" 0 0 0755
}