#!/system/bin/sh
# File này sẽ chạy khi Yuu Onii-chan gỡ cài đặt module

CHROOT_PATH="/data/local/debian_chroot"

# 1. Đảm bảo đã gỡ mount hết để tránh lỗi hệ thống khi xóa
umount -l $CHROOT_PATH/dev/pts 2>/dev/null
umount -l $CHROOT_PATH/dev 2>/dev/null
umount -l $CHROOT_PATH/proc 2>/dev/null
umount -l $CHROOT_PATH/sys 2>/dev/null
umount -l $CHROOT_PATH/mnt 2>/dev/null
umount -l $CHROOT_PATH/root 2>/dev/null

# 2. Xóa sạch thư mục Debian
if [ -d "$CHROOT_PATH" ]; then
    rm -rf "$CHROOT_PATH"
fi

# Ghi log nhẹ nhàng để biết đã xóa xong
echo "🌸 Debian Chroot đã được dọn dẹp sạch sẽ cho Yuu Onii-chan!" > /cache/debian_uninstall.log